package com.maveric.loanapi.controller;



import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.loanapi.dto.AadhaarVerificationRequest;
import com.maveric.loanapi.dto.AadhaarVerificationResponse;
import com.maveric.loanapi.model.AadhaarData;
import com.maveric.loanapi.service.AadhaarService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/aadhaar")
public class AadhaarController {

    private final AadhaarService aadhaarService;

    public AadhaarController(AadhaarService aadhaarService) {
        this.aadhaarService = aadhaarService;
    }

    @PostMapping("/verify")
    public ResponseEntity<AadhaarVerificationResponse> verifyAadhaar(@Valid @RequestBody AadhaarVerificationRequest request,HttpServletRequest httpRequest) {
        AadhaarVerificationResponse response = aadhaarService.verifyAadhaar(request, httpRequest);
        return ResponseEntity.ok(response);
    }
    
    
    @GetMapping("/verify/{aadhaarNumber}")
    public ResponseEntity<AadhaarData> getAadhaarData(@PathVariable String aadhaarNumber) {
        // Fetch Aadhaar data from the service
        Optional<AadhaarData> optionalData = aadhaarService.getAadhaarData(aadhaarNumber);

        // Check if data exists
        if (optionalData.isPresent()) {
            AadhaarData aadhaarData = optionalData.get();

            // Mask Aadhaar number before returning
            String maskedAadhaarNumber = AadhaarService.halfMaskAadhaar(aadhaarData.getAadhaarNumber());
            aadhaarData.setAadhaarNumber(maskedAadhaarNumber);

            String maskedOtp = AadhaarService.maskOtp(aadhaarData.getOtp());
            aadhaarData.setOtp(maskedOtp);
            
            return ResponseEntity.ok(aadhaarData); // Return 200 OK with masked Aadhaar data
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null); // Return 404 if Aadhaar data is not found
        }
    }

}
