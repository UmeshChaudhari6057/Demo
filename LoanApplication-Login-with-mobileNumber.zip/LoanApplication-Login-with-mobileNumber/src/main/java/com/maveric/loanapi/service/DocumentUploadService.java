package com.maveric.loanapi.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.loanapi.model.UploadedDocument;
import com.maveric.loanapi.repository.UploadedDocumentRepository;




@Service
public class DocumentUploadService {

    @Value("${document.upload.directory}")
    private String uploadDirectory;

    private final UploadedDocumentRepository documentRepository;

    public DocumentUploadService(UploadedDocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    public String saveFile(MultipartFile file, String documentType) throws IOException {
        // Define the upload directory
        File directory = new File(uploadDirectory);
        if (!directory.exists()) {
            directory.mkdirs(); // Create directory if it does not exist
        }

        // Create a unique file name
        String fileName = documentType + "_" + System.currentTimeMillis() + "_" + file.getOriginalFilename();
        File uploadFile = new File(directory, fileName);

        // Save file to disk
        try (FileOutputStream outputStream = new FileOutputStream(uploadFile)) {
            outputStream.write(file.getBytes());
        }

        // Save metadata to the database
        UploadedDocument document = new UploadedDocument();
        document.setDocumentType(documentType);
        document.setFilePath(uploadFile.getAbsolutePath());
        document.setUploadTime(LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        documentRepository.save(document);

        return fileName;
    }
}

