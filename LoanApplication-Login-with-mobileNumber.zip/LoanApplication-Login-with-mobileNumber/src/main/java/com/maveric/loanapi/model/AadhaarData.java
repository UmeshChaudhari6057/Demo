package com.maveric.loanapi.model;

import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.Id;
import java.util.UUID;

import org.hibernate.annotations.GenericGenerator;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AadhaarData {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID aadhaarId;

    @Column(unique = true, nullable = false, length = 12)
    private String aadhaarNumber;

    private String name;
    private String dob;
    private String otp; // Mock OTP

    // Getters and setters
}
