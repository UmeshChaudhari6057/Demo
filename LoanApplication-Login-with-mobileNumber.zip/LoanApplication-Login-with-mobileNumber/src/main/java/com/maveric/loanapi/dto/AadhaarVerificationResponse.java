package com.maveric.loanapi.dto;

public class AadhaarVerificationResponse {
    private boolean isValid;
    private String message;

    // Getters and Setters
    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean valid) {
        isValid = valid;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
