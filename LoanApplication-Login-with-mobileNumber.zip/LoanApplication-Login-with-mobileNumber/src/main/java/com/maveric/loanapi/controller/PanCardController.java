package com.maveric.loanapi.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.loanapi.dto.PanVerificationRequest;
import com.maveric.loanapi.dto.PanVerificationResponse;
import com.maveric.loanapi.service.PanCardService;


@RestController
@RequestMapping("/api/pan")
public class PanCardController {
    @Autowired
    private PanCardService panCardService;

    
    @PostMapping("/verify")
    public PanVerificationResponse verifyPan(@RequestBody PanVerificationRequest panCardRequest) {
        return panCardService.verifyPan(panCardRequest);
    }
}

