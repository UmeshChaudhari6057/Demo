package com.maveric.loanapi.dto;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PanVerificationRequest {
    
    private String panNumber; // PAN number provided by the customer
    private String userName;  // Name of the customer
    private String dob;       // Date of Birth of the customer
    private String userIp;      // User's IP address
    private String mobileNumber; // User's Mobile Number
  
}