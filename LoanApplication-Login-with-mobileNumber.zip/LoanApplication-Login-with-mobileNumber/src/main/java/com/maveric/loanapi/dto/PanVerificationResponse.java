package com.maveric.loanapi.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PanVerificationResponse {
 //   private Object details; // This can hold either detailed success data or an error message
	    private String panNumber;
	    private String status;
	    private LocalDateTime verificationDate;
	    private String failureReason;

	    public PanVerificationResponse(String status, String message) {
	        this.status = status;
	        this.failureReason = message;  // Use failureReason to store the message
	    }
    
}

