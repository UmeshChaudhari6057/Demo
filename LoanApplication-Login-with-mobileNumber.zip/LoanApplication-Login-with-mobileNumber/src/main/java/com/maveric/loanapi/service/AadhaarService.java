package com.maveric.loanapi.service;



import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.loanapi.dto.AadhaarVerificationRequest;
import com.maveric.loanapi.dto.AadhaarVerificationResponse;
import com.maveric.loanapi.model.AadhaarData;
import com.maveric.loanapi.model.AuditLog;
import com.maveric.loanapi.repository.AadhaarRepository;
import com.maveric.loanapi.repository.AuditLogRepository;

@Service
public class AadhaarService {
	private final AadhaarRepository aadhaarRepository;

	private final AuditLogRepository auditLogRepository;
	
    @Autowired
    public AadhaarService(AadhaarRepository aadhaarRepository , AuditLogRepository auditLogRepository) {
        this.aadhaarRepository = aadhaarRepository;
        this.auditLogRepository = auditLogRepository;
    }

//    public AadhaarVerificationResponse verifyAadhaar(AadhaarVerificationRequest request , HttpServletRequest httpRequest) {
//        // Validate Aadhaar number format
//        if (request.getAadhaarNumber() == null || !request.getAadhaarNumber().matches("\\d{12}")) {
//            throw new IllegalArgumentException("Invalid Aadhaar number. It must be 12 digits.");
//        }
//
//        // Validate OTP presence
//        if (request.getOtp() == null || request.getOtp().isBlank()) {
//            throw new IllegalArgumentException("OTP cannot be blank.");
//        }
//
//        // Validate OTP format
//        if (!request.getOtp().matches("\\d{6}")) {
//            throw new IllegalArgumentException("OTP should be 6 digits.");
//        }
//
//        // Check if the Aadhaar number exists in the database
//        Optional<AadhaarData> aadhaarData = aadhaarRepository.findByAadhaarNumber(request.getAadhaarNumber());
//
//        AadhaarVerificationResponse response = new AadhaarVerificationResponse();
//
//        AuditLog auditLog = new AuditLog();
//        auditLog.setAadhaarNumber(halfMaskAadhaar(request.getAadhaarNumber())); // Mask Aadhaar number
//        auditLog.setRequestTime(LocalDateTime.now());
//        auditLog.setUserIp(httpRequest.getRemoteAddr());
//         
//        
//        if (aadhaarData.isPresent()) {
//            // If Aadhaar number exists, check the OTP for the verification
//            AadhaarData data = aadhaarData.get();
//
//            // For demonstration, assume OTP verification logic is simple. You may add a more robust logic.
//            if (data.getOtp().equals(request.getOtp())) {
//                response.setValid(true);
//                response.setMessage("Aadhaar verification successful.");
//                auditLog.setVerificationStatus("Success");
//                auditLog.setOtpStatus("Matched");
//            } else {
//                response.setValid(false);
//                response.setMessage("Invalid OTP.");
//                auditLog.setVerificationStatus("Failed");
//                auditLog.setOtpStatus("Mismatched");
//            }
//        } else {
//            response.setValid(false);
//            response.setMessage("Aadhaar number not found.");
//            auditLog.setVerificationStatus("Failed");
//            auditLog.setOtpStatus("Not Found");
//        }
//
//        
//        auditLogRepository.save(auditLog);
//        return response;
//    }
//    
    
    
    public AadhaarVerificationResponse verifyAadhaar(AadhaarVerificationRequest request, HttpServletRequest httpRequest) {
        AuditLog auditLog = new AuditLog();
        auditLog.setAadhaarNumber(halfMaskAadhaar(request.getAadhaarNumber())); // Mask Aadhaar number
        auditLog.setRequestTime(LocalDateTime.now());
        auditLog.setUserIp(httpRequest.getRemoteAddr());

        AadhaarVerificationResponse response = new AadhaarVerificationResponse();

        try {
            // Validate Aadhaar number
            if (request.getAadhaarNumber() == null || !request.getAadhaarNumber().matches("\\d{12}")) {
                auditLog.setVerificationStatus("Failed");
                auditLog.setOtpStatus("Invalid Aadhaar Number");
                auditLogRepository.save(auditLog);
                throw new IllegalArgumentException("Invalid Aadhaar number. It must be 12 digits.");
            }

            // Validate OTP presence
            if (request.getOtp() == null || request.getOtp().isBlank()) {
                auditLog.setVerificationStatus("Failed");
                auditLog.setOtpStatus("Blank OTP");
                auditLogRepository.save(auditLog);
                throw new IllegalArgumentException("OTP cannot be blank.");
            }

            // Validate OTP format
            if (!request.getOtp().matches("\\d{6}")) {
                auditLog.setVerificationStatus("Failed");
                auditLog.setOtpStatus("Invalid OTP Format");
                auditLogRepository.save(auditLog);
                throw new IllegalArgumentException("OTP should be 6 digits.");
            }

            // Check if Aadhaar number exists
            Optional<AadhaarData> aadhaarData = aadhaarRepository.findByAadhaarNumber(request.getAadhaarNumber());

            if (aadhaarData.isPresent()) {
                AadhaarData data = aadhaarData.get();
                if (data.getOtp().equals(request.getOtp())) {
                    // Success
                    response.setValid(true);
                    response.setMessage("Aadhaar verification successful.");
                    auditLog.setVerificationStatus("Success");
                    auditLog.setOtpStatus("Matched");
                } else {
                    // OTP mismatch
                    response.setValid(false);
                    response.setMessage("Invalid OTP.");
                    auditLog.setVerificationStatus("Failed");
                    auditLog.setOtpStatus("Mismatched");
                }
            } else {
                // Aadhaar not found
                response.setValid(false);
                response.setMessage("Aadhaar number not found.");
                auditLog.setVerificationStatus("Failed");
                auditLog.setOtpStatus("Not Found");
            }
        } catch (Exception e) {
            // General error handling
            response.setValid(false);
            response.setMessage(e.getMessage());
        } finally {
            // Save the audit log in all cases
            auditLogRepository.save(auditLog);
        }

        return response;
    }
    public Optional<AadhaarData> getAadhaarData(String aadhaarNumber) {
        // Fetch Aadhaar data based on Aadhaar number
        return aadhaarRepository.findByAadhaarNumber(aadhaarNumber);
    }

    public static String halfMaskAadhaar(String aadhaarNumber) {
        // Mask Aadhaar number to show only the first 6 digits
        if (aadhaarNumber != null && aadhaarNumber.length() == 12) {
            return aadhaarNumber.substring(0, 6) + "******";
        }
        return aadhaarNumber;
    }
    
    public static String maskOtp(String otp) {
        // Completely mask the OTP
        if (otp != null && otp.length() == 6) {
            return "******";
        }
        return otp; // Return original if invalid
    }
    
    }

