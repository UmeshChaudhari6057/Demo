package com.maveric.loanapi.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.loanapi.dto.PanVerificationRequest;
import com.maveric.loanapi.dto.PanVerificationResponse;
import com.maveric.loanapi.model.PanCard;
import com.maveric.loanapi.model.PanCardAudit;
import com.maveric.loanapi.repository.PanCardAuditRepository;
import com.maveric.loanapi.repository.PanCardRepository;

@Service
public class PanCardServiceImpl implements PanCardService {

    @Autowired
    private PanCardRepository panCardRepository;

    @Autowired
    private PanCardAuditRepository panCardAuditRepository;

    @Override
    public PanVerificationResponse verifyPan(PanVerificationRequest request) {
        String panNumber = request.getPanNumber();
        Optional<PanCard> existingPan = panCardRepository.findByPanNumber(panNumber);

        if (existingPan.isPresent()) {
            // PAN exists: Add "Verified" entry to audit table
            PanCard panCard = existingPan.get();
            storeAuditRecord(panNumber, "Verified", null, request.getUserIp(), panCard.getUserName(), panCard.getMobileNumber());

            // Return successful response with all required fields
            return new PanVerificationResponse(
                    panNumber,               // Set panNumber
                    "Verified",              // Set status
                    LocalDateTime.now(),     // Set verificationDate to current time
                    null                      // No failure reason, since it's verified
            );
        } else {
            // PAN does not exist: Add "Unverified" entry to audit table
            storeAuditRecord(panNumber, "Unverified", "PAN number not found in database", request.getUserIp(), null, request.getMobileNumber());

            // Return failure response with all required fields
            return new PanVerificationResponse(
                    panNumber,               // Set panNumber
                    "Unverified",            // Set status
                    null,                    // No verificationDate for unverified PAN
                    "PAN number not found in database"  // Set failureReason
            );
        }
    }

    private void storeAuditRecord(String panNumber, String status, String failureReason, String userIp, String userName, String mobileNumber) {
        PanCardAudit audit = new PanCardAudit();
        audit.setPanNumber(panNumber);
        audit.setStatus(status);
        audit.setFailureReason(failureReason);
        audit.setUserIp(userIp);
        audit.setRequestTime(LocalDateTime.now());
        audit.setVerificationDate(status.equals("Verified") ? LocalDateTime.now() : null);
        audit.setUserName(userName);
        audit.setMobileNumber(mobileNumber);
        panCardAuditRepository.save(audit);
    }
}

