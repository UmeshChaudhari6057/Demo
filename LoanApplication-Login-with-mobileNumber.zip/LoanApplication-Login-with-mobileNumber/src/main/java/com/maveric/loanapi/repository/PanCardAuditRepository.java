package com.maveric.loanapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maveric.loanapi.model.PanCardAudit;



@Repository
public interface PanCardAuditRepository extends JpaRepository<PanCardAudit, Long> {
    // Additional custom query methods (if needed) can be defined here.
}
