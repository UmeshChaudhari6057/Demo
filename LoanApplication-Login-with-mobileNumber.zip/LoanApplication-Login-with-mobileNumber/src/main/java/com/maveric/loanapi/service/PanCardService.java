package com.maveric.loanapi.service;

import com.maveric.loanapi.dto.PanVerificationRequest;
import com.maveric.loanapi.dto.PanVerificationResponse;

public interface PanCardService {
	PanVerificationResponse verifyPan(PanVerificationRequest request);
}

