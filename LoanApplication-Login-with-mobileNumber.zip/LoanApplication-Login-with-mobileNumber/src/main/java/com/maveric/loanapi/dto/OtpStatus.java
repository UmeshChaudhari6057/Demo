package com.maveric.loanapi.dto;

public enum OtpStatus {
    DELIVERED,
    FAILED
}
