package com.maveric.loanapi.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.loanapi.service.DocumentUploadService;

@RestController
@RequestMapping("/api/documents")
public class DocumentUploadController {

    private final DocumentUploadService documentUploadService;

    @Autowired
    public DocumentUploadController(DocumentUploadService documentUploadService) {
        this.documentUploadService = documentUploadService;
    }

    @PostMapping(value = "/documents/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadDocument(
            @RequestParam("documentType") String documentType,
            @RequestParam("file") MultipartFile file) {
        try {
            // Validate inputs
            if (file.isEmpty() || documentType == null || documentType.isBlank()) {
                return ResponseEntity.badRequest().body("Invalid input: documentType or file is missing.");
            }

            // Process the file upload logic
            String savedFileName = saveFile(file, documentType);

            return ResponseEntity.ok("File uploaded successfully with name: " + savedFileName);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error occurred: " + e.getMessage());
        }
    }

    // Implement saveFile method
    private String saveFile(MultipartFile file, String documentType) throws IOException {
        // Define the directory to save files (e.g., create "uploads" folder in the project directory)
        String uploadDir = "C:\\Users\\umeshch\\Downloads\\New folder\\" + documentType;

        // Create directory if it doesn't exist
        Path uploadPath = Paths.get(uploadDir);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Generate a unique file name
        String originalFilename = file.getOriginalFilename();
        String savedFileName = System.currentTimeMillis() + "_" + originalFilename;

        // Save the file to the directory
        Path filePath = uploadPath.resolve(savedFileName);
        file.transferTo(filePath.toFile());

        return savedFileName; // Return the saved file name
    }
}


