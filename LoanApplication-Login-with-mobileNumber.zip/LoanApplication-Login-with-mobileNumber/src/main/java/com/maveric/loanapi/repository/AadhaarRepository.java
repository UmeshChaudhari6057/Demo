package com.maveric.loanapi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.loanapi.model.AadhaarData;

public interface AadhaarRepository extends JpaRepository<AadhaarData, Long> {
    Optional<AadhaarData> findByAadhaarNumber(String aadhaarNumber);
}
