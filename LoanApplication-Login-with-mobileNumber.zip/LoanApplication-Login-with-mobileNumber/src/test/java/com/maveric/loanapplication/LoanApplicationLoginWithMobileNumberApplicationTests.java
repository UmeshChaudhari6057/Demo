package com.maveric.loanapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanApplicationLoginWithMobileNumberApplicationTests {

	@Test
	void contextLoads() {
	}

}
