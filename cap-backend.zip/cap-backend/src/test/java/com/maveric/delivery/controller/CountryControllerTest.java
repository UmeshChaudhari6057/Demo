package com.maveric.delivery.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.Entity.Country;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.CountryService;

@WebMvcTest(CountryController.class)
@ExtendWith(SpringExtension.class)
class CountryControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private CountryController countryController;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CountryService countryService;
    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    private AzureUsermysqlRepository azureUserRepository;

    @MockBean
    AuditImpl auditImpl;


    @Test
    void testGetAllCountries() throws Exception {
        List<Country> countries = new ArrayList<>();
        countries.add(new Country("India", "IN"));
        countries.add(new Country("Canada", "CAN"));

        when(countryService.getAllCountries()).thenReturn(countries);

        MvcResult mvcResult = mockMvc.perform(get("/v1/countries")).andReturn();
        ResponseDto responseDto = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ResponseDto.class);

        assertEquals("Success", responseDto.getStatus());
        verify(countryService, times(1)).getAllCountries();
    }

    @Test
    void testGetAllCountriesEmptyList() throws Exception {
        when(countryService.getAllCountries()).thenReturn(Collections.emptyList());

        MvcResult mvcResult = mockMvc.perform(get("/v1/countries")).andReturn();
        ResponseDto responseDto = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ResponseDto.class);

        assertEquals("Success", responseDto.getStatus());
        assertEquals(Collections.emptyList(), responseDto.getPayload());
    }
}
