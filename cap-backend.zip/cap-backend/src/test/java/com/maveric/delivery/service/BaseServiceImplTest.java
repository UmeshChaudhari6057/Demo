package com.maveric.delivery.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.maveric.delivery.exception.BaseTypeNotFoundException;
import com.maveric.delivery.Entity.ArtifactType;
import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.EngagementType;
import com.maveric.delivery.Entity.Frequency;
import com.maveric.delivery.Entity.Location;
import com.maveric.delivery.Entity.ProjectRole;
import com.maveric.delivery.Entity.ProjectStatus;
import com.maveric.delivery.mysqlrepository.ProjectRolemysqlRepository;
import com.maveric.delivery.mysqlrepository.ArtifactTypemysqlRepository;
import com.maveric.delivery.mysqlrepository.BusinessSubverticalmysqlRepository;
import com.maveric.delivery.mysqlrepository.EngagementTypemysqlRepository;
import com.maveric.delivery.mysqlrepository.FrequencymysqlRepository;
import com.maveric.delivery.mysqlrepository.LocationmysqlRepository;
import com.maveric.delivery.mysqlrepository.ProjectStatusmysqlRepository;
import com.maveric.delivery.responsedto.BaseDto;

class BaseServiceImplTest {

    @Mock
    private FrequencymysqlRepository frequencyRepository;

    @Mock
    private BusinessSubverticalmysqlRepository businessSubverticalRepository;

    @Mock
    private EngagementTypemysqlRepository engagementTypeRepository;
    @Mock
    private ProjectStatusmysqlRepository projectStatusRepository;

    @Mock
    private LocationmysqlRepository locationRepository;

    @Mock
    private ArtifactTypemysqlRepository artifactTypeRepository;

    @Mock
    private ProjectRolemysqlRepository projectRoleRepository;

    @InjectMocks
    private BaseServiceImpl baseService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFetchAllBaseTypes()
    {
        List<Frequency> frequencyList = new ArrayList<>();
        frequencyList.add(new Frequency(1L, "frequency1",10));
        frequencyList.add(new Frequency(2L, "frequency2",20));

        List<EngagementType> engagementTypeList = new ArrayList<>();
        engagementTypeList.add(new EngagementType(1L, "engagementType1"));
        engagementTypeList.add(new EngagementType(2L, "engagementType2"));

        List<BusinessSubvertical> businessSubverticalList = new ArrayList<>();
        businessSubverticalList.add(new BusinessSubvertical(1L, "businessSubvertica1"));
        businessSubverticalList.add(new BusinessSubvertical(2L, "businessSubvertica2"));
        List<Location> locationsList = new ArrayList<>();
        locationsList.add(new Location(1L,"location1"));
        locationsList.add(new Location(2L,"location2"));

        List<ProjectRole> projectRoleList =  new ArrayList<>();
        projectRoleList.add(new ProjectRole(1L,"projectRole1"));
        projectRoleList.add(new ProjectRole(2L,"projectRole2"));

        List<ArtifactType> artifactTypeList = new ArrayList<>();
        artifactTypeList.add(new ArtifactType(1L,"artifactType1"));
        artifactTypeList.add(new ArtifactType(2L,"artifactType2"));

        when(frequencyRepository.findAll()).thenReturn(frequencyList);
        when(engagementTypeRepository.findAll()).thenReturn(engagementTypeList);
        when(businessSubverticalRepository.findAll()).thenReturn(businessSubverticalList);
        when(locationRepository.findAll()).thenReturn(locationsList);
        when(projectRoleRepository.findAll()).thenReturn(projectRoleList);
        when(artifactTypeRepository.findAll()).thenReturn(artifactTypeList);

        List<BaseDto> result = baseService.fetchAllTypes("frequency");
        List<BaseDto> result1 = baseService.fetchAllTypes("engagement-type");
        List<BaseDto> result2 = baseService.fetchAllTypes("business-subvertical");
        List<BaseDto> result3 = baseService.fetchAllTypes("Location");
        List<BaseDto> result4 = baseService.fetchAllTypes("Project-Role");
        List<BaseDto> result5 = baseService.fetchAllTypes("Artifact-Type");

        assertEquals(frequencyList.size(), result.size());
        assertEquals(engagementTypeList.size(), result1.size());
        assertEquals(businessSubverticalList.size(), result2.size());
        assertEquals(locationsList.size(), result3.size());
        assertEquals(locationsList.size(), result4.size());
        assertEquals(locationsList.size(), result5.size());

        verify(frequencyRepository, times(1)).findAll();
        verify(engagementTypeRepository, times(1)).findAll();
        verify(businessSubverticalRepository, times(1)).findAll();
        verify(locationRepository, times(1)).findAll();
        verify(artifactTypeRepository, times(1)).findAll();
        verify(projectRoleRepository, times(1)).findAll();
    }

    @Test
    void testFetchAllTypesWithInvalidType() {
        assertThrows(BaseTypeNotFoundException.class, () -> baseService.fetchAllTypes("invalid-type"));
    }

    @Test
    void fetchAllProjectStatus()
    {
        List<ProjectStatus> projectStatusList= new ArrayList<>();
        projectStatusList.add(new ProjectStatus(1L,"TemplateName1"));
        projectStatusList.add(new ProjectStatus(2L,"TemplateName2"));

        when(projectStatusRepository.findAll()).thenReturn(projectStatusList);
        List<BaseDto> result = baseService.fetchAllProjectStatus();
        assertEquals(projectStatusList.size(),result.size());
        verify(projectStatusRepository, times(1)).findAll();

    }

    @Test
    public void testSaveArtifactType() {
        String name = "Test Artifact";
        ArtifactType artifactType = new ArtifactType();
        artifactType.setName(name);
        when(artifactTypeRepository.save(artifactType)).thenReturn(artifactType);
        BaseDto result = baseService.saveArtifactType(name);
        verify(artifactTypeRepository).save(artifactType);
        assertEquals(name, result.getName());
        assertEquals(artifactType.getId(), result.getId());
    }

    @Test
    public void testsaveLocation() {
        String name = "Test Location";
        Location location = new Location();
        location.setName(name);
        when(locationRepository.save(location)).thenReturn(location);
        BaseDto result = baseService.saveLocation(name);
        verify(locationRepository).save(location);
        assertEquals(name, result.getName());
        assertEquals(location.getId(), result.getId());
    }

    @Test
    public void testsaveProjectRole() {
        String name = "Test ProjectRole";
        ProjectRole projectRole = new ProjectRole();
        projectRole.setName(name);
        when(projectRoleRepository.save(projectRole)).thenReturn(projectRole);
        BaseDto result = baseService.saveProjectRole(name);
        verify(projectRoleRepository).save(projectRole);
        assertEquals(name, result.getName());
        assertEquals(projectRole.getId(), result.getId());
    }
}
