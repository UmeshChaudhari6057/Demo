package com.maveric.delivery.service;

import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Assessment;
import com.maveric.delivery.Entity.AssessmentHistory;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.DeliveryInformation;
import com.maveric.delivery.requestdto.DashboardFilterDto;
import com.maveric.delivery.requestdto.DateRangeDto;
import com.maveric.delivery.responsedto.AssessmentDetailsDto;
import com.maveric.delivery.responsedto.DashboardDetailsDto;
import com.maveric.delivery.responsedto.AssessmentTrendsDetailsDto;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static com.maveric.delivery.utils.Constants.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class DashboardServiceImplTest {

    @MockBean
    private JwtDecoder jwtDecoder;

    @Mock
    private UtilMethods utilMethods;

//    @Mock
//    private MongoTemplate mongoTemplate;

    @InjectMocks
    private DashboardServiceImpl dashboardService;

    @Test
    void fetchDashboardDetails_ALL_Success() {

        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setAccountId(1L);
        dashboardFilterDto.setProjectId(1L);
        dashboardFilterDto.setDateRange(ALL);
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account());
        List<Project> projects = new ArrayList<>();
        Project project = new Project();
        project.setId(1L);
        project.setProjectName("Project A");
        project.setCustomerLOB("Finance");
        project.setIsBillable(true);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        deliveryInformation.setProjectType("example1");
        project.setDeliveryInfo(deliveryInformation);
        projects.add(project);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());

     // Commented out MongoDB code

//        when(mongoTemplate.find(any(Query.class), eq(Account.class))).thenReturn(accounts);
//        when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(projects);
//        when(mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class),eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        DashboardDetailsDto dashboardDetailsDto = dashboardService.fetchDashboardDetails(dashboardFilterDto);
//        assertNotNull(dashboardDetailsDto);
    }

    @Test
    void fetchDashboardDetails_LAST_3_MONTHS_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        DateRangeDto dateRangeDto = new DateRangeDto();
        dashboardFilterDto.setDateRange(LAST_3_MONTHS);
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account());
        List<Project> projects = new ArrayList<>();
        Project project = new Project();
        project.setId(1L);
        project.setProjectName("Project A");
        project.setCustomerLOB("Finance");
        project.setIsBillable(true);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        deliveryInformation.setProjectType("example1");
        project.setDeliveryInfo(deliveryInformation);
        projects.add(project);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
     // Commented out MongoDB code

//
//        when(mongoTemplate.find(any(Query.class), eq(Account.class))).thenReturn(accounts);
//        when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(projects);
//        when(mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class),eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when(utilMethods.getDateRange(any(String.class))).thenReturn(dateRangeDto);

        DashboardDetailsDto dashboardDetailsDto = dashboardService.fetchDashboardDetails(dashboardFilterDto);
        assertNotNull(dashboardDetailsDto);
    }


    @Test
    void fetchDashboardDetails_LAST_6_MONTHS_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setDateRange(LAST_6_MONTHS);
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account());
        List<Project> projects = new ArrayList<>();
        Project project = new Project();
        project.setId(1L);
        project.setProjectName("Project A");
        project.setCustomerLOB("Finance");
        project.setIsBillable(true);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        deliveryInformation.setProjectType("example1");
        project.setDeliveryInfo(deliveryInformation);
        projects.add(project);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        DateRangeDto dateRangeDto = new DateRangeDto();
//        when(mongoTemplate.find(any(Query.class), eq(Account.class))).thenReturn(accounts);
//        when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(projects);
//        when(mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class),eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when(utilMethods.getDateRange(any(String.class))).thenReturn(dateRangeDto);
        DashboardDetailsDto dashboardDetailsDto = dashboardService.fetchDashboardDetails(dashboardFilterDto);
        assertNotNull(dashboardDetailsDto);
    }


    @Test
    void fetchDashboardDetails_LAST_1_YEAR_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setAccountId(1L);
        dashboardFilterDto.setProjectId(1L);
        dashboardFilterDto.setDateRange(LAST_1_YEAR);
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account());
        List<Project> projects = new ArrayList<>();
        Project project = new Project();
        project.setId(1L);
        project.setProjectName("Project A");
        project.setCustomerLOB("Finance");
        project.setIsBillable(true);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        deliveryInformation.setProjectType("example1");
        project.setDeliveryInfo(deliveryInformation);
        projects.add(project);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        DateRangeDto dateRangeDto = new DateRangeDto();
//        when(mongoTemplate.find(any(Query.class), eq(Account.class))).thenReturn(accounts);
//        when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(projects);
//        when(mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class),eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when(utilMethods.getDateRange(any(String.class))).thenReturn(dateRangeDto);
        DashboardDetailsDto dashboardDetailsDto = dashboardService.fetchDashboardDetails(dashboardFilterDto);
        assertNotNull(dashboardDetailsDto);
    }

    @Test
    void fetchDashboardDetails_LAST_2_YEAR_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setDateRange(LAST_2_YEAR);
        List<Account> accounts = new ArrayList<>();
        accounts.add(new Account());
        List<Project> projects = new ArrayList<>();
        Project project = new Project();
        project.setId(1L);
        project.setProjectName("Project A");
        project.setCustomerLOB("Finance");
        project.setIsBillable(true);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        deliveryInformation.setProjectType("example1");
        project.setDeliveryInfo(deliveryInformation);
        projects.add(project);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        DateRangeDto dateRangeDto = new DateRangeDto();
//        when(mongoTemplate.find(any(Query.class), eq(Account.class))).thenReturn(accounts);
//        when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(projects);
//        when(mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class),eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when(utilMethods.getDateRange(any(String.class))).thenReturn(dateRangeDto);
        DashboardDetailsDto dashboardDetailsDto = dashboardService.fetchDashboardDetails(dashboardFilterDto);
        assertNotNull(dashboardDetailsDto);
    }

    @Test
    void fetchTopAssessment() {
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);
        List<Account> accounts = new ArrayList<>();
        Account account = new Account();
        account.setId(1L);
        account.setAccountName("test");
        accounts.add(account);
//        when( mongoTemplate.find(any(Query.class),eq(Account.class))).thenReturn(accounts);
//        when(mongoTemplate.find(any(Query.class),eq(Assessment.class))).thenReturn(assessments);
//        when(mongoTemplate.findById(any(Long.class), eq(Account.class))).thenReturn(account);
        AssessmentDetailsDto assessmentDetailsDto = dashboardService.fetchTopAssessment();
        assertNotNull(assessmentDetailsDto);

    }

    @Test
    void fetchDashboardTrendsDetails_ALL_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setAccountId(1L);
        dashboardFilterDto.setProjectId(1L);
        dashboardFilterDto.setDateRange(ALL);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);

//        when(mongoTemplate.exists(any(Query.class),eq(Assessment.class))).thenReturn(true);
//
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);

        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = dashboardService.fetchDashboardTrendsDetails(dashboardFilterDto);
        assertNotNull(assessmentTrendsDetailsDto);
    }

    @Test
    void fetchDashboardTrendsDetails_LAST_3_MONTHS_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setDateRange(LAST_3_MONTHS);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);
//        when(mongoTemplate.exists(any(Query.class),eq(Assessment.class))).thenReturn(true);
//
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);

        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = dashboardService.fetchDashboardTrendsDetails(dashboardFilterDto);
        assertNotNull(assessmentTrendsDetailsDto);
    }


    @Test
    void fetchDashboardTrendsDetails_LAST_6_MONTHS_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setDateRange(LAST_6_MONTHS);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);
//        when(mongoTemplate.exists(any(Query.class),eq(Assessment.class))).thenReturn(true);
//
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);

        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = dashboardService.fetchDashboardTrendsDetails(dashboardFilterDto);
        assertNotNull(assessmentTrendsDetailsDto);
    }


    @Test
    void fetchDashboardTrendsDetails_LAST_1_YEAR_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setDateRange(LAST_1_YEAR);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);
//        when(mongoTemplate.exists(any(Query.class),eq(Assessment.class))).thenReturn(true);
//
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);

        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = dashboardService.fetchDashboardTrendsDetails(dashboardFilterDto);
        assertNotNull(assessmentTrendsDetailsDto);
    }

    @Test
    void fetchDashboardTrendsDetails_LAST_2_YEAR_Success() {
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();;
        dashboardFilterDto.setDateRange(LAST_2_YEAR);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);
//        when(mongoTemplate.exists(any(Query.class),eq(Assessment.class))).thenReturn(true);
//
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);

        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = dashboardService.fetchDashboardTrendsDetails(dashboardFilterDto);
        assertNotNull(assessmentTrendsDetailsDto);
    }

}