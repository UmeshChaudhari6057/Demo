package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.requestdto.DashboardFilterDto;
import com.maveric.delivery.responsedto.*;
import com.maveric.delivery.service.AccountService;
import com.maveric.delivery.service.DashboardService;
import com.maveric.delivery.service.ProjectService;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.ALL;
import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DashboardController.class)
@ExtendWith(SpringExtension.class)
class DashboardControllerTest {

    @MockBean
    private DashboardService dashboardService;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    private AccountService accountService;

    @MockBean
    private ProjectService projectService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private UtilMethods utilMethods;

    private final String oId = UUID.randomUUID().toString();

    @Test
    void fetchDashboardDetails_success() throws Exception {

        DashboardDetailsDto dashboardDetailsDto = new DashboardDetailsDto();
        DashboardFilterDto dashboardFilterDto = DashboardFilterDto.builder().build();
        dashboardFilterDto.setAccountId(1L);
        dashboardFilterDto.setProjectId(1L);
        dashboardFilterDto.setDateRange(ALL);
        when(dashboardService.fetchDashboardDetails(any(DashboardFilterDto.class))).thenReturn(dashboardDetailsDto);
        MockHttpServletRequestBuilder requestBuilder = post("/v1/dashboard").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dashboardFilterDto));
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<DashboardDetailsDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<DashboardDetailsDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1030", responseDto.getCode());
        assertEquals("Dashboard Details Fetched successfully", responseDto.getMessage());
        assertEquals(dashboardDetailsDto, responseDto.getPayload());
    }

    @Test
    void fetchDashboardTrendsDetails() throws Exception {

        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = new AssessmentTrendsDetailsDto();
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();
        dashboardFilterDto.setAccountId(1L);
        dashboardFilterDto.setProjectId(1L);
        dashboardFilterDto.setDateRange(ALL);
        when(dashboardService.fetchDashboardTrendsDetails(any(DashboardFilterDto.class))).thenReturn(assessmentTrendsDetailsDto);
        MockHttpServletRequestBuilder requestBuilder = post("/v1/dashboard/trends").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dashboardFilterDto));
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<AssessmentTrendsDetailsDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<AssessmentTrendsDetailsDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1031", responseDto.getCode());
        assertEquals("Dashboard Trends Details Fetched successfully", responseDto.getMessage());
        assertEquals(assessmentTrendsDetailsDto, responseDto.getPayload());
    }

    @Test
    void fetchTopAssessment() throws Exception {
        AssessmentDetailsDto assessmentDetailsDto = new AssessmentDetailsDto();
        DashboardFilterDto dashboardFilterDto =  DashboardFilterDto.builder().build();
        dashboardFilterDto.setAccountId(1L);
        dashboardFilterDto.setProjectId(1L);
        dashboardFilterDto.setDateRange(ALL);
        when(dashboardService.fetchTopAssessment()).thenReturn(assessmentDetailsDto);
        MockHttpServletRequestBuilder requestBuilder = get("/v1/dashboard/top-assessment").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<AssessmentDetailsDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<AssessmentDetailsDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1032", responseDto.getCode());
        assertEquals("Top Assessment Details Fetched successfully", responseDto.getMessage());
        assertEquals(assessmentDetailsDto, responseDto.getPayload());
    }

    @Test
    void fetchActiveAccounts() throws Exception {
        List<BaseDto> baseDtoList = new ArrayList<>();
        when(accountService.fetchActiveAccounts()).thenReturn(baseDtoList);
        MockHttpServletRequestBuilder requestBuilder = get("/v1/dashboard/accounts").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<List<BaseDto>> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<List<BaseDto>>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1033", responseDto.getCode());
        assertEquals("Active Accounts Details Fetched successfully", responseDto.getMessage());
        assertEquals(baseDtoList, responseDto.getPayload());
    }

    @Test
    void fetchActiveProjects() throws Exception {
        List<BaseDto> baseDtoList = new ArrayList<>();
        when(projectService.fetchActiveProjects(any(Long.class))).thenReturn(baseDtoList);
        MockHttpServletRequestBuilder requestBuilder = get("/v1/dashboard/projects").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .param("accountId", String.valueOf(1));
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<List<BaseDto>> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<List<BaseDto>>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1034", responseDto.getCode());
        assertEquals("Active Projects Details Fetched successfully", responseDto.getMessage());
        assertEquals(baseDtoList, responseDto.getPayload());
    }
}