package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.requestdto.AssessmentFilterDto;
import com.maveric.delivery.responsedto.AssessmentTrendsDetailsDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AssessmentService;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AssessmentController.class)
@AutoConfigureMockMvc
class AssessmentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;


    @MockBean
    private AssessmentService assessmentService;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    AuditImpl auditImpl;


    private final String oId = UUID.randomUUID().toString();

    @Test
    void fetchTrendsDetails_Success() throws Exception {
        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = new AssessmentTrendsDetailsDto();
        AssessmentFilterDto assessmentFilterDto = AssessmentFilterDto.builder().build();

        when(assessmentService.fetchTrendsDetails(any(UUID.class), any(AssessmentFilterDto.class), any(AssessmentRole.class))).thenReturn(assessmentTrendsDetailsDto);
        MockHttpServletRequestBuilder requestBuilder = post("/v1/assessments/trends").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .param("assessmentRole", String.valueOf(AssessmentRole.ALL))
                .content(objectMapper.writeValueAsString(assessmentFilterDto));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<AssessmentTrendsDetailsDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<AssessmentTrendsDetailsDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1035", responseDto.getCode());
        assertEquals("Assessment Trends Details Fetched successfully", responseDto.getMessage());
        assertEquals(assessmentTrendsDetailsDto, responseDto.getPayload());
    }
}