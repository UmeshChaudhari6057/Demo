package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.ACCOUNT_ADMIN_;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBER;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_ADD;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_EDIT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;
//import org.springframework.data.mongodb.core.MongoTemplate;

import com.maveric.delivery.exception.ProjectDateException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.exception.TeamMemberNotFoundException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.TeamMember;
import com.maveric.delivery.model.embedded.TeamMemberStatus;
import com.maveric.delivery.mysqlrepository.LocationmysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.mysqlrepository.TeamMembermysqlRepository;
import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.requestdto.TeamMemberFilterDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;
import com.maveric.delivery.utils.UtilMethods;

@ExtendWith(MockitoExtension.class)
class TeamMemberServiceTest {

    @InjectMocks
    private TeamMemberServiceImpl teamMemberService;

    @Mock
    private UtilMethods utilMethods;

    @Mock
    private TeamMembermysqlRepository teamMemberRepository;

    @Mock
    private ProjectRepository projectRepository;
    @Mock
    private DedRolesRepository dedRolesRepository;

    @Mock
    private LocationmysqlRepository locationRepository;

    @Mock
    AccountRepository accountRepository;

    @Mock
    private UserServiceImpl userService;

    private TeamMemberDto teamMemberDto;
    private TeamMember teamMember;
    private Project project;
    private Account account;
    private UUID userId;
    private Long projectId;
    private Long teamMemberId;
 //   private MongoTemplate mongoTemplate;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        projectId = 1L;
        teamMemberId = 1L;
        teamMemberDto = new TeamMemberDto();
        teamMemberDto.setStartDate(Instant.now().minusSeconds(3600).toEpochMilli());
        teamMemberDto.setEndDate(Instant.now().plusSeconds(3600).toEpochMilli());
        teamMemberDto.setProjectId(1L);
        teamMemberDto.setUserId(userId);
        teamMember = new TeamMember();
        BeanUtils.copyProperties(teamMemberDto, teamMember);
        teamMember.setId(1L);
        teamMember.setProjectId(1L);
        teamMember.setStatus(TeamMemberStatus.Active);

        project = new Project();
        project.setId(1L);
        project.setAccountId(1L);
        project.setStartDate(Instant.now().minusSeconds(7200).toEpochMilli());
        project.setEndDate(Instant.now().plusSeconds(7200).toEpochMilli());

        account = new Account();
        account.setAccountName("Test");
        account.setId(1L);

    }

    @Test
    void saveTeamMember() {
        Long accountId=1L;
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");
        when(userService.getHighestRole(userId, null, projectId)).thenReturn(ACCOUNT_ADMIN_);
        when(utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(TEAM_MEMBERS))).thenReturn(List.of(TEAM_MEMBERS_ADD));
     //   when(projectRepository.findById(projectId)).thenReturn(Optional.of(project));
        when(teamMemberRepository.save(any(TeamMember.class))).thenReturn(teamMember);
        TeamMemberResponseDto responseDto = teamMemberService.saveTeamMember(teamMemberDto, userId, projectId);

        assertThat(responseDto).isNotNull();
        verify(teamMemberRepository, times(1)).save(any(TeamMember.class));
    }

    @Test
    void saveTeamMemberThrowProjectNotFoundException() {
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");
       // when(projectRepository.findById(projectId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> teamMemberService.saveTeamMember(teamMemberDto, userId, projectId))
                .isInstanceOf(ProjectNotFoundException.class)
                .hasMessageContaining("Project with ID " + projectId + " not found");
    }

    @Test
    void getTeamMemberById() {
        when(teamMemberRepository.findById(teamMemberId)).thenReturn(Optional.of(teamMember));
      //  when(projectRepository.findById(teamMember.getProjectId())).thenReturn(Optional.of(project));
      //  when(accountRepository.findById(any(Long.class))).thenReturn(Optional.of(account));

        TeamMemberResponseListDto responseDto = teamMemberService.getTeamMemberById(teamMemberId);

        assertThat(responseDto).isNotNull();
        assertThat(responseDto.getId()).isEqualTo(teamMemberId);
        verify(teamMemberRepository, times(1)).findById(teamMemberId);
    }

    @Test
    void getTeamMemberById_ThrowTeamMemberNotFoundException() {
        when(teamMemberRepository.findById(teamMemberId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> teamMemberService.getTeamMemberById(teamMemberId))
                .isInstanceOf(TeamMemberNotFoundException.class)
                .hasMessageContaining("Team Member not found");
    }

    @Test
    void editTeamMember() {
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");
        when(userService.getHighestRole(userId, null, projectId)).thenReturn(ACCOUNT_ADMIN_);
        when(utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(TEAM_MEMBERS))).thenReturn(List.of(TEAM_MEMBERS_EDIT));
        when(teamMemberRepository.findById(teamMemberId)).thenReturn(Optional.of(teamMember));
   //     when(projectRepository.findById(teamMember.getProjectId())).thenReturn(Optional.of(project));
        when(teamMemberRepository.save(any(TeamMember.class))).thenReturn(teamMember);
        doNothing().when(dedRolesRepository).deleteByOidAndProject_IdAndRole(userId,projectId,TEAM_MEMBER);
        TeamMemberResponseDto responseDto = teamMemberService.editTeamMember(teamMemberDto, userId, teamMemberId);

        assertThat(responseDto).isNotNull();
        verify(teamMemberRepository, times(1)).save(any(TeamMember.class));
    }

    @Test
    void editTeamMemberThrowTeamMemberNotFoundException() {
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");
        when(teamMemberRepository.findById(teamMemberId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> teamMemberService.editTeamMember(teamMemberDto, userId, teamMemberId))
                .isInstanceOf(TeamMemberNotFoundException.class)
                .hasMessageContaining("Team Member with ID " + teamMemberId + " not found");
    }

    @Test
    void startAndEndDateValidator_ForStartDateBeforeProjectStartDate() {
        teamMemberDto.setStartDate(Instant.now().minusSeconds(10800).toEpochMilli());
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");
      //  when(projectRepository.findById(projectId)).thenReturn(Optional.of(project));
        when(userService.getHighestRole(userId, null, projectId)).thenReturn(ACCOUNT_ADMIN_);
        when(utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(TEAM_MEMBERS))).thenReturn(List.of(TEAM_MEMBERS_ADD));
        assertThatThrownBy(() -> teamMemberService.saveTeamMember(teamMemberDto, userId, projectId))
                .isInstanceOf(ProjectDateException.class)
                .hasMessageContaining("Member start date must be after Project start date");
    }


    @Test
    void startAndEndDateValidator_ForEndDateAfterProjectEndDate() {
        teamMemberDto.setEndDate(Instant.now().plusSeconds(10800).toEpochMilli());
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");
    //    when(projectRepository.findById(projectId)).thenReturn(Optional.of(project));
        when(userService.getHighestRole(userId, null, projectId)).thenReturn(ACCOUNT_ADMIN_);
        when(utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(TEAM_MEMBERS))).thenReturn(List.of(TEAM_MEMBERS_ADD));
        assertThatThrownBy(() -> teamMemberService.saveTeamMember(teamMemberDto, userId, projectId))
                .isInstanceOf(ProjectDateException.class)
                .hasMessageContaining("Member End date Must be before Project end date");
    }

    @Test
    void checkUserAuthenticityThrowUserNotFoundException() {
        when(utilMethods.getDisplayName(userId)).thenReturn("");

        assertThatThrownBy(() -> teamMemberService.checkUserAuthenticity(userId))
                .isInstanceOf(UserNotFoundException.class)
                .hasMessageContaining("User not found " + userId);
    }

    @Test
    void checkUserAuthenticity() {
        when(utilMethods.getDisplayName(userId)).thenReturn("Test User");

        teamMemberService.checkUserAuthenticity(userId);

        verify(utilMethods, times(1)).getDisplayName(userId);
    }

    @Test
    void startAndEndDateValidator_ForFutureStartDate() {
        Long futureDate = Instant.now().plusSeconds(86400).toEpochMilli();
        Long projectStartDate = Instant.now().minusSeconds(3600).toEpochMilli();
        Long projectEndDate = Instant.now().plusSeconds(3600).toEpochMilli();

        assertThatThrownBy(() -> teamMemberService.startAndEndDateValidator(futureDate, projectStartDate, futureDate, projectEndDate))
                .isInstanceOf(ProjectDateException.class)
                .hasMessageContaining("Future date is not allowed: start date must be a past or current date");
    }

    @Test
    void startAndEndDateValidator_ForStartDateAfterProjectEndDate() {
        Long memberStartDate = Instant.now().minus(5, ChronoUnit.DAYS).toEpochMilli();
        Long projectStartDate = Instant.now().minus(6, ChronoUnit.DAYS).toEpochMilli();
        Long memberEndDate = Instant.now().plus(7, ChronoUnit.DAYS).toEpochMilli();
        Long projectEndDate = Instant.now().plus(6, ChronoUnit.DAYS).toEpochMilli();

        assertThatThrownBy(() -> teamMemberService.startAndEndDateValidator(memberStartDate, projectStartDate, memberEndDate, projectEndDate))
                .isInstanceOf(ProjectDateException.class)
                .hasMessageContaining("Member End date Must be before Project end date");
    }

    @Test
    void startAndEndDateValidator_ForValidDates() {
        Long memberStartDate = Instant.now().minusSeconds(3600).toEpochMilli();
        Long projectStartDate = Instant.now().minusSeconds(7200).toEpochMilli();
        Long memberEndDate = Instant.now().plusSeconds(3600).toEpochMilli();
        Long projectEndDate = Instant.now().plusSeconds(7200).toEpochMilli();

        teamMemberService.startAndEndDateValidator(memberStartDate, projectStartDate, memberEndDate, projectEndDate);
    }

    @Test
    void toTeamMemberDtoList() {
        List<TeamMemberResponseListDto> responseList = teamMemberService.toTeamMemberDtoList(List.of(teamMember));

        assertThat(responseList).hasSize(1);
        assertThat(responseList.get(0).getId()).isEqualTo(teamMember.getId());
    }

    @Test
    void toTeamMemberResponseDto() {
        TeamMemberResponseListDto responseDto = teamMemberService.toTeamMemberResponseDto(teamMember);

        assertThat(responseDto).isNotNull();
        assertThat(responseDto.getId()).isEqualTo(teamMember.getId());
    }
    @Test
    void toTeamMemberDto() {
        String projectName = "Project X";
        String accountName = "Account Y";

        TeamMemberResponseListDto responseDto = teamMemberService.toTeamMemberDto(teamMember, projectName, accountName);

        assertThat(responseDto).isNotNull();
        assertThat(responseDto.getProjectName()).isEqualTo(projectName);
        assertThat(responseDto.getAccountName()).isEqualTo(accountName);
    }

    @Test
    void getAllSkills() {
        Long projectId = 1L;

        TeamMember teamMember1 = new TeamMember();
        teamMember1.setSkillSet(Arrays.asList("Java", "Spring"));

        TeamMember teamMember2 = new TeamMember();
        teamMember2.setSkillSet(Arrays.asList("Java", "MongoDB"));

        when(teamMemberRepository.findByProjectId(projectId)).thenReturn(List.of(teamMember1, teamMember2));

        Set<String> skills = teamMemberService.getAllSkills(projectId);

        assertNotNull(skills);
        assertEquals(3, skills.size());
        assertTrue(skills.containsAll(Arrays.asList("Java", "Spring", "MongoDB")));
        verify(teamMemberRepository, times(1)).findByProjectId(projectId);
    }

    @Test
    void getAllSkills_EmptyProject() {
        Long projectId = 1L;

        when(teamMemberRepository.findByProjectId(projectId)).thenReturn(List.of());

        Set<String> skills = teamMemberService.getAllSkills(projectId);

        assertNotNull(skills);
        assertTrue(skills.isEmpty());
        verify(teamMemberRepository, times(1)).findByProjectId(projectId);
    }

    @Test
    void getAllTeamMembers_ProjectNotFound() {
        UUID userId = UUID.randomUUID();
        Long projectId = 1L;
        TeamMemberFilterDto filter = new TeamMemberFilterDto();

  //      when(projectRepository.findById(projectId)).thenReturn(Optional.empty());

        ProjectNotFoundException exception = assertThrows(ProjectNotFoundException.class, () -> {
            teamMemberService.getAllTeamMembers(userId, projectId, filter);
        });

        assertEquals("Project with ID " + projectId + " not found", exception.getMessage());
  //      verify(projectRepository, times(1)).findById(projectId);
    }

}