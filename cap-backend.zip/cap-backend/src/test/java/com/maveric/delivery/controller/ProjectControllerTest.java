package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.requestdto.ProjectFilterDto;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.*;
import com.maveric.delivery.service.ProjectService;
import com.maveric.delivery.service.ProjectServiceImpl;
import com.maveric.delivery.service.ProjectServiceImplTest;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author ankushk
 */

@WebMvcTest(ProjectController.class)
@AutoConfigureMockMvc

public class ProjectControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;
    @MockBean
    private ProjectServiceImpl projectService;

    @MockBean
    private UtilMethods utilMethods;

    @Mock
    private ProjectService projectService1;

   /* @InjectMocks
    private ProjectController projectController;*/

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    DedRolesRepository dedRolesRepository;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    private final String oId = UUID.randomUUID().toString();


    @Test
    public void testGetAccountById_AccountFound_Success() throws Exception {

        ProjectResponseDto projectResponseDto = new ProjectResponseDto();
        projectResponseDto.setAccountId(1L);
        when(projectService.getProjectById(1L, UUID.randomUUID() )).thenReturn(projectResponseDto);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects/1").requestAttr(O_ID, oId)
                .header("userId", UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals("S-1011", responseDto.getCode());
        assertEquals("Project Fetched successfully", responseDto.getMessage());
        // assertNotNull(responseDto.getPayload());
    }

    @Test
    public void testSaveProject_Success() throws Exception {
        ProjectRequestDto requestDto = ProjectServiceImplTest.createSampleProjectRequestDto();
        ProjectResponseDto createdProject =new ProjectResponseDto();
        BeanUtils.copyProperties(requestDto,createdProject);
        createdProject.setProjectId(1L);

        when(projectService.saveProject(any(ProjectRequestDto.class),eq(UUID.fromString(oId)))).thenReturn(createdProject);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/v1/projects").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(ProjectServiceImplTest.createSampleProjectRequestDto()));
        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isCreated())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<ProjectResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals("S-1009", responseDto.getCode());
        assertEquals("Project created successfully", responseDto.getMessage());
        verify(projectService, times(1)).saveProject(any(ProjectRequestDto.class),eq(UUID.fromString(oId)));
    }


    @Test
    void testGetProjectList() throws Exception {
        // Mocking
        Long accountId = 123L;
        ProjectsListDto projectsListDto=new ProjectsListDto();
        List<ProjectListResponseDto> mockProjectList = Collections.singletonList(new ProjectListResponseDto());
        projectsListDto.setProjectListResponseDtos(mockProjectList);

        when(projectService.getProjectDetailsList(UUID.fromString(oId), accountId, new ProjectFilterDto())).thenReturn(projectsListDto);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects").requestAttr(O_ID, oId)
                .header("userId", UUID.randomUUID())
                .param("accountId",accountId.toString())
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(Constants.SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.PROJECT_LIST_FETCHED.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.PROJECT_LIST_FETCHED.getMessage(), responseDto.getMessage());
    }


    @Test
    void testFetchProjectNameList() throws Exception {
        Long accountId = 123L;
        BaseDto projectName = new BaseDto();
        List<BaseDto> projectNames = Collections.singletonList(projectName);

        when(utilMethods.stringToLong(anyString())).thenReturn(accountId);
        when(projectService.fetchAllProjectNames(any(UUID.class), eq(accountId), any(AssessmentRole.class))).thenReturn(projectNames);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects/filters/project-name")
                .requestAttr(O_ID, oId)
                .param("accountId", accountId.toString())
                .param("assessmentRole", ALL)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<List<BaseDto>> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.FETCH_PROJECT_NAMES.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.FETCH_PROJECT_NAMES.getMessage(), responseDto.getMessage());

        verify(projectService, times(1)).fetchAllProjectNames(any(UUID.class), eq(accountId), any(AssessmentRole.class));
    }

    @Test
    void testGetFilterMembers() throws Exception {
        Long accountId = 123L;
        FilterRolesResponseDto filterRolesResponseDto = new FilterRolesResponseDto();

        when(utilMethods.stringToLong(anyString())).thenReturn(accountId);
        when(projectService.getFilterMembers(any(UUID.class), eq(accountId))).thenReturn(filterRolesResponseDto);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects/members/filters")
                .requestAttr(O_ID, oId)
                .param("accountId", accountId.toString())
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<FilterRolesResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.FETCH_PROJECT_MEMBERS.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.FETCH_PROJECT_MEMBERS.getMessage(), responseDto.getMessage());

        verify(projectService, times(1)).getFilterMembers(any(UUID.class), eq(accountId));
    }
    @Test
    void testGetProjectListWithFilters() throws Exception {
        String accountId = "123";
        Long accountIdLong = 123L;
        ProjectFilterDto projectFilterDto = new ProjectFilterDto();
        List<ProjectListResponseDto> projectListResponseDtos = Collections.singletonList(new ProjectListResponseDto());
        ProjectsListDto projectsListDto = new ProjectsListDto();
        projectsListDto.setProjectListResponseDtos(projectListResponseDtos);

        when(utilMethods.stringToLong(anyString())).thenReturn(accountIdLong);
        when(projectService.getProjectDetailsList(any(UUID.class), eq(accountIdLong), any(ProjectFilterDto.class))).thenReturn(projectsListDto);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/v1/projects/filters")
                .requestAttr(O_ID, oId)
                .param("accountId", accountId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(projectFilterDto));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<List<ProjectListResponseDto>> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.PROJECT_LIST_FETCHED.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.PROJECT_LIST_FETCHED.getMessage(), responseDto.getMessage());

        verify(projectService, times(1)).getProjectDetailsList(any(UUID.class), eq(accountIdLong), any(ProjectFilterDto.class));
    }
    @Test
    void testValidateProjectName_ProjectNameAvailable() throws Exception {
        Long accountId = 123L;
        String field = "fieldName";
        String value = "ProjectName";

        when(projectService.validateProjectName(eq(accountId), eq(value))).thenReturn(true);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects/validate")
                .requestAttr(Constants.O_ID, oId)
                .param("accountId", accountId.toString())
                .param("field", field)
                .param("value", value)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<Boolean> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.PROJECT_NAME_EXIST.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.PROJECT_NAME_EXIST.getMessage(), responseDto.getMessage());

        verify(projectService, times(1)).validateProjectName(eq(accountId), eq(value));
    }

    @Test
    void testValidateProjectName_ProjectNameAlreadyExists() throws Exception {
        Long accountId = 123L;
        String field = "fieldName";
        String value = "ExistingProject";

        when(projectService.validateProjectName(eq(accountId), eq(value))).thenReturn(false);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects/validate")
                .requestAttr(Constants.O_ID, oId)
                .param("accountId", accountId.toString())
                .param("field", field)
                .param("value", value)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<Boolean> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.DUPLICATE_PROJECT_NAME.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.DUPLICATE_PROJECT_NAME.getMessage(), responseDto.getMessage());

        verify(projectService, times(1)).validateProjectName(eq(accountId), eq(value));
    }

    @Test
    public void testEditProject_Success() throws Exception {
        Long projectId = 1L;
        ProjectRequestDto requestDto = ProjectServiceImplTest.createSampleProjectRequestDto();
        ProjectResponseDto editProject =new ProjectResponseDto();
        BeanUtils.copyProperties(requestDto,editProject);
        editProject.setProjectId(1L);
        when(projectService.editProject(any(ProjectRequestDto.class), eq(projectId), any(UUID.class))).thenReturn(editProject);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/v1/projects/{projectId}", projectId).requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(ProjectServiceImplTest.createSampleProjectRequestDto()));
        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isCreated())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<ProjectResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals(SUCCESS, responseDto.getStatus());
        verify(projectService, times(1)).editProject(any(ProjectRequestDto.class), eq(projectId), any(UUID.class));
    }


}


