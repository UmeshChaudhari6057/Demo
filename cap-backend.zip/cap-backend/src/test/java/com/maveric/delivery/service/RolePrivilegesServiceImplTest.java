package com.maveric.delivery.service;

import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.Entity.RolePrivileges;
import com.maveric.delivery.Entity.Roles;
import com.maveric.delivery.mysqlrepository.PrivilegesmysqlRepository;
import com.maveric.delivery.mysqlrepository.RolePrivilegesmysqlRepository;
import com.maveric.delivery.mysqlrepository.RolesmysqlRepository;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class RolePrivilegesServiceImplTest {

    @MockBean
    private JwtDecoder jwtDecoder;

    @MockBean
    private RolePrivilegesmysqlRepository rolePrivilegesRepository;

    @MockBean
    private RolesmysqlRepository rolesRepository;

    @Autowired
    private RolePrivilegesService rolePrivilegesService;

    @MockBean
    private PrivilegesmysqlRepository privilegesRepository;

    @MockBean
    private UtilMethods utilMethods;

    Long roleId = Long.valueOf(1);

    @Test
    void save_success() {
        List<RolePrivilegesDto> rolePrivilegesDtos = new ArrayList<>();
        RolePrivileges privileges = new RolePrivileges();
        when(rolePrivilegesRepository.findByRoleId(null)).thenReturn(Optional.of(privileges));
        when(rolePrivilegesRepository.save(privileges)).thenReturn(privileges);
        rolePrivilegesDtos =  rolePrivilegesService.save(rolePrivilegesDtos);
        assertNotNull(rolePrivilegesDtos);
    }

    @Test
    void update_success() {
        List<RolePrivilegesDto> rolePrivilegesDtos = new ArrayList<>();
        RolePrivileges privileges = new RolePrivileges();
        privileges.setId(roleId);
        when(rolePrivilegesRepository.findByRoleId(roleId)).thenReturn(Optional.of(privileges));
        when(rolePrivilegesRepository.save(privileges)).thenReturn(privileges);
        rolePrivilegesDtos =  rolePrivilegesService.save(rolePrivilegesDtos);
        assertNotNull(rolePrivilegesDtos);
    }

    @Test
    void findAll_success() {
        List<RolePrivileges> rolePrivilegesList = Collections.singletonList(mock(RolePrivileges.class));
        Privileges privileges = mock(Privileges.class);
        when(privilegesRepository.findAll()).thenReturn(Collections.singletonList(privileges));
        when(rolePrivilegesRepository.findAll()).thenReturn(rolePrivilegesList);
        assertNotNull(rolePrivilegesService.findAll());
    }

    @Test
    void findByRoleId_success() {
        RolePrivileges rolePrivileges = new RolePrivileges();
        Privileges privileges = mock(Privileges.class);
        when(privilegesRepository.findAll()).thenReturn(Collections.singletonList(privileges));
        when(rolePrivilegesRepository.findByRoleId(roleId)).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByRoleId(roleId));
    }

    @Test
    void findByRoleId_success_null() {
        RolePrivileges rolePrivileges = mock(RolePrivileges.class);
        Privileges privileges = mock(Privileges.class);
        when(privilegesRepository.findAll()).thenReturn(Collections.singletonList(privileges));
        when(rolePrivilegesRepository.findByRoleId(roleId)).thenReturn(Optional.ofNullable(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByRoleId(roleId));
    }

    @Test
    void findByValue_success() {
        List<String> module =  Collections.singletonList("Accounts");
        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        List<Privileges> privilegesList = new ArrayList<>();
        Privileges privileges = new Privileges();
        privileges.setName("Accounts");
        privileges.setPrivileges(Collections.singletonList(privileges));
        privilegesList.add(privileges);
        rolePrivileges.setPrivileges(privilegesList);
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByValue(module,name));
    }

    @Test
    void findByValue_success_null() {
        List<String> module =  Collections.singletonList("Accounts");
        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByValue(module,name));
    }

    @Test
    void testfindByValue_success() {

        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        List<Privileges> privilegesList = new ArrayList<>();
        Privileges privileges = new Privileges();
        privileges.setName("Accounts");
        privileges.setPrivileges(Collections.singletonList(privileges));
        privilegesList.add(privileges);
        rolePrivileges.setPrivileges(privilegesList);
        when(privilegesRepository.findAll()).thenReturn(Collections.singletonList(privileges));
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByValue(name));
    }

    @Test
    void testfindByValue_success_null() {

        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        Privileges privileges = mock(Privileges.class);
        when(privilegesRepository.findAll()).thenReturn(Collections.singletonList(privileges));
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByValue(name));
    }
}