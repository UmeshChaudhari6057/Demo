package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.PrivilegesService;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PrivilegesController.class)
@AutoConfigureMockMvc
class PrivilegesControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    private PrivilegesService privilegesService;

    @MockBean
    private ValidateApiAccess validateApiAccess;
    private final String oId = UUID.randomUUID().toString();

    @Test
    void get_test() throws Exception {
        when(privilegesService.getPrivileges()).thenReturn(List.of(new PrivilegesDetailsDto()));
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/privileges")
                .requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }
}