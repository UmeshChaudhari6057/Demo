package com.maveric.delivery.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.BaseServiceImpl;

@WebMvcTest(BaseController.class)
@AutoConfigureMockMvc
public class BaseControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AzureUsermysqlRepository azureUserRepository;

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    private BaseServiceImpl baseService;

    @Test
    public void testSaveLocation_ValidInput_Success() throws Exception {

        String locationName = "Test Location";
        BaseDto mockBaseDto = new BaseDto();
        mockBaseDto.setName(locationName);
        when(baseService.saveLocation(locationName)).thenReturn(mockBaseDto);
        String requestBody = "{\"name\":\"Test Location\"}";
        MockHttpServletRequestBuilder requestBuilder = post("http://localhost:8080/v1/types/location/Test Location")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(requestBody);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isCreated())
                .andReturn();
        ResponseDto<BaseDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<BaseDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1012", responseDto.getCode());
        assertEquals("Location saved successfully", responseDto.getMessage());
        assertEquals(mockBaseDto, responseDto.getPayload());
    }

    @Test
    public void testSaveProjectRole_ValidInput_Success() throws Exception {

        String projectRole = "Test ProjectRole";
        BaseDto mockBaseDto = new BaseDto();
        mockBaseDto.setName(projectRole);
        when(baseService.saveProjectRole(projectRole)).thenReturn(mockBaseDto);
        String requestBody = "{\"name\":\"Test ProjectRole\"}";
        MockHttpServletRequestBuilder requestBuilder = post("http://localhost:8080/v1/types/projectRole/Test ProjectRole")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(requestBody);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isCreated())
                .andReturn();
        ResponseDto<BaseDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<BaseDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1010", responseDto.getCode());
        assertEquals("ProjectRole saved successfully", responseDto.getMessage());
        assertEquals(mockBaseDto, responseDto.getPayload());
    }

    @Test
    public void testSaveArtifactType_ValidInput_Success() throws Exception {

        String artifactType = "Test ArtifactType";
        BaseDto mockBaseDto = new BaseDto();
        mockBaseDto.setName(artifactType);
        when(baseService.saveArtifactType(artifactType)).thenReturn(mockBaseDto);
        String requestBody = "{\"name\":\"Test ArtifactType\"}";
        MockHttpServletRequestBuilder requestBuilder = post("http://localhost:8080/v1/types/artifactType/Test ArtifactType")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(requestBody);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isCreated())
                .andReturn();
        ResponseDto<BaseDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<BaseDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1011", responseDto.getCode());
        assertEquals("Artifact type saved successfully", responseDto.getMessage());
        assertEquals(mockBaseDto, responseDto.getPayload());
    }

    @Test
    public void testFetchAllType_Success() throws Exception {

        String typeName="frequency";
        List<BaseDto> baseDtoList = new ArrayList<>();
        baseDtoList.add(new BaseDto(1L, "Type1"));
        when(baseService.fetchAllTypes(typeName)).thenReturn(baseDtoList);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/types/{typeName}",typeName)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper=new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testFetchAllType_Failed() throws Exception {

        String typeName="invalid";
        List<BaseDto> baseDtoList = new ArrayList<>();
        when(baseService.fetchAllTypes(typeName)).thenReturn(baseDtoList);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/types/{typeName}",typeName)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper=new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Failed", responseDto.getStatus());
    }

    @Test
    public void testFetchAllProjectStatus_Success() throws Exception {

        List<BaseDto> baseDtoList = new ArrayList<>();
        baseDtoList.add(new BaseDto(1L, "Status1"));
        when(baseService.fetchAllProjectStatus()).thenReturn(baseDtoList);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/types/project-status")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper=new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());

    }
    @Test
    public void testFetchAllProjectStatus_Failed() throws Exception {

        List<BaseDto> baseDtoList = new ArrayList<>();
        when(baseService.fetchAllProjectStatus()).thenReturn(baseDtoList);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/types/project-status")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper=new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Failed", responseDto.getStatus());

    }
}