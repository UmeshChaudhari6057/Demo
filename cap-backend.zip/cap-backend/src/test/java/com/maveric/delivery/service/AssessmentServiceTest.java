package com.maveric.delivery.service;

import com.maveric.delivery.Entity.Assessment;
import com.maveric.delivery.Entity.AssessmentHistory;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.mysqlrepository.AssessmentmysqlRepository;
import com.maveric.delivery.requestdto.AssessmentFilterDto;
import com.maveric.delivery.responsedto.AssessmentTrendsDetailsDto;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AssessmentServiceTest {

    @MockBean
    private JwtDecoder jwtDecoder;

    @Mock
    private UtilMethods utilMethods;

//    @Mock
//    private MongoTemplate mongoTemplate;

    @InjectMocks
    private AssessmentService assessmentService;

    @Mock
    private AssessmentmysqlRepository assessmentRepository;

    private final UUID oId = UUID.randomUUID();

    @Test
    void fetchTrendsDetails_All_Success() {
        AssessmentFilterDto assessmentFilterDto = AssessmentFilterDto.builder().build();
        assessmentFilterDto.setAccountId(1L);
        assessmentFilterDto.setProjectId(1L);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);

     //   when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
       // when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
      //  when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);
        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = assessmentService.fetchTrendsDetails(oId,assessmentFilterDto, AssessmentRole.ALL);
        assertNotNull(assessmentTrendsDetailsDto);

    }
    @Test
    void fetchTrendsDetails_Assigned_Success() {
        AssessmentFilterDto assessmentFilterDto = AssessmentFilterDto.builder().build();
        assessmentFilterDto.setAccountId(1L);
        assessmentFilterDto.setProjectId(1L);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);

//        when(assessmentRepository.findByUserId(any(UUID.class))).thenReturn(assessments);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);
//        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = assessmentService.fetchTrendsDetails(oId,assessmentFilterDto, AssessmentRole.ASSIGNED);
//        assertNotNull(assessmentTrendsDetailsDto);

    }
    @Test
    void fetchTrendsDetails_Reviewer_Success() {
        AssessmentFilterDto assessmentFilterDto = AssessmentFilterDto.builder().build();
        assessmentFilterDto.setAccountId(1L);
        assessmentFilterDto.setProjectId(1L);
        List<AssessmentHistory> assessmentHistories = new ArrayList<>();
        assessmentHistories.add(new AssessmentHistory());
        List<Assessment> assessments = new ArrayList<>();
        Assessment assessment = new Assessment();
        assessment.setAccountId(1L);
        assessment.setStatus(AssessmentStatus.REVIEWED);
        assessment.setScore(2.2);
        assessments.add(assessment);
        assessment = new Assessment();
        assessment.setAccountId(2L);
        assessment.setScore(2.2);
        assessment.setStatus(AssessmentStatus.SUBMITTED);
        assessments.add(assessment);
//        when(assessmentRepository.findByReviewerId(any(UUID.class))).thenReturn(assessments);
//        when(mongoTemplate.findDistinct(any(Query.class), any(String.class), eq(AssessmentHistory.class), eq(AssessmentHistory.class))).thenReturn(assessmentHistories);
//        when( mongoTemplate.count(any(Query.class), eq(AssessmentHistory.class))).thenReturn(2L);
//        when(mongoTemplate.find(any(Query.class), eq(Assessment.class))).thenReturn(assessments);
//        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = assessmentService.fetchTrendsDetails(oId,assessmentFilterDto, AssessmentRole.REVIEWER);
//        assertNotNull(assessmentTrendsDetailsDto);

    }
}