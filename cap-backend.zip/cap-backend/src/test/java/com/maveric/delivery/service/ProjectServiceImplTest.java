package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.YES;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.EngagementType;
import com.maveric.delivery.exception.ProjectDateException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Frequency;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AccountType;
import com.maveric.delivery.model.embedded.BaseInfo;
import com.maveric.delivery.model.embedded.ClientInformation;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.DeliveryInformation;
import com.maveric.delivery.model.embedded.ExternalSystemInfo;
import com.maveric.delivery.model.embedded.OtherInformation;
import com.maveric.delivery.model.embedded.ProjectClientInfo;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.mysqlrepository.BusinessSubverticalmysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.mysqlrepository.EngagementTypemysqlRepository;
import com.maveric.delivery.mysqlrepository.FrequencymysqlRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.requestdto.AccountRoles;
import com.maveric.delivery.requestdto.DeliveryInformationDto;
import com.maveric.delivery.requestdto.ProjectFilterDto;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.utils.UtilMethods;

/**
 * @author ankushk
 */

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class ProjectServiceImplTest {

    @MockBean
    private JwtDecoder jwtDecoder;

    @MockBean
    private ProjectRepository projectRepository;

    @MockBean
    private AccountRepository accountRepository;

    @MockBean
    private DedRolesRepository dedRolesRepository;

    @Autowired
    private ProjectServiceImpl projectService;

    @MockBean
    private UserServiceImpl userServiceImpl;

    @MockBean
    private  AzureUsermysqlRepository azureUserRepository;
    @MockBean
    private UtilMethods utilMethods;
    @MockBean
    private  BusinessSubverticalmysqlRepository businessSubverticalRepository;
    @MockBean
    private  FrequencymysqlRepository frequencyRepository;
    @MockBean
    private  EngagementTypemysqlRepository engagementTypeRepository;

//    @Mock
//    private MongoTemplate mongoTemplate;

    @Test
    public void testGetProjectById_ProjectFound() {
        UUID oid=UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4");
        Long projectId = 1L;
        Project project = new Project();
        project.setId(projectId);
        Long accountId = 1L;
        project.setAccountId(accountId);
        project.setStartDate(233843483l);
        project.setEndDate(233843483l);
        project.setIsBillable(true);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        deliveryInformation.setAssessmentStartDate(LocalDate.now());
        project.setDeliveryInfo(deliveryInformation);
        Account account = new Account();

        account.setAccountName("Test Account");
     // Commented out MongoDB code

//        when(projectRepository.findById(projectId)).thenReturn(Optional.of(project));
//        when(accountRepository.findById(accountId)).thenReturn(Optional.of(account));
        List<DedRolesmy> resultAccount = new ArrayList<>();
        DedRolesmy dedRoles1 = new DedRolesmy();
        dedRoles1.setAccountId(1L);
        dedRoles1.setRole("DH");

        resultAccount.add(dedRoles1);

        project.setDedRoles(resultAccount);
        when(userServiceImpl.getHighestRole(oid,null,null)).thenReturn("ACCOUNT_ADMIN");
        when(userServiceImpl.getHighestRole(oid,1L,1L)).thenReturn("ACCOUNT_ADMIN");

        ProjectResponseDto result = projectService.getProjectById(projectId, oid);
        result.setEndDate(23943904l); // Assuming project.getEndDate() returns a long representing milliseconds since epoch

        assertEquals(projectId, result.getProjectId());
        assertEquals("Test Account", result.getAccountName());



    }


 // Commented out MongoDB code

//    @Test
//    void testGetProjectById_ProjectNotFound() {
//        when(projectRepository.findById(anyLong())).thenReturn(Optional.empty());
//        assertThrows(ProjectNotFoundException.class, () -> {
//            projectService.getProjectById(  999L, UUID.randomUUID());
//        });
//    }


    public static ProjectRequestDto createSampleProjectRequestDto() {
        ProjectRequestDto projectRequestDto = new ProjectRequestDto();
        projectRequestDto.setAccountId(1L);
        projectRequestDto.setProjectName("Sample Project");
        projectRequestDto.setCustomerLOB("Sample LOB");
        projectRequestDto.setEngagementType("Time & Material");
        List<String> tags = new ArrayList<>();
        tags.add("Tag1");
        tags.add("Tag2");
        projectRequestDto.setTags(tags);
        projectRequestDto.setBusinessSubVertical("Retail");
        projectRequestDto.setStartDate(System.currentTimeMillis());
        projectRequestDto.setEndDate(System.currentTimeMillis() + 46400000);// Current time in milliseconds
        // Adding one day (86400000 milliseconds) to current time
        projectRequestDto.setIsBillable(true);
        projectRequestDto.setDescription("Sample Description Theres a new version of SonarQube available. Upgrade to the latest active version to access new updates and features");
        DeliveryInformationDto deliveryInfo = createSampleDeliveryInformationDto();
        projectRequestDto.setDeliveryInfo(deliveryInfo);
        ProjectClientInfo clientInformation = new ProjectClientInfo();
        projectRequestDto.setClientInformation(clientInformation);
        OtherInformation otherInformation = new OtherInformation();
        List<ExternalSystemInfo> externalSystemInfos=new ArrayList<>();
        externalSystemInfos.add(new ExternalSystemInfo("APD777","SAP ERP"));
        otherInformation.setExternalSystemInfo(externalSystemInfos);
        projectRequestDto.setOtherInformation(otherInformation);
        projectRequestDto.setStatus(ProjectStatus.Active);
        return projectRequestDto;
    }

    public static DeliveryInformationDto createSampleDeliveryInformationDto() {
        DeliveryInformationDto deliveryInformationDto = new DeliveryInformationDto();
        deliveryInformationDto.setProjectType("Sample Project Type");
        List<BaseInfo> assessmentTemplates = new ArrayList<>();
        BaseInfo assessmentTemplate1 = new BaseInfo();
        assessmentTemplate1.setId(1L);
        assessmentTemplate1.setName("Template 1");
        assessmentTemplates.add(assessmentTemplate1);
        BaseInfo assessmentTemplate2 = new BaseInfo();
        assessmentTemplate2.setId(2L);
        assessmentTemplate2.setName("Template 2");
        assessmentTemplates.add(assessmentTemplate2);
        deliveryInformationDto.setAssessmentTemplates(assessmentTemplates);
        deliveryInformationDto.setFrequency("Monthly");
        deliveryInformationDto.setDeliveryNotes("Sample Delivery Notes");
        AccountRoles deliveryHead = new AccountRoles();
        deliveryHead.setUserId(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"));
        deliveryHead.setName("Delivery Head");
        deliveryInformationDto.setDeliveryManager(deliveryHead);
        AccountRoles accountPartner1 = new AccountRoles();
        accountPartner1.setUserId(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa3"));
        accountPartner1.setName("Account Partner 1");
        deliveryInformationDto.setAccountPartner(accountPartner1);
        AccountRoles engagementPartner1 = new AccountRoles();
        engagementPartner1.setUserId(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa2"));
        engagementPartner1.setName("Engagement Partner 1");
        deliveryInformationDto.setEngagementPartner(engagementPartner1);
        AccountRoles deliveryPartner1 = new AccountRoles();
        deliveryPartner1.setUserId(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1"));
        deliveryPartner1.setName("Delivery Partner 1");
        deliveryInformationDto.setDeliveryPartner(deliveryPartner1);
        deliveryInformationDto.setAssessmentStartDate(System.currentTimeMillis() + 86400000);
        return deliveryInformationDto;
    }




    @Test
    void testSetProjectListResponseDetailsWithProjectDetails() {
        MockitoAnnotations.initMocks(this);
        Project project = new Project();
        project.setId(1L);
        project.setProjectName("Project A");
        project.setCustomerLOB("Finance");
        project.setIsBillable(true);
        DedRolesmy dmRole = new DedRolesmy(UUID.randomUUID(),1L,2l,"DM", "John Doe");
        project.setDedRoles(Arrays.asList(dmRole)); // Assuming DedRoles has a constructor that takes role and name
        ProjectListResponseDto result = projectService.setProjectListResponseDetails(project);
        assertEquals(1L, result.getId());
        assertEquals("Project A", result.getName());
        assertEquals("Finance", result.getCustomerLOB());
        assertEquals(YES, result.getIsBillable());

    }
    @Test
    void testGetProjectDetailsList_EmptyProjectIdList() {
        UUID oid = UUID.randomUUID();
        Long accountId = 123L;
        Set<Long> emptyList = Set.of();
     // Commented out MongoDB code

       // when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(new ArrayList<>());
        when(userServiceImpl.getHighestRole(oid,null,null)).thenReturn("ACCOUNT_ADMIN");
        ProjectsListDto result = projectService.getProjectDetailsList(oid, accountId, new ProjectFilterDto());

        assertEquals(0, result.getProjectsList().size());
    }



    @Test
    public void testGetProjectDetailsList_whenProjectIdListIsEmpty() {
        UUID oid = UUID.randomUUID();
        Long accountId = 123L;

        //when(projectService.getProjectId(oid, accountId)).thenReturn(Set.of());
        when(userServiceImpl.getHighestRole(oid,null,null)).thenReturn("ACCOUNT_ADMIN");
     // Commented out MongoDB code

  //      when(mongoTemplate.find(any(Query.class), eq(Project.class))).thenReturn(new ArrayList<>());
        ProjectsListDto result = projectService.getProjectDetailsList(oid, accountId, new ProjectFilterDto());

        assertTrue(result.getProjectsList().isEmpty());
    }

    /*@Test
     void testGetProjectDetailsList() {
        UUID oid = UUID.fromString("9e200b5e-d5cc-4171-bc4e-a6aaf519be9f");
        Long accountId = 991740250L;
        List<DedRoles> expectedRoles = Arrays.asList(createDedRoles(1L),createDedRoles(2L));
        when(dedRolesRepository.findByOid(oid)).thenReturn(expectedRoles);
        when(dedRolesRepository.findByOidAndAccountId(oid,accountId)).thenReturn(expectedRoles);
        when(dedRolesRepository.findByAccountId(accountId)).thenReturn(expectedRoles);
        List<ProjectListResponseDto> expectedResponse = Arrays.asList(
                createProjectListResponseDto(1L),
                createProjectListResponseDto(2L)
        );
        Project resultAccount=createProject(1L);
        when(projectRepository.findById(1L)).thenReturn(Optional.of(resultAccount));
        Project resultAccount1=createProject(2L);
        when(projectRepository.findById(2L)).thenReturn(Optional.of(resultAccount1));
        List<ProjectListResponseDto> result = projectService.getProjectDetailsList(oid, accountId);
        assertEquals(expectedResponse, result);
    }*/

   /* @Test
     void testGetProjectId_whenAccountIdIsZero() {
        UUID oid = UUID.randomUUID();
        Long accountId = 0L;
        List<DedRoles> expectedRoles = Arrays.asList(createDedRoles(1L), createDedRoles(2L));

        when(dedRolesRepository.findByOid(oid)).thenReturn(expectedRoles);

        Set<Long> result = projectService.getProjectId(oid, accountId);

        assertEquals(expectedRoles.size(), result.size());
        assertTrue(result.contains(1L));
        assertTrue(result.contains(2L));
    }*/


    private DedRolesmy createDedRoles(Long projectId) {
        DedRolesmy dedRoles = new DedRolesmy();
        dedRoles.setProjectId(projectId);
        dedRoles.setRole("DM");
        dedRoles.setName("Name");
        return dedRoles;
    }

    private Project createProject(Long projectId) {
        Project project = new Project();
        project.setId(projectId);
        project.setProjectName("ProjectName");

        project.setCustomerLOB("CustomerLOB");
        project.setIsBillable(true);
        project.setStartDate(1L);
        project.setEndDate(2L);
        project.setDedRoles(Collections.singletonList(createDedRoles(projectId)));
        return project;
    }

    private ProjectListResponseDto createProjectListResponseDto(Long projectId) {
        ProjectListResponseDto dto = new ProjectListResponseDto();
        dto.setId(projectId);
        dto.setName("ProjectName");
        dto.setDeliveryManager("Name");
        dto.setCustomerLOB("CustomerLOB");
        dto.setIsBillable(YES);
        dto.setStartDate(1L);
        dto.setEndDate(2L);

        return dto;
    }
    public  Account createMockAccount() {
        Account account = new Account();
        account.setId(810203031l);
        account.setAccountName("Sample");
        account.setAccountType(AccountType.Client);
        account.setTags(List.of("Network", "IT"));
        account.setDedRoles(createMockDedRoles());
        account.setStatus(AccountStatus.Active);
        account.setDateOnboarded(23423412343431L);
        account.setExternalId("ext-123");
        account.setClientInfo(new ClientInformation());
        account.setCreatedBy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6"));
        account.setCreatedAt(System.currentTimeMillis());
        account.setUpdatedBy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66af92"));
        account.setUpdatedAt(System.currentTimeMillis());
        return account;
    }
    private  List<DedRolesmy> createMockDedRoles() {
        List<DedRolesmy> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1"), null, 0L, "Barani", "DH"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa2"), null, 0L, "Sham", "DP"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa3"), null, 0L, "Krishna", "AP"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"), null, 0L, "Barani", "EP"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6"), null, 0L, "Ankush", "SuperAdmin"));
        return dedRoles;
    }
    @Test
    void testCreateProject_ExceptionProjectDateAfterAccountOnboardedDate() {
//        when(accountRepository.findById(1L)).thenReturn(Optional.of(createMockAccount()));
//        when(projectRepository.findByAccountId(1L)).thenReturn(new ArrayList<>());
        when(userServiceImpl.checkAndAddUserId( anySet(),any(AccountRoles.class),any(String.class))).thenReturn(new HashSet<>());
        List<BusinessSubvertical> subverticalList =new ArrayList<>();
        subverticalList.add( new BusinessSubvertical("Sample Business SubVertical"));
        when(businessSubverticalRepository.findAll()).thenReturn(subverticalList);
        when(engagementTypeRepository.findAll()).thenReturn(List.of(new EngagementType("Sample Engagement Type")));
        when(frequencyRepository.findAll()).thenReturn(List.of(new Frequency("Sample Frequency",10)));
//        doNothing().when(userServiceImpl).saveRole(any());
        ProjectRequestDto requestDto = createSampleProjectRequestDto();

        List<BusinessSubvertical> businessVerticals = new ArrayList<>();
        BusinessSubvertical businessSubvertical = new BusinessSubvertical();
        businessSubvertical.setName("Retail");
       // businessSubvertical.setId(1L);
        businessVerticals.add(businessSubvertical);

        List<Frequency> frequencies =  new ArrayList<>();
        Frequency frequency = new Frequency();
        frequency.setName("Monthly");
        frequency.setId(1L);
        frequencies.add(frequency);

        List<EngagementType> engTypeList =  new ArrayList<>();
        EngagementType engType = new EngagementType();
        engType.setName("Time & Material");
        engType.setId(1L);
        engTypeList.add(engType);


        when( businessSubverticalRepository.findAll()).thenReturn(businessVerticals);
        when( frequencyRepository.findAll()).thenReturn(frequencies);
        when( engagementTypeRepository.findAll()).thenReturn(engTypeList);

        try {

            ProjectResponseDto createdProject = projectService.saveProject(requestDto,UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"));
        } catch(ProjectDateException pde) {
            assertEquals("Project start date should be after account onboarded date", pde.getMessage());
        }

    }

    /*@Test
    void testCreateProject_SuccessfulProjectDateNotAfterAccountOnboardedDate() {
        Account acct = createMockAccount();
        acct.setDateOnboarded(System.currentTimeMillis()-100000000);
        when(accountRepository.findById(1L)).thenReturn(Optional.of(acct));
        when(projectRepository.findByAccountId(1L)).thenReturn(new ArrayList<>());
        when(userServiceImpl.checkAndAddUserId( new HashSet<>(),"3fa85f64-5717-4562-b3fc-2c963f66afa4")).thenReturn(new HashSet<>());
        List<BusinessSubvertical> subverticalList =new ArrayList<>();
        subverticalList.add( new BusinessSubvertical("Sample Business SubVertical"));
        when(businessSubverticalRepository.findAll()).thenReturn(subverticalList);
        when(engagementTypeRepository.findAll()).thenReturn(List.of(new EngagementType("Sample Engagement Type")));
        when(frequencyRepository.findAll()).thenReturn(List.of(new Frequency("Sample Frequency")));
//        doNothing().when(userServiceImpl).saveRole(any());
        ProjectRequestDto requestDto = createSampleProjectRequestDto();

        List<BusinessSubvertical> businessVerticals = new ArrayList<>();
        BusinessSubvertical businessSubvertical = new BusinessSubvertical();
        businessSubvertical.setName("Retail");
        // businessSubvertical.setId(1L);
        businessVerticals.add(businessSubvertical);

        List<Frequency> frequencies =  new ArrayList<>();
        Frequency frequency = new Frequency();
        frequency.setName("Monthly");
        frequency.setId(1L);
        frequencies.add(frequency);

        List<EngagementType> engTypeList =  new ArrayList<>();
        EngagementType engType = new EngagementType();
        engType.setName("Time & Material");
        engType.setId(1L);
        engTypeList.add(engType);


        when( businessSubverticalRepository.findAll()).thenReturn(businessVerticals);
        when( frequencyRepository.findAll()).thenReturn(frequencies);
        when( engagementTypeRepository.findAll()).thenReturn(engTypeList);

        Project project=new Project();
        BeanUtils.copyProperties(requestDto,project);
        project.setId(1L);
        ProjectResponseDto projectResponseDto=new ProjectResponseDto();
        BeanUtils.copyProperties(requestDto,projectResponseDto);
        *//*when(projectRepository.save(any())).thenReturn(project);*//*
       doNothing().when(userServiceImpl).saveRole(any());
        ProjectResponseDto createdProject = projectService.saveProject(requestDto,UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"));

        assertNotNull(createdProject);
        assertEquals("Sample Project", createdProject.getProjectName());
        assertEquals(1L, createdProject.getAccountId());

    }*/

}







