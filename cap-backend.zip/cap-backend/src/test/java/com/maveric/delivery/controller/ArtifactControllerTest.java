package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.requestdto.ArtifactFilterDto;
import com.maveric.delivery.requestdto.ArtifactRequestDto;
import com.maveric.delivery.responsedto.ArtifactListDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ArtifactServiceImpl;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ArtifactController.class)
@AutoConfigureMockMvc
class ArtifactControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ArtifactServiceImpl artifactService;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    private UtilMethods utilMethods;

    private final String oId = UUID.randomUUID().toString();


    @Test
    void testFetchAllArtifacts() throws Exception {
        UUID userId = UUID.randomUUID();
        Long projectId = 123L;
        List<ArtifactListDto> artifacts = new ArrayList<>();
        when(artifactService.getAllArtifacts(any(UUID.class), any(Long.class),any(ArtifactFilterDto.class))).thenReturn(artifacts);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/artifacts")
                .requestAttr(O_ID, oId)
                .param("projectId", String.valueOf(projectId))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }


    @Test
    void testDeleteArtifact() throws Exception {
        UUID userId = UUID.randomUUID();
        Long artifactId = 123L;
        List<ArtifactListDto> artifacts = new ArrayList<>();
        when(artifactService.getAllArtifacts(any(UUID.class), any(Long.class),any(ArtifactFilterDto.class))).thenReturn(artifacts);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/artifacts/"+artifactId+"/attachment-delete")
                        .requestAttr(O_ID, oId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        Assert.assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testSaveArtifact_Success() throws Exception {
        Long projectId = 123L;
        ArtifactListDto artifactDto = new ArtifactListDto();
        ArtifactRequestDto artifactRequestDto =  new ArtifactRequestDto();
        artifactRequestDto.setName("test");
        artifactRequestDto.setLink("test");
        artifactRequestDto.setType("test");
        MockMultipartFile jsonPart = new MockMultipartFile("request", "", MediaType.APPLICATION_JSON_VALUE, objectMapper.writeValueAsString(artifactRequestDto).getBytes());

        when(artifactService.saveArtifact(any(ArtifactRequestDto.class), any(UUID.class),any(Long.class), any(MultipartFile.class)))
                .thenReturn(artifactDto);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/artifacts")
                        .file(jsonPart)
                        .requestAttr(O_ID, oId)

                        .contentType(MediaType.MULTIPART_FORM_DATA)
                .accept(MediaType.APPLICATION_JSON)
                        .param("projectId", String.valueOf(projectId))
                )
                .andReturn();
        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        Assert.assertEquals("Success", responseDto.getStatus());

    }

    @Test
    public void testFetchFilteredArtifacts() throws Exception {
        Long projectId = 123L;
        List<ArtifactListDto> artifacts = new ArrayList<>();
        when(artifactService.getAllArtifacts(any(UUID.class), any(Long.class),any(ArtifactFilterDto.class))).thenReturn(artifacts);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/v1/artifacts/filters")
                        .requestAttr(O_ID, oId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .param("projectId", String.valueOf(projectId))
                        .content(objectMapper.writeValueAsString(new ArtifactFilterDto())))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        Assert.assertEquals("Success", responseDto.getStatus());

    }


}
