package com.maveric.delivery.service;

import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.TemplateStatus;
import com.maveric.delivery.mysqlrepository.AssessmentTemplatemysqlRepository;
import com.maveric.delivery.responsedto.BaseDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class AssessmentTemplateServiceTest {

    private MockMvc mockMvc;

    @Mock
    private AssessmentTemplatemysqlRepository assessmentTemplateRepository;

    @InjectMocks
    private AssessmentTemplateServiceImpl assessmentTemplateService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFetchAllTemplates_Success() throws Exception {
        List<AssessmentTemplate> assessmentTemplates = new ArrayList<>();
        AssessmentTemplate assessmentTemplate=new AssessmentTemplate();
        assessmentTemplate.setStatus(TemplateStatus.Active);
        assessmentTemplates.add(assessmentTemplate);
        when(assessmentTemplateRepository.findByAssessmentTypeAndStatus(AssessmentCategoryType.DELIVERY_MATURITY, TemplateStatus.Active)).thenReturn(assessmentTemplates);
        List<BaseDto> result = assessmentTemplateService.getAllTemplates("delivery");
        Assertions.assertEquals(assessmentTemplates.size(), result.size());
    }
}
