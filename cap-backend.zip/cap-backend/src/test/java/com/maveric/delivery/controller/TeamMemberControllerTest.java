package com.maveric.delivery.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.requestdto.TeamMemberFilterDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;
import com.maveric.delivery.service.TeamMemberService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;

import jakarta.servlet.http.HttpServletRequest;

@WebMvcTest(TeamMemberController.class)
@AutoConfigureMockMvc
public class TeamMemberControllerTest {

    @Autowired
    private TeamMemberController teamMemberController;
    @MockBean
    private TeamMemberService teamMemberService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;
    @Mock
    private HttpServletRequest httpServletRequest;

    @MockBean
    private AzureUsermysqlRepository azureUserRepository;

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    private UtilMethods utilMethods;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(teamMemberController).build();
    }


    @Test
    void testSaveTeamMember() throws Exception {
        TeamMemberDto teamMemberDto = new TeamMemberDto();
        teamMemberDto.setName("example");
        teamMemberDto.setProjectRole("Developer");
        teamMemberDto.setLocation("Pune");
        teamMemberDto.setIsBillable(true);
        teamMemberDto.setStartDate(1620260000000L);
        teamMemberDto.setEndDate(1620370000000L);
        teamMemberDto.setAllocation(100L);
        teamMemberDto.setUserId(UUID.randomUUID());

        String projectId = "12345";
        UUID userId = UUID.randomUUID();

        TeamMemberResponseDto createdTeamMember = new TeamMemberResponseDto();
        when(teamMemberService.saveTeamMember(teamMemberDto, userId, utilMethods.stringToLong(projectId)))
                .thenReturn(createdTeamMember);

        MockHttpServletRequestBuilder requestBuilder = post("/v1/teamMembers")
                .param("projectId", String.valueOf(projectId))
                .requestAttr("oid", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(teamMemberDto));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isCreated())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ResponseDto<TeamMemberResponseDto> responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testFetchAllTeamMembers() throws Exception {
        String oId ="d4682ac9-3e2c-49dd-bca4-ea784aa0eb4e";
        List<TeamMemberResponseListDto> teamMemberList = new ArrayList<>();
        TeamMemberFilterDto teamMemberFilterDto=new TeamMemberFilterDto();
        when(teamMemberService.getAllTeamMembers(UUID.fromString(oId),1L,teamMemberFilterDto)).thenReturn(teamMemberList);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/teamMembers")
                        .param("projectId", "1")
                        .requestAttr(Constants.O_ID, UUID.randomUUID().toString()))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ResponseDto<TeamMemberResponseListDto> responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testGetTeamMemberById() throws Exception {
        TeamMemberResponseListDto teamMemberResponse = new TeamMemberResponseListDto();
        when(teamMemberService.getTeamMemberById(eq(1L))).thenReturn(teamMemberResponse);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/teamMembers/1")
                        .requestAttr(Constants.O_ID, UUID.randomUUID().toString()))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ResponseDto<TeamMemberResponseListDto> responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testEditTeamMember() throws Exception {
        TeamMemberDto teamMemberDto = new TeamMemberDto();
        teamMemberDto.setName("example");
        teamMemberDto.setProjectRole("Developer");
        teamMemberDto.setLocation("Pune");
        teamMemberDto.setIsBillable(true);
        teamMemberDto.setStartDate(1620260000000L);
        teamMemberDto.setEndDate(1620370000000L);
        teamMemberDto.setAllocation(100L);
        teamMemberDto.setUserId(UUID.randomUUID());

        String teamMemberId = "12345";
        UUID userId = UUID.randomUUID();

        TeamMemberResponseDto createdTeamMember = new TeamMemberResponseDto();
        when(teamMemberService.editTeamMember(teamMemberDto, userId, utilMethods.stringToLong(teamMemberId)))
                .thenReturn(createdTeamMember);

        MockHttpServletRequestBuilder requestBuilder = put("/v1/teamMembers/{teamMemberId}",teamMemberId)
                .requestAttr("oid", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(teamMemberDto));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ResponseDto<TeamMemberResponseDto> responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testFilterTeamMember() throws Exception {
        TeamMemberFilterDto teamMemberFilterDto = new TeamMemberFilterDto();
        String projectId = "1";
        String userId = "d4682ac9-3e2c-49dd-bca4-ea784aa0eb4e";
        List<TeamMemberResponseListDto> teamMemberList = new ArrayList<>();

        when(teamMemberService.getAllTeamMembers(UUID.fromString(userId), utilMethods.stringToLong(projectId), teamMemberFilterDto))
                .thenReturn(teamMemberList);

        MockHttpServletRequestBuilder requestBuilder = post("/v1/teamMembers/filters")
                .param("projectId", projectId)
                .requestAttr(Constants.O_ID, userId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(teamMemberFilterDto));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ResponseDto<List<TeamMemberResponseListDto>> responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }
    @Test
    public void testFetchAllSkills() throws Exception {
        String projectId = "1";
        String userId = "d4682ac9-3e2c-49dd-bca4-ea784aa0eb4e";
        Set<String> skills = new HashSet<>(Arrays.asList("Java", "Spring", "SQL"));

        when(teamMemberService.getAllSkills(utilMethods.stringToLong(projectId))).thenReturn(skills);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/teamMembers/skills")
                        .param("projectId", projectId)
                        .requestAttr(Constants.O_ID, userId))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ResponseDto<Set<String>> responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }
}
