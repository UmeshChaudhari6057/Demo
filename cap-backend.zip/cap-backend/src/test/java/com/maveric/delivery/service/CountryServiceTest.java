package com.maveric.delivery.service;

import com.maveric.delivery.Entity.Country;
import com.maveric.delivery.mysqlrepository.CountrymysqlRepository;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.oauth2.jwt.JwtDecoder;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class CountryServiceTest {

    @MockBean
    private JwtDecoder jwtDecoder;

    @MockBean
    private CountrymysqlRepository countryRepository;

    @Autowired
    private CountryServiceImpl countryService;

    @MockBean
    private UtilMethods utilMethods;
    @Test
    void testGetAllCountries() {
        List<Country> countries = new ArrayList<>();
        countries.add(new Country( "India","IN"));
        countries.add(new Country( "Canada","CAN"));

        when(countryRepository.findAll()).thenReturn(countries);

        List<Country> result = countryService.getAllCountries();

        assertEquals(countries.size(), result.size());
    }
}

