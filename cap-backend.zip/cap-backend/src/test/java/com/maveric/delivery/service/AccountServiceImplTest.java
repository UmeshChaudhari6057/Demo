package com.maveric.delivery.service;

import com.maveric.delivery.exception.AccountNotFoundException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.AccountNamesResponseDto;
import com.maveric.delivery.responsedto.AccountMemberDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;


import static com.maveric.delivery.utils.Constants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class AccountServiceImplTest {

    @MockBean
    private AccountRepository accountRepository;
    @Autowired
    private AccountServiceImpl accountService;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private ProjectServiceImpl projectServiceImpl;
    @MockBean
    private UserServiceImpl userService;

    @MockBean
    private DedRolesRepository dedRolesRepository;

    @MockBean
    private UtilMethods utilMethods;

    @MockBean
    private AzureUsermysqlRepository azureUserRepository;

    @MockBean
    private RolePrivilegesServiceImpl rolePrivilegesServiceImpl;

   // @Mock
  //  private MongoTemplate mongoTemplate;


    public static Account createMockAccount() {
        Account account = new Account();
        account.setId(810203031l);
        account.setAccountName("Sample");
        account.setAccountType(AccountType.Client);
        account.setTags(List.of("Network", "IT"));
        account.setDedRoles(createMockDedRoles());
        account.setStatus(AccountStatus.Active);
        account.setExternalId("ext-123");
        account.setClientInfo(createMockClientInformation());
        account.setCreatedBy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6"));
        account.setCreatedAt(System.currentTimeMillis());
        account.setUpdatedBy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66af92"));
        account.setUpdatedAt(System.currentTimeMillis());
        return account;
    }

    private static List<DedRolesmy> createMockDedRoles() {
        List<DedRolesmy> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1"), null, 0L, "Barani", "DH"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa2"), null, 0L, "Sham", "DP"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa3"), null, 0L, "Krishna", "AP"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"), null, 0L, "Barani", "EP"));
        dedRoles.add(new DedRolesmy(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6"), null, 0L, "Ankush", "SuperAdmin"));
        return dedRoles;
    }

    private static ClientInformation createMockClientInformation() {
        ClientInformation clientInformation = new ClientInformation();
        clientInformation.setClientName("ClientName");
        clientInformation.setClientDescription("Description");
        clientInformation.setBusinessAddressLineOne("Address Line 1");
        clientInformation.setBusinessAddressLineTwo("Address Line 2");
        clientInformation.setBusinessCity("City");
        clientInformation.setBusinessState("State");
        clientInformation.setBusinessCountry("SOME COUNTRY");
        clientInformation.setContactsList(createMockClientContacts());
        return clientInformation;
    }

    private static List<ClientContacts> createMockClientContacts() {
        List<ClientContacts> clientContacts = new ArrayList<>();
        clientContacts.add(new ClientContacts("Manmath Doe", "Manager", "john.doe@example.com", "1234567890"));
        clientContacts.add(new ClientContacts("Jane Smith", "Director", "jane.smith@example.com", "1987654321"));
        return clientContacts;
    }


    private String mapRoleName(String roleName) {
        switch (roleName) {
            case "Delivery Head":
                return "DH";
            case "Account Partner":
                return "AP";
            case "Engagement Partner":
                return "EP";
            case "Delivery Partner":
                return "DP";
            default:
                return roleName;
        }
    }

    private AccountRoles mapToAccountRolesTest(List<DedRoles> dedRoles, String roleName) {
        for (DedRoles role : dedRoles) {
            if (roleName.equals(role.getRole())) {
                return new AccountRoles(role.getOid(), role.getName());
            }
        }
        return null;
    }
    private List<AccountRoles> mapToAccountRolesOrListTest(List<DedRoles> dedRoles, String roleName) {
        List<AccountRoles> accountRolesList = new ArrayList<>();
        for (DedRoles role : dedRoles) {
            if (roleName.equals(role.getRole())) {
                accountRolesList.add(new AccountRoles(role.getOid(), role.getName()));
            }
        }
        return accountRolesList;
    }


    private AccountRequestDto createSampleAccountRequestDto() {
        AccountRequestDto requestDto = new AccountRequestDto();
        requestDto.setAccountName("Sample");
        requestDto.setAccountType(AccountType.Client);
        requestDto.setTags(List.of("Tag1", "Tag2"));
        requestDto.setExternalId("ext-123");
        requestDto.setDateOnboarded(System.currentTimeMillis());
        requestDto.setStatus(AccountStatus.Active);
        requestDto.setClientInfo(createMockClientInformation());

        UUID userId1 = UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8");
        UUID userId2 = UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8");
        UUID userId3 = UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8");
        UUID userId4 = UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8");
        // Setting up sample account roles
        AccountRoles deliveryHead = new AccountRoles(userId1, "Test DH1");
        requestDto.setDeliveryHead(Collections.singletonList(deliveryHead));

        List<AccountRoles> accountPartners = List.of(new AccountRoles(userId2, "Test AP1"));
        requestDto.setAccountPartners(accountPartners);

        List<AccountRoles> engagementPartners = List.of(new AccountRoles(userId3, "Test EP1"));
        requestDto.setEngagementPartners(engagementPartners);

        List<AccountRoles> deliveryPartners = List.of(new AccountRoles(userId4, "Test DP1"));
        requestDto.setDeliveryPartners(deliveryPartners);

        return requestDto;
    }

    @Test
    void testCreateAccount_Successful() {
//// Commented out MongoDB code
//   //     when(accountRepository.existsByAccountName(anyString())).thenReturn(false);
//        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> {
//            Account savedAccount = invocation.getArgument(0);
//            savedAccount.setId(810203031l);
//            return savedAccount;
//        });
//        AzureUsers azureUser = new AzureUsers();
//        azureUser.setId(UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"));
//        azureUser.setDisplayName("i am here");
//
//        when(azureUserRepository.findById(UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"))).thenReturn(Optional.of(azureUser));
//        AccountRequestDto requestDto = createSampleAccountRequestDto();
//        when(userService.getHighestRole(UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"),null,null)).thenReturn(SUPER_ADMIN_);
//        AccountResponseDto createdAccount = accountService.createAccount(requestDto,UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"));
//        assertNotNull(createdAccount);
//        assertEquals("Sample", createdAccount.getAccountName());
//        assertEquals(810203031l, createdAccount.getAccountId());
//
//        verify(accountRepository, times(1)).existsByAccountName("Sample");
//        verify(accountRepository, times(1)).save(any(Account.class));
    }

    @Test
    void testGetAccountById_ExistingId() {
    	//// Commented out MongoDB code
//        UUID oid= UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6");
//        List<PrivilegesDetailsDto> privilegeList = new ArrayList<PrivilegesDetailsDto>();
//        PrivilegesDetailsDto privilegesDetailsDto = new PrivilegesDetailsDto();
//        privilegesDetailsDto.setName("Accounts");
//        privilegesDetailsDto.setPrivilegesList(List.of("Some access", "Some other access"));
//        privilegeList.add(privilegesDetailsDto);
//
//        privilegesDetailsDto = new PrivilegesDetailsDto();
//        privilegesDetailsDto.setName("Projects");
//        privilegesDetailsDto.setPrivilegesList(List.of("Some access", "Some other access"));
//        privilegeList.add(privilegesDetailsDto);
//
//        List<String> privList = List.of("AA","BB");
//
//
//        when(accountRepository.findById(810203031L)).thenReturn(Optional.of(createMockAccount()));
//        when(userService.getHighestRole(oid,null,null)).thenReturn(SUPER_ADMIN_);
//        // when(utilMethods.dummyGetPrivileges(SUPER_ADMIN,List.of(ACCOUNTS, PROJECTS))).thenReturn(privilegeList);
//        // when(utilMethods.getPrivilegesString(SUPER_ADMIN,List.of(ACCOUNTS, PROJECTS))).thenReturn(privList);
//        when(dedRolesRepository.findByOidAndProject_IdAndAccount_Id(oid,1L,1L)).thenReturn(new ArrayList<DedRolesmy>());
//        AccountResponseDto accountResponseDto = accountService.getAccountById(810203031L,oid);
//        assertNotNull(accountResponseDto);

    }
    @Test
    void testGetAccountById_ExistingId_ACCOUNT_ADMIN() {
//        UUID oid= UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6");
//        when(accountRepository.findById(anyLong())).thenReturn(Optional.of(createMockAccount()));
//        when(userService.getHighestRole(oid, null,null)).thenReturn("ACCOUNT_ADMIN");
//        when(userService.getHighestRole(oid,810203031L,null)).thenReturn("ACCOUNT_ADMIN");
//        AccountResponseDto accountResponseDto = accountService.getAccountById(810203031L,oid);
//        assertNotNull(accountResponseDto);

    }

    @Test
    void testGetAccountById_NonExistingId() {
//        UUID oid=UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6");
//        when(accountRepository.findById(anyLong())).thenReturn(Optional.empty());
//        assertThrows(AccountNotFoundException.class, () -> {
//            accountService.getAccountById(999L,oid);
//        });
    }


    @Test
    void testEditAccount_AccountNotFound() {
//        Long accountId = 123L;
//        AccountRequestDto requestDto = new AccountRequestDto();
//        when(accountRepository.findById(accountId)).thenReturn(Optional.empty());
//        assertThrows(AccountNotFoundException.class, () -> accountService.editAccount(requestDto, accountId,UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8")));
//        verify(accountRepository, times(1)).findById(accountId);
//        verify(accountRepository, never()).save(any(Account.class));
    }



    @Test
    void testDuplicateAccountName_Duplicated() {
//        when(accountRepository.findByAccountNameIgnoreCase(anyString())).thenReturn(Arrays.asList(createMockAccount()));
//        boolean result = accountService.duplicateAccountName("Sample");
//        assertTrue(result);
    }

    @Test
    void testDuplicateAccountName_NotDuplicated() {
//        when(accountRepository.findByAccountNameIgnoreCase(anyString())).thenReturn(Collections.emptyList());
//        boolean result = accountService.duplicateAccountName("NonDuplicate");
//        assertFalse(result);
    }


    @Test
    public void testEditAccount_ExistingAccount() throws Exception {
//        Long accountId = 810203031L;
//        Account mockAccount = createMockAccount();
//        AccountRequestDto requestDto = new AccountRequestDto();
//        requestDto.setAccountName("Updated Sample");
//        requestDto.setAccountType(AccountType.Client);
//        requestDto.setTags(List.of("Network", "ITS"));
//        AccountRoles deliveryHead = new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1"), "Test DH1");
//        requestDto.setDeliveryHead(Collections.singletonList(deliveryHead));
//        List<AccountRoles> accountPartners = Arrays.asList(
//                new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa2"), "Test AP1")
//        );
//        requestDto.setAccountPartners(accountPartners);
//        List<AccountRoles> engagementPartners = Arrays.asList(
//                new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa3"), "Test EP1")
//        );
//        requestDto.setEngagementPartners(engagementPartners);
//        List<AccountRoles> deliveryPartners = Arrays.asList(
//                new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"), "Test DP1")
//        );
//        requestDto.setDeliveryPartners(deliveryPartners);
//        requestDto.setStatus(AccountStatus.Active);
//        requestDto.setExternalId("ext-123");
//        requestDto.setClientInfo(createMockClientInformation());
//        requestDto.setDateOnboarded(System.currentTimeMillis());
//        when(accountRepository.findById(accountId)).thenReturn(Optional.of(mockAccount));
//        when(accountRepository.existsByAccountName(requestDto.getAccountName())).thenReturn(false);
//        when(accountRepository.save(any(Account.class))).thenReturn(mockAccount);
//
//       // when(utilMethods.checkAndAddUserId( new HashSet<>(),"3fa85f64-5717-4562-b3fc-2c963f66afa4")).thenReturn(new HashSet<>());
//        when(userService.getHighestRole(UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"),null,null)).thenReturn(SUPER_ADMIN_);
//       // when(userService.getDisplayName(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"))).thenReturn("my name");
//        AccountResponseDto editedAccount = accountService.editAccount(requestDto, accountId,UUID.fromString("1ef314e9-8fe9-4198-8fa0-4ecdeb954af8"));
//
//        assertNotNull(editedAccount);
//        assertEquals(accountId, editedAccount.getAccountId());
//        assertNotEquals("Sample", editedAccount.getAccountName());
//        verify(accountRepository, times(1)).findById(accountId);
//        verify(accountRepository, times(1)).existsByAccountName(requestDto.getAccountName());
    }

//    @Test
    public void testGetAllAccountsByOid_SuperAdmin() throws Exception {
//        UUID userId = UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1");
//        Mockito.when(userService.getHighestRole(userId, null, null)).thenReturn(SUPER_ADMIN_);
//
//        List<Account> mockAccounts = Arrays.asList(createMockAccount());
//        Mockito.when(mongoTemplate.find(any(Query.class), eq(Account.class))).thenReturn(mockAccounts);
////        Mockito.when(accountRepository.findAll()).thenReturn(mockAccounts);
//        // Mockito.when(accountRepository.findById(1L)).thenReturn(Optional.of(new Account()));
//        List<AccountSummaryDto> accountSummaries = accountService.getAllAccounts(userId,new AccountFilterDto());
//        assertNotNull(accountSummaries);
    }

    
    //This test case is already commented not related to Mongo
   /* @Test
    public void testGetCountOfAccountByOidSuperAdmin() throws Exception {

        UUID userId = UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1");

        DedRoles dedRoles1 = new DedRoles();
        dedRoles1.setAccountId(1L);
        dedRoles1.setOid(userId);
        dedRoles1.setRole("DH");
        DedRoles dedRoles2 = new DedRoles();
        dedRoles2.setAccountId(2L);

        List<DedRoles> dedRolesList = new ArrayList<>();
        dedRolesList.add(dedRoles1);
        //dedRolesList.add(dedRoles2);



       // when(accountRepository.count()).thenReturn(10L);
        when(userService.getHighestRole(userId,null, null)).thenReturn(SUPER_ADMIN_);

        List<Account> mockAccounts = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Account a = new Account();
            a.setDedRoles(dedRolesList);
            a.setId((long) i);

            mockAccounts.add(a); // Add mock Account objects as needed
        }
        when( accountRepository.findAll()).thenReturn(mockAccounts);
        when(dedRolesRepository.findByOid(userId)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndAccountId(userId, 1L)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(userId, 1L,2L)).thenReturn(dedRolesList);

        AccountSummaryCountDto result = accountService.getCountOfAccountByuserId(userId);
        assertEquals(0, result.getAccounts());
        assertEquals(0, result.getProjects());
        assertEquals(0, result.getTeamMembers());
        assertEquals(0, result.getArtifacts());
        assertEquals(0, result.getAssessmentCompleted());
    }

    @Test
    public void testGetCountOfAccountByOidSuperDH() throws Exception {

        UUID userId = UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1");

        DedRoles dedRoles1 = new DedRoles();
        dedRoles1.setAccountId(1L);
        dedRoles1.setOid(userId);
        dedRoles1.setRole("DH");
        DedRoles dedRoles2 = new DedRoles();
        dedRoles2.setAccountId(2L);

        List<DedRoles> dedRolesList = new ArrayList<>();
        dedRolesList.add(dedRoles1);
        //dedRolesList.add(dedRoles2);



        // when(accountRepository.count()).thenReturn(10L);
        when(userService.getHighestRole(userId,null, null)).thenReturn("DH");

        List<Account> mockAccounts = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Account a = new Account();
            a.setDedRoles(dedRolesList);
            a.setId((long) i);

            mockAccounts.add(a); // Add mock Account objects as needed
        }

        List<PrivilegesDetailsDto> privilegesDtoList = new ArrayList<PrivilegesDetailsDto>();
        PrivilegesDetailsDto privilegesDto = new PrivilegesDetailsDto();
        privilegesDto.setPrivileges(List.of(ACCOUNTS_VIEW_ALL));
        privilegesDtoList.add(privilegesDto);


        when( accountRepository.findAll()).thenReturn(mockAccounts);
        when(dedRolesRepository.findByOid(userId)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndAccountId(userId, 1L)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(userId, 1L,2L)).thenReturn(dedRolesList);

        when(utilMethods.getPrivilegesString("DH", List.of(ACCOUNTS))).thenReturn(List.of(ACCOUNTS_VIEW_ALL));
        when(rolePrivilegesServiceImpl.findByGroup( List.of("ACCOUNTS"), "DH")).thenReturn(privilegesDtoList);

        AccountSummaryCountDto result = accountService.getCountOfAccountByuserId(userId);
        assertEquals(0, result.getAccounts());
        assertEquals(0, result.getProjects());
        assertEquals(0, result.getTeamMembers());
        assertEquals(0, result.getArtifacts());
        assertEquals(0, result.getAssessmentCompleted());
    }*/


    /*@Test
    public void testGetCountOfAccountByOidSuperDHACCOUNTS_VIEW_ASSOCIATED() throws Exception {

        UUID userId = UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1");

        DedRoles dedRoles1 = new DedRoles();
        dedRoles1.setAccountId(1L);
        dedRoles1.setOid(userId);
        dedRoles1.setRole("DH");
        DedRoles dedRoles2 = new DedRoles();
        dedRoles2.setAccountId(2L);

        List<DedRoles> dedRolesList = new ArrayList<>();
        dedRolesList.add(dedRoles1);
        //dedRolesList.add(dedRoles2);



        // when(accountRepository.count()).thenReturn(10L);
        when(userService.getHighestRole(userId,null, null)).thenReturn("DH");

        List<Account> mockAccounts = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Account a = new Account();
            a.setDedRoles(dedRolesList);
            a.setId((long) i);

            mockAccounts.add(a); // Add mock Account objects as needed
        }

        List<PrivilegesDetailsDto> privilegesDtoList = new ArrayList<PrivilegesDetailsDto>();
        PrivilegesDetailsDto privilegesDto = new PrivilegesDetailsDto();
        privilegesDto.setPrivileges(List.of(ACCOUNTS_VIEW_ASSOCIATED));
        privilegesDtoList.add(privilegesDto);


        when( accountRepository.findAll()).thenReturn(mockAccounts);
        when(dedRolesRepository.findByOid(userId)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndAccountId(userId, 1L)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(userId, 1L,2L)).thenReturn(dedRolesList);

        when(utilMethods.getPrivilegesString("DH", List.of(ACCOUNTS))).thenReturn(List.of(ACCOUNTS_VIEW_ASSOCIATED));
        when(rolePrivilegesServiceImpl.findByGroup( List.of("ACCOUNTS"), "DH")).thenReturn(privilegesDtoList);

        when(accountRepository.findById(1L)).thenReturn(Optional.of(mockAccounts.get(0)));

        AccountSummaryCountDto result = accountService.getCountOfAccountByuserId(userId);
        assertEquals(0, result.getAccounts());
        assertEquals(0, result.getProjects());
        assertEquals(0, result.getTeamMembers());
        assertEquals(0, result.getArtifacts());
        assertEquals(0, result.getAssessmentCompleted());
    }*/

   /* @Test
    public void testGetCountOfProjectsByOidSuperAdmin() throws Exception {

        UUID userId = UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1");

        DedRoles dedRoles1 = new DedRoles();
        dedRoles1.setAccountId(1L);
        dedRoles1.setOid(userId);
        dedRoles1.setRole("DH");
        dedRoles1.setProjectId(1L);
        DedRoles dedRoles2 = new DedRoles();
        dedRoles2.setAccountId(2L);

        List<DedRoles> dedRolesList = new ArrayList<>();
        dedRolesList.add(dedRoles1);
        //dedRolesList.add(dedRoles2);
        // when(accountRepository.count()).thenReturn(10L);
        when(userService.getHighestRole(userId,null, null)).thenReturn(SUPER_ADMIN_);

        List<Account> mockAccounts = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Account a = new Account();
            a.setDedRoles(dedRolesList);
            a.setId((long) i);

            mockAccounts.add(a); // Add mock Account objects as needed
        }
        when(projectServiceImpl.getProjectId(userId, 0L,null).getProjectsList().size()).thenReturn(3);
        when( accountRepository.findAll()).thenReturn(mockAccounts);
        when( dedRolesRepository.findAll()).thenReturn(dedRolesList);

        when(dedRolesRepository.findByOid(userId)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndAccountId(userId, 1L)).thenReturn(dedRolesList);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(userId, 1L,2L)).thenReturn(dedRolesList);

        AccountSummaryCountDto result = accountService.getCountOfAccountByuserId(userId);
        assertEquals(10, result.getAccounts());
        assertEquals(0, result.getTeamMembers());
        assertEquals(0, result.getArtifacts());
        assertEquals(0, result.getAssessmentCompleted());
    }*/

    @Test
    public void testGetAccountsListForSuperAdminRole() throws Exception {
    	// Commented out MongoDB code
//        UUID userId = UUID.randomUUID();
//        when(userService.getHighestRole(userId, null, null)).thenReturn("SUPER_ADMIN");
//        List<Account> allAccounts = new ArrayList<>();
//        when(accountRepository.findAll()).thenReturn(allAccounts);
//        AccountNamesResponseDto accountNamesResponseDto = accountService.getAccountsList(userId);
//        assertEquals(allAccounts.size(), accountNamesResponseDto.getAccountListDtoList().size());

    }



    @Test
    public void testGetAccountName() {

        List<Long> accountIdList = new ArrayList<>();
        accountIdList.add(1L);
        accountIdList.add(2L);

        Account account1 = new Account();
        account1.setId(1L);
        account1.setAccountName("Account 1");

        Account account2 = new Account();
        account2.setId(2L);
        account2.setAccountName("Account 2");
      //// Commented out MongoDB code
      //  when(accountRepository.findById(1L)).thenReturn(Optional.of(account1));
      //  when(accountRepository.findById(2L)).thenReturn(Optional.of(account2));


        List<AccountListDto> accountList = accountService.getAccountDetails(accountIdList);


        assertEquals(2, accountList.size());
        assertEquals(1L, accountList.get(0).getId());
        assertEquals("Account 1", accountList.get(0).getName());
        assertEquals(2L, accountList.get(1).getId());
        assertEquals("Account 2", accountList.get(1).getName());
    }

    @Test
    public void testGetAccountNameWithEmptyList() {

        List<Long> accountIdList = Collections.emptyList();

        List<AccountListDto> accountList = accountService.getAccountDetails(accountIdList);

        assertEquals(0, accountList.size());
    }



    @Test
    public void testGetAccountId() {

        UUID oid = UUID.randomUUID();
        List<Long> expectedAccountIdList = new ArrayList<>();
        expectedAccountIdList.add(1L);
        expectedAccountIdList.add(2L);

        DedRolesmy dedRoles1 = new DedRolesmy();
        dedRoles1.setAccountId(1L);

        DedRolesmy dedRoles2 = new DedRolesmy();
        dedRoles2.setAccountId(2L);

        List<DedRolesmy> resultAccount = new ArrayList<>();
        resultAccount.add(dedRoles1);
        resultAccount.add(dedRoles2);

        when(dedRolesRepository.findByOid(oid)).thenReturn(resultAccount);


        List<Long> accountIdList = accountService.getAccountId(oid);

        assertEquals(expectedAccountIdList, accountIdList);
    }

    @Test
    public void testGetAccountIdWithEmptyResult() {

        UUID oid = UUID.randomUUID();
        when(dedRolesRepository.findByOid(oid)).thenReturn(Collections.emptyList());

        List<Long> accountIdList = accountService.getAccountId(oid);

        assertEquals(Collections.emptyList(), accountIdList);
    }


    @Test
    public void testConvertToAccountListDto() {

        Account account = new Account();
        account.setId(123L);
        account.setAccountName("Test Account");

        AccountListDto dto = accountService.convertToAccountListDto(account);

        assertNotNull(dto);
        assertEquals(123, dto.getId());
        assertEquals("Test Account", dto.getName());
    }

    @Test
    public void testGetAccountMembers() {
        Long accountId = 1L;
        List<DedRolesmy> dedRolesList = new ArrayList<>();
        DedRolesmy dedRole1 = new DedRolesmy();
        dedRole1.setRole("AP");
        dedRole1.setName("Account Partner");
        DedRolesmy dedRole2 = new DedRolesmy();
        dedRole2.setRole("EP");
        dedRole2.setName("Engagement Partner");
        dedRolesList.add(dedRole1);
        dedRolesList.add(dedRole2);
        when(dedRolesRepository.findByAccount_IdAndProject_IdIsNull(accountId)).thenReturn(dedRolesList);

        AccountMemberDto accountMemberDto = accountService.getAccountMembers(accountId);

        assertEquals(1, accountMemberDto.getAccountPartners().size());
        assertEquals("Account Partner", accountMemberDto.getAccountPartners().get(0).getName());
        assertEquals(1, accountMemberDto.getEngagementPartners().size());
        assertEquals("Engagement Partner", accountMemberDto.getEngagementPartners().get(0).getName());
        verify(dedRolesRepository, times(1)).findByAccount_IdAndProject_IdIsNull(accountId);
    }
}










