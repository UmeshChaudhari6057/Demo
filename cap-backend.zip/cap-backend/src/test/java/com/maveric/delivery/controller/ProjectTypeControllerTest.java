package com.maveric.delivery.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ProjectTypeService;

@WebMvcTest(ProjectTypeController.class)
@ExtendWith(SpringExtension.class)
class ProjectTypeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ProjectTypeController projectTypeController;

    @MockBean
    private ProjectTypeService projectTypeService;
    @MockBean
    private AuditmysqlRepository auditRepository;

    @MockBean
    private AzureUsermysqlRepository azureUserRepository;

    @MockBean
    AuditImpl auditImpl;


    @Test
    void testFetchAllProjectType() {
        List<BaseDto> projectTypes = new ArrayList<>();
        projectTypes.add(new BaseDto(1L, "Agile"));
        projectTypes.add(new BaseDto(2L, "DevOps"));

        List<BaseDto> baseDtoList=new ArrayList<>();


        when(projectTypeService.fetchAllProjectType()).thenReturn(projectTypes);

        ResponseDto responseDto = projectTypeController.fetchAllProjectType().getBody();

        assertEquals("Success", responseDto.getStatus());
        assertEquals(projectTypes, responseDto.getPayload());
        verify(projectTypeService, times(1)).fetchAllProjectType();
    }

    @Test
    void testFetchAllProjectTypeEmptyList() {
        when(projectTypeService.fetchAllProjectType()).thenReturn(Collections.emptyList());

        ResponseDto responseDto = projectTypeController.fetchAllProjectType().getBody();

        assertEquals("Failed", responseDto.getStatus());
        assertEquals(Collections.emptyList(), responseDto.getPayload());
    }

//    @Test
//    void testSaveProjectType() throws Exception {
//        ProjectTypeDto requestPayload = new ProjectTypeDto();
//        requestPayload.setName("example");
//        requestPayload.setDescription("description");
//
//        ProjectType savedProjectType = new ProjectType("example", "description");
//        String content = new ObjectMapper().writeValueAsString(requestPayload);
//        when(projectTypeService.saveProjectType(any(ProjectTypeDto.class))).thenReturn(savedProjectType);
//
//        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/projectTypes")
//                .contentType(MediaType.APPLICATION_JSON)
//                .accept(MediaType.APPLICATION_JSON)
//                .content(content);
//
//        mockMvc.perform(requestBuilder)
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON));
//    }
}
