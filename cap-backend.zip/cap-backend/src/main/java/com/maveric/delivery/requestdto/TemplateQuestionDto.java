package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.maveric.delivery.model.embedded.*;
import jakarta.validation.constraints.*;
import lombok.*;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TemplateQuestionDto {

    private int number;
    @NotBlank(message = "Question text is required")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- /?%\":#'+*=]+$", message = "Question can only contain alphabets, numbers, comma, dot, &, (),/,?,%,\",:,#,',+,*,= and hyphen")
    @Size(min = 3,max = 500, message = "Question must be between 3 and 500 characters")
    private String questionText;
    @Size(min = 3,max = 500, message = "Sub title must be between 3 and 500 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- /?%\":#'+*=]+$", message = "Sub title can only contain alphabets, numbers, comma, dot, &, (),/,?,%,\",:,#,',+,*,= and hyphen")
    private String subHeading;
    private boolean attachmentRequired;
    private QuestionType type;
    private CheckBoxOptions checkBoxOptions;
    private RadioOptions radioOptions;
    private Numerical numerical;
    private Slider slider;
    @JsonProperty("isNotApplicable")
    private boolean isNotApplicable;
    @Min(value = 1, message = "weightage must be at least 1")
    @Max(value = 5, message = "weightage must be at most 5")
    @NotNull(message = "Weightage is required")
    private Integer weightage;
}
