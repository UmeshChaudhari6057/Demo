package com.maveric.delivery.migration;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.mysqlrepository.DeaRolesmysql;
import com.maveric.delivery.utils.JsonFileReader;

//import io.mongock.api.annotations.ChangeUnit;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@Service
//@ChangeUnit(id = "DedRoles-v.0.2", order = "001", author = "delivery-excellence", systemVersion = "1")
public class DedRolesMigration implements Migration{
  //  private final MongoTemplate mongoTemplate;
	
	DeaRolesmysql deaRolesmysqlRepository;
	
    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/dedRoles.json";


 //   @BeforeExecution
    @Override
    public void before() {
        log.info("dedRoles Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
  //  @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("dedRoles Migration RollbackBeforeExecution");
    }
    @Transactional
  //  @Execution
    @Override
    public void migrationMethod() throws IOException {
        log.info("mongock migrationMethod");
//        mongoTemplate.remove(new Query(), DedRoles.class);
//        List<DedRoles> roles= jsonFileReader.readJsonFileToList(filePath, DedRoles.class);
//        mongoTemplate.insertAll(roles);
//        
        deaRolesmysqlRepository.deleteAll();
        
        try {
            List<DedRolesmy> roles = jsonFileReader.readJsonFileToList(filePath, DedRolesmy.class);

            if (!roles.isEmpty()) {
            	deaRolesmysqlRepository.saveAll(roles);
                log.info("Migration completed: {} records inserted", roles.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
        
    }

  //  @RollbackExecution
    @Override
    public void rollback() {
        log.info("dedRoles Migration RollbackBeforeExecution");
        deaRolesmysqlRepository.deleteAll();
    }

}
