package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.Privileges;

public interface PrivilegesmysqlRepository extends JpaRepository<Privileges,Long> {

}
