package com.maveric.delivery.mysqlrepository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.DeliveryImpact;

public interface DeliveryImpactmysqlRepository extends JpaRepository<DeliveryImpact, Long> {
    
    Optional<DeliveryImpact> findByProjectId(Long projectId);

    List<DeliveryImpact> findByProjectIdIn(Set<Long> projectId);
}
