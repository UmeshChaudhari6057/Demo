package com.maveric.delivery.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * @author ankushk
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserRolesDto {
    private UUID oid;
    private String name;
    private String role;
}
