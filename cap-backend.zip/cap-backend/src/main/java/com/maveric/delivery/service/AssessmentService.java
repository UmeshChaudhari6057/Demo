package com.maveric.delivery.service;



import static com.maveric.delivery.utils.Constants.*;


import java.io.IOException;
import java.text.DecimalFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Criteria;
//import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.exception.AssessmentException;
import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.exception.ValidationException;
import com.maveric.delivery.mapper.AssessmentDraftMapper;
import com.maveric.delivery.mapper.QuestionMapper;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Assessment;
import com.maveric.delivery.Entity.AssessmentDraft;
import com.maveric.delivery.Entity.AssessmentHistory;
import com.maveric.delivery.Entity.AssessmentSharePointDetails;
import com.maveric.delivery.Entity.AssessmentsSchedulerFailedLogs;
import com.maveric.delivery.Entity.IdentifiedEntity;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.ProjectAssessmentDetails;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.model.embedded.Numerical;
import com.maveric.delivery.model.embedded.Option;
import com.maveric.delivery.model.embedded.ProjectStatus;
//import com.maveric.delivery.model.embedded.Question;
//import com.maveric.delivery.model.embedded.MyQuestion;
import com.maveric.delivery.Entity.Question;
import com.maveric.delivery.model.embedded.QuestionType;
import com.maveric.delivery.model.embedded.Range;
import com.maveric.delivery.model.embedded.Slider;
import com.maveric.delivery.model.embedded.MyTemplateCategory;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.mysqlrepository.AssessmentDraftmysqlRepository;
import com.maveric.delivery.mysqlrepository.AssessmentHistorymysqlRepository;
import com.maveric.delivery.mysqlrepository.AssessmentmysqlRepository;
import com.maveric.delivery.repository.AssessmentSharePointRepository;
import com.maveric.delivery.mysqlrepository.AssessmentsSchedulerFailedLogsmysqlRepository;
import com.maveric.delivery.mysqlrepository.EmailDetailsmysqlRepository;
import com.maveric.delivery.mysqlrepository.ProjectAssessmentDetailsmysqlRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.requestdto.AssessmentCategoryWiseRequestDto;
import com.maveric.delivery.requestdto.AssessmentDraftRequestDto;
import com.maveric.delivery.requestdto.AssessmentFilterDto;
import com.maveric.delivery.requestdto.AssessmentSharePointRequest;
import com.maveric.delivery.requestdto.DateRangeDto;
import com.maveric.delivery.requestdto.QuestionDto;
import com.maveric.delivery.requestdto.ReviewAssessmentRequestDto;
import com.maveric.delivery.requestdto.ReviewComments;
import com.maveric.delivery.requestdto.SendEmailDetailsDto;
import com.maveric.delivery.responsedto.AssessmentResponseDto;
import com.maveric.delivery.responsedto.AssessmentSharePointResponse;
import com.maveric.delivery.responsedto.AssessmentTrendsDetailsDto;
import com.maveric.delivery.responsedto.AttachmentDownloadDto;
import com.maveric.delivery.responsedto.ChartDto;
import com.maveric.delivery.responsedto.ChartXAxisDataDto;
import com.maveric.delivery.responsedto.JobNotificationDetails;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SharepointUtils;
import com.maveric.delivery.utils.UtilMethods;
import com.microsoft.graph.models.DriveItem;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Service
@RequiredArgsConstructor
@Slf4j
public class AssessmentService {

    private final AssessmentmysqlRepository assessmentRepository;
    private final SharepointUtils sharepointUtils;
//    private final ProjectRepository projectRepository;
  //  private final AssessmentSharePointRepository assessmentSharePointRepository;
    private final AssessmentHistorymysqlRepository assessmentHistoryRepository;
    private final UtilMethods utilMethods;
  //  private final MongoTemplate mongoTemplate;
    private final AssessmentsSchedulerFailedLogsmysqlRepository assessmentsSchedulerFailedLogsRepository;
    private final AssessmentCreationAndNotification assessmentCreationAndNotification;
    private final ProjectAssessmentDetailsmysqlRepository projectAssessmentDetailsRepository;
    private final EmailDetailsmysqlRepository emailDetailsRepository;
    private final EmailService emailService;
    private final AzureUsermysqlRepository azureUserRepository;
    private final DecimalFormat formatter = new DecimalFormat("##0.00");
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    //private final AccountRepository accountRepository;
    private final AssessmentDraftmysqlRepository assessmentDraftRepository;
    @Autowired
    private Validator validator;

    @Value("${maveric.de-dashboard.sharepoint.driver.itemId}")
    private String driverItemId;

    @Value("${maveric.de-dashboard.sharepoint.allowedFileFormat}")
    List<String> allowedAssessmentFileFormat;

    public AssessmentCategoryWiseRequestDto saveAssessment(AssessmentCategoryWiseRequestDto assessmentCategoryWiseRequestDto,
                                                           Long assessmentId, Long projectId, UUID userId) {
//        Optional<Assessment> assessmentOptional = assessmentRepository.findByIdAndProjectId(assessmentId, projectId);
//        Optional<Project> projectOptional = projectRepository.findById(projectId);
//        if (assessmentOptional.isPresent() && projectOptional.isPresent()) {
//            Assessment assessment = assessmentOptional.get();
//            Project project = projectOptional.get();
//            if (!userId.equals(assessment.getUserId())) {
//                throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
//            }
//            if (validateAssessmentStatus(assessment.getStatus())) {
//                MyTemplateCategory templateCategory = new MyTemplateCategory();
//
//                BeanUtils.copyProperties(assessmentCategoryWiseRequestDto, templateCategory);
//                List<MyTemplateCategory> templateCategoryList = assessment.getTemplateCategories();
//                for (MyTemplateCategory category : templateCategoryList) {
//                    if (category.getName().equals(assessmentCategoryWiseRequestDto.getCategoryType())) {
//                        //validate questions
//                        validateAndUpdateTemplateCategory(category, templateCategoryList, assessmentCategoryWiseRequestDto, assessmentId);
//                        break;
//                    }
//                }
//                assessment.setTemplateCategories(templateCategoryList);
//                if (assessmentCategoryWiseRequestDto.getSubmitAssessment()) {
//                    long epochMilli = LocalDate.now().atStartOfDay(ZoneId.systemDefault())
//                            .toInstant().toEpochMilli();
//                    assessment.setSubmittedOn(epochMilli);
//                    AssessmentHistory assessmentHistory = AssessmentHistory.builder().assessmentId(assessmentId)
//                            .projectId(projectId)
//                            .accountId(assessment.getAccountId())
//                            .assessmentStartDate(assessment.getInitiatedOn())
//                            .previousStatus(assessment.getStatus())
//                            .currentStatus(AssessmentStatus.SUBMITTED)
//                            .createDate(epochMilli)
//                            .createdBy(utilMethods.getDisplayName(userId))
//                            .build();
//                    assessment.setStatus(AssessmentStatus.SUBMITTED);
//                    for (DedRolesmy dedRoles : project.getDedRoles()) {
//                        if (dedRoles.getRole().equals(DP)) {
//                            assessment.setReviewerId(dedRoles.getOid());
//                            assessment.setReviewerName(dedRoles.getName());
//                        }
//                    }
//                    assessmentHistoryRepository.save(assessmentHistory);
//                }
//                assessmentRepository.save(assessment);
//                //update the draft up to date.
//               Optional<AssessmentDraft> assessmentDraft = assessmentDraftRepository.findByAssessmentId(assessmentId);
//                assessmentDraft.ifPresent(draft -> {
//                    Long draftId = draft.getId();
//                    draft = AssessmentDraftMapper.MAPPER.fromAssessment(assessment);
//                    draft.setAssessmentId(assessmentId);
//                    draft.setId(draftId);
//                    assessmentDraftRepository.save(draft);
//                });
//
//                if (Boolean.TRUE.equals(assessmentCategoryWiseRequestDto.getSubmitAssessment())) {
//                    try {
//                        assessmentCreationAndNotification.sendEmailDetails(assessment, project, ASSESSMENT_SUBMISSION_SUBJECT, SUBMITTED_ASSESSMENT_TEMPLATE, ASSESSMENT_SUBMISSION, null,"ASSESSMENT_SUBMISSION_EMAIL");
//                        assessmentCreationAndNotification.sendEmailDetails(assessment, project, REVIEW_ASSESSMENT_SUBJECT, REVIEW_ASSESSMENT_TEMPLATE, REVIEW_ASSESSMENT, null,"ASSESSMENT_REVIEW_EMAIL");
//                    } catch (Exception e) {
//                        log.error("An error occurred while sending email for Assessment ID: {}", assessment.getId(), e);
//                    }
//                }
//                log.info("User response saved successfully for - " + assessmentCategoryWiseRequestDto.getCategoryType());
//                return assessmentCategoryWiseRequestDto;
//            } else {
//                throw new CustomException("Assessment status is not valid for edit ", HttpStatus.FORBIDDEN);
//            }
//        } else {
//            throw new CustomException("Combination of assessment and project not found", HttpStatus.NOT_FOUND);
//        }
    	return new AssessmentCategoryWiseRequestDto();
    }

    private void validateAndUpdateTemplateCategory(MyTemplateCategory category,
                                                   List<MyTemplateCategory> templateCategoryList,
                                                   AssessmentCategoryWiseRequestDto sectionWiseRequestDto, Long assessmentId) {
        List<Question> questionList = new ArrayList<>();
        log.info("Question level validation started");
        if (category.getQuestions().size() != sectionWiseRequestDto.getQuestions().size()) {

            throw new AssessmentException("The number of questions in the template is not matching with the assessment question");

        } else {
            category.getQuestions().sort(Comparator.comparing(Question::getNumber));
            sectionWiseRequestDto.getQuestions().sort(Comparator.comparing(QuestionDto::getNumber));
            for (int i = 0; i < category.getQuestions().size(); i++) {
                String text1 = category.getQuestions().get(i).getQuestionText().trim();
                String text2 = sectionWiseRequestDto.getQuestions().get(i).getQuestionText().trim();
                if (!text1.equals(text2)) {

                    throw new AssessmentException("The question text in the template is not matching with the assessment questions");

                } else if (!category.getQuestions().get(i).getType().
                        equals(sectionWiseRequestDto.getQuestions().get(i).getType())) {
                    throw new AssessmentException("The question type in the template is not matching with the assessment questions");
                }
                Question question = validateUserResponse(sectionWiseRequestDto.getQuestions().get(i), category.getQuestions().get(i));
                //Due to Mongo Migration code is commited
//                Optional<AssessmentSharePointDetails> sharePointDetailsOptional = assessmentSharePointRepository.findByAssessmentIdAndQuestionNumberAndAssessmentCategoryType(assessmentId, sectionWiseRequestDto.getQuestions().get(i).getNumber(), sectionWiseRequestDto.getCategoryType());
//                if (sharePointDetailsOptional.isPresent()) {
//                    question.setDocumentId(sharePointDetailsOptional.get().getDocumentId());
//                    question.setFileName(sharePointDetailsOptional.get().getFileName());
//                }
                questionList.add(question);
            }
        }
        templateCategoryList.remove(category);
        category.setQuestions(questionList);
        templateCategoryList.add(category);
        log.info("Question level validation completed");
    }

    private Question validateUserResponse(QuestionDto questionDto, Question question) {
        if (!questionDto.isNotApplicableUserResponse()) {
            BeanUtils.copyProperties(questionDto, question);
            AtomicReference<Double> questionLevelScore = new AtomicReference<>();
            if (questionDto.getType().equals(QuestionType.CHECK_BOX)) {
                //From request
                List<Option> options = questionDto.getCheckBoxOption();
                //Fetched from DB
                List<Option> optionsList = question.getCheckBoxOptions().getOptions();

                if (options.isEmpty()) {
                    throw new AssessmentException("Atleast one option should be selected");
                }

                Map<Integer, Option> list2Map = options.stream()
                        .collect(Collectors.toMap(Option::getIndex, option -> option));

                // Replace the values in list1 with the values from list2 where index matches
                optionsList.forEach(option -> {
                    if (list2Map.containsKey(option.getIndex())) {
                        Option newOption = list2Map.get(option.getIndex());
                        if (!newOption.isSelected()) {
                            throw new AssessmentException("Unanswered option found in the request");
                        }
                        questionLevelScore.set(questionLevelScore.get() == null ? option.getScore() : questionLevelScore.get() + option.getScore());
                        option.setSelected(true);
                    } else {
                        option.setSelected(false);
                    }
                });
                question.getCheckBoxOptions().setOptions(optionsList);
            } else if (questionDto.getType().equals(QuestionType.RADIO_BUTTON)) {
                Option option = questionDto.getRadioOption();
                if (option == null || !option.isSelected()) {
                    throw new AssessmentException("Select any one of the option");
                }
                List<Option> optionsList = question.getRadioOptions().getOptions();
                List<Option> newOptionList = new ArrayList<>();
                for (Option option1 : optionsList) {
                    if (option1.getIndex() == option.getIndex()) {
                        option.setScore(option1.getScore());
                        newOptionList.add(option);
                        questionLevelScore.set(option1.getScore());
                    } else {
                        option1.setSelected(false);
                        newOptionList.add(option1);
                    }
                }
                question.getRadioOptions().setOptions(newOptionList);
            } else if (questionDto.getType().equals(QuestionType.NUMERICAL)) {
                Numerical value = question.getNumerical();
                validateNumericalResponse(value.getMax(), value.getMin(), questionDto.getValue());
                value.setValue(questionDto.getValue());
                questionLevelScore.set(getScore(value.getRange(), questionDto.getValue()));
            } else {
                Slider value = question.getSlider();
                validateNumericalResponse(value.getMax(), value.getMin(), questionDto.getValue());
                value.setValue(questionDto.getValue());
                questionLevelScore.set(getScore(value.getRange(), questionDto.getValue()));
            }
            question.setQuestionLevelScore(questionLevelScore.get());
        } else {
            if (!question.isNotApplicable()) {
                throw new AssessmentException("Mandatory question : " + question.getNumber());
            }
            question.setNotApplicableUserResponse(true);
            if (StringUtils.isBlank(questionDto.getCommentText())) {
                throw new AssessmentException("Comment is mandatory when Not Applicable option is selected");
            }
            question.setCommentText(questionDto.getCommentText());
            rollbackPreviousData(question);
        }
        return question;
    }

    private void rollbackPreviousData(Question question) {
        if (question.getType().equals(QuestionType.CHECK_BOX)) {
            for (Option option : question.getCheckBoxOptions().getOptions()) {
                option.setSelected(false);
            }
        } else if (question.getType().equals(QuestionType.RADIO_BUTTON)) {
            for (Option option : question.getRadioOptions().getOptions()) {
                option.setSelected(false);
            }
        } else if (question.getType().equals(QuestionType.NUMERICAL)) {
            question.getNumerical().setValue(null);
        } else {
            question.getSlider().setValue(null);
        }
        question.setQuestionLevelScore(null);
    }

    private void validateNumericalResponse(Integer max, Integer min, Double value) {
        if (value == null || value > max || value < min) {
            throw new AssessmentException("The response value should be between min and max");
        }
    }


    public AssessmentResponseDto fetchAssessment(Long assessmentId, Long projectId, String action, UUID userId) {
//        Optional<Assessment> assessmentOptional = assessmentRepository.findByIdAndProjectId(assessmentId, projectId);
//        AssessmentResponseDto assessmentResponseDto = new AssessmentResponseDto();
//        assessmentOptional.ifPresentOrElse(assessment -> {
//            if (action.equals(TAKE_ASSESSMENT) && (assessment.getStatus().equals(AssessmentStatus.PENDING) ||
//                    assessment.getStatus().equals(AssessmentStatus.OVERDUE))) {
//                AssessmentStatus status = assessment.getStatus();
//                AssessmentStatus currentStatus = status.equals(AssessmentStatus.OVERDUE) ?
//                        AssessmentStatus.OVERDUE_IN_PROGRESS : AssessmentStatus.IN_PROGRESS;
//                long epochMilli = LocalDate.now().atStartOfDay(ZoneId.systemDefault())
//                        .toInstant().toEpochMilli();
//                AssessmentHistory assessmentHistory = AssessmentHistory.builder().assessmentId(assessmentId)
//                        .projectId(projectId)
//                        .accountId(assessment.getAccountId())
//                        .assessmentStartDate(assessment.getInitiatedOn())
//                        .previousStatus(status)
//                        .currentStatus(currentStatus)
//                        .createDate(epochMilli)
//                        .createdBy(utilMethods.getDisplayName(userId))
//                        .build();
//                assessmentHistoryRepository.save(assessmentHistory);
//                assessment.setStatus(currentStatus);
//                assessmentRepository.save(assessment);
//            }
//            if (TAKE_ASSESSMENT.equals(action) ){
//                Optional<AssessmentDraft> assessmentDraft =  assessmentDraftRepository.findByAssessmentId(assessmentId);
//
//                assessmentDraft.ifPresentOrElse(assessmentDraft1 -> {
//                    BeanUtils.copyProperties(assessmentDraft1, assessmentResponseDto);
//                            assessmentResponseDto.setReassigned(assessmentDraft1.getIsReassigned() != null ? assessmentDraft1.getIsReassigned() : false);
//                    }
//                        ,
//                        () -> {BeanUtils.copyProperties(assessment, assessmentResponseDto);
//                assessmentResponseDto.setReassigned(assessment.getIsReassigned()!= null ? assessment.getIsReassigned() : false);}
//                );
//            }else {
//                BeanUtils.copyProperties(assessment, assessmentResponseDto);
//                assessmentResponseDto.setReassigned(assessment.getIsReassigned()!= null ? assessment.getIsReassigned() : false);
//
//            }
//            assessmentResponseDto.setAssessmentId(assessmentId);
//            accountRepository.findById(assessment.getAccountId()).ifPresent(account -> assessmentResponseDto.setAccountName(account.getAccountName()));
//            projectRepository.findById(projectId).ifPresent(project -> {
//                assessmentResponseDto.setProjectName(project.getProjectName());
//                DedRolesmy deliveryPartner = project.getDedRoles().stream().filter(dedRoles -> DP.equalsIgnoreCase(dedRoles.getRole())).findAny().orElse(new DedRolesmy());
//                assessmentResponseDto.setDeliveryPartner(deliveryPartner.getName());
//            });
//
//        }, () -> {
//            log.error("Combination of assessment Id:{} and project id:{} not found", assessmentId, projectId);
//            throw new CustomException("Assessment not found", HttpStatus.NOT_FOUND);
//        });
//        return assessmentResponseDto;
    	
    	return new AssessmentResponseDto();
    }

    public boolean validateAssessmentStatus(AssessmentStatus assessmentStatus) {
        return assessmentStatus.equals(AssessmentStatus.IN_PROGRESS) ||
                assessmentStatus.equals(AssessmentStatus.PENDING) || assessmentStatus.equals(AssessmentStatus.OVERDUE)
                || assessmentStatus.equals(AssessmentStatus.OVERDUE_IN_PROGRESS);

    }

    public AssessmentSharePointResponse uploadAssessmentAttachment(AssessmentSharePointRequest request, Long assessmentId, MultipartFile file) {

//        isValidInput(request);
//        Optional<Project> projectOptional = projectRepository.findById(request.getProjectId());
//        AssessmentSharePointDetails sharePointDetails = new AssessmentSharePointDetails();
//        if (projectOptional.isPresent()) {
//            Project project = projectOptional.get();
//            if (StringUtils.isBlank(project.getProjectDriverId())) {
//                DriveItem driveItem = sharepointUtils.createFolder(String.valueOf(request.getProjectId()), driverItemId);
//                project.setProjectDriverId(driveItem.getId());
//                driveItem = getAssessmentDriveItem(driveItem, project);
//                return validateAndUploadAssessmentAttachment(request, assessmentId, driveItem, sharePointDetails, file);
//            } else {
//                DriveItem driveItem = new DriveItem();
//                if (StringUtils.isBlank(project.getAssessmentDriverId())) {
//                    driveItem = getAssessmentDriveItem(driveItem, project);
//                    return validateAndUploadAssessmentAttachment(request, assessmentId, driveItem, sharePointDetails, file);
//                } else {
//                    driveItem.setId(project.getAssessmentDriverId());
//                    return validateAndUploadAssessmentAttachment(request, assessmentId, driveItem, sharePointDetails, file);
//                }
//            }
//        } else {
//            log.info("Project not found for " + request.getProjectId());
//            throw new ProjectNotFoundException("Project not found");
//        }

    	return new AssessmentSharePointResponse();
    }

    private void isValidInput(AssessmentSharePointRequest request) {

        Errors errors = new BeanPropertyBindingResult(request, AssessmentSharePointRequest.class.getName());
        ValidationUtils.invokeValidator(validator, request, errors);
        List<ErrorMessage> errorMessages = new ArrayList<>();
        if (errors.hasFieldErrors()) {
            errors.getFieldErrors().forEach(fieldError -> errorMessages.add(new ErrorMessage(fieldError.getField(), fieldError.getDefaultMessage())));

            throw new ValidationException(FailedMessage.VALIDATION_EXCEPTION.getMessage(), errorMessages);

        }
    }

    private AssessmentSharePointResponse validateAndUploadAssessmentAttachment(AssessmentSharePointRequest request, Long assessmentId, DriveItem driveItem, AssessmentSharePointDetails sharePointDetails, MultipartFile file) {
        driveItem = getAssessmentDriverItem(assessmentId, driveItem);
        sharePointDetails = validateSharePointDetails(request, assessmentId, sharePointDetails);
        if (StringUtils.isBlank(sharePointDetails.getFolderDocumentId())) {
            saveParticularAssessmentFolderDetails(request, assessmentId, driveItem, sharePointDetails, file);
        }
        String currentAssessmentFolder = driveItem.getId();
        String oldDocumentId = sharePointDetails.getDocumentId();
        driveItem = uploadAttachment(file, driveItem.getId());
        return saveAssessmentSharePointDetails(request, assessmentId, sharePointDetails, driveItem, currentAssessmentFolder, oldDocumentId, file);
    }

    private void saveParticularAssessmentFolderDetails(AssessmentSharePointRequest request, Long assessmentId,
                                                       DriveItem driveItem, AssessmentSharePointDetails sharePointDetails, MultipartFile file) {
//Mongo commeted code
    	//        sharePointDetails.setAssessmentId(assessmentId);
//        sharePointDetails.setQuestionNumber(request.getQuestionNumber());
//        sharePointDetails.setAssessmentCategoryType(request.getAssessmentCategoryType());
//        sharePointDetails.setFolderDocumentId(driveItem.getId());
//        sharePointDetails.setFileName(file.getOriginalFilename());
//        sharePointDetails.setType(file.getContentType());
       // assessmentSharePointRepository.save(sharePointDetails);
    }

    private AssessmentSharePointDetails validateSharePointDetails(AssessmentSharePointRequest request, Long assessmentId, AssessmentSharePointDetails sharePointDetails) {
//        Optional<AssessmentSharePointDetails> sharePointDetailsOptional = assessmentSharePointRepository.
//                findByAssessmentIdAndQuestionNumberAndAssessmentCategoryType(assessmentId, request.getQuestionNumber()
//                        , request.getAssessmentCategoryType());
//        return sharePointDetailsOptional.orElse(sharePointDetails);
    	return new AssessmentSharePointDetails();
    }

    private AssessmentSharePointResponse saveAssessmentSharePointDetails(AssessmentSharePointRequest request, Long assessmentId,
                                                                         AssessmentSharePointDetails sharePointDetails, DriveItem driveItem,
                                                                         String currentAssessmentFolder, String oldDocumentId, MultipartFile file) {
//        sharePointDetails.setFileName(file.getOriginalFilename());
//        sharePointDetails.setType(file.getContentType());
//        sharePointDetails.setDocumentId(driveItem.getId());
//        assessmentSharePointRepository.save(sharePointDetails);
//        if (oldDocumentId != null) {
//            sharepointUtils.deleteFile(oldDocumentId);
//        }
//        AssessmentSharePointResponse sharePointResponse = new AssessmentSharePointResponse();
//        BeanUtils.copyProperties(sharePointDetails, sharePointResponse);
//        sharePointResponse.setItemDocumentId(driveItem.getId());
//        return sharePointResponse;
    	return new AssessmentSharePointResponse();
    }

    private DriveItem uploadAttachment(MultipartFile file, String driveItemId) {
        try {
            int index = Objects.requireNonNull(file.getOriginalFilename()).lastIndexOf('.');
            String attachmentName = file.getOriginalFilename().substring(index);
            checkAllowedFileFormat(attachmentName);
            String fileName = file.getOriginalFilename().substring(0, index) + "_" + System.currentTimeMillis() + attachmentName;

            return sharepointUtils.uploadFile(file.getContentType(), fileName,
                    file.getBytes(), driveItemId).getBody();
        } catch (IOException e) {
            log.error(e.getMessage());
            throw new CustomException("Upload is failed , try again", HttpStatus.BAD_REQUEST);
        }
    }

    private DriveItem getAssessmentDriverItem(Long assessmentId, DriveItem driveItem) {
//        Optional<AssessmentSharePointDetails> sharePointDetailsOptional = assessmentSharePointRepository.
//                findFirstByAssessmentIdAndFolderDocumentIdIsNotNull(assessmentId);
//        if (sharePointDetailsOptional.isPresent()) {
//            driveItem.setId(sharePointDetailsOptional.get().getFolderDocumentId());
//            return driveItem;
//        }
//        return sharepointUtils.createFolder(String.valueOf(assessmentId), driveItem.getId());
    	return  driveItem;
    }

    private DriveItem getAssessmentDriveItem(DriveItem driveItem, Project project) {
//  commented mongo code
    	//        driveItem.setId(project.getProjectDriverId());
//        driveItem = sharepointUtils.createFolder("Assessments", driveItem.getId());
//        project.setAssessmentDriverId(driveItem.getId());
//        projectRepository.save(project);
//        return driveItem;
    	return new DriveItem();
    }

    public AttachmentDownloadDto getAttachmentDetails(Long assessmentId, int questionNumber, AssessmentCategoryType categoryType) {
        AssessmentSharePointDetails assessmentSharePointDetails = getAssessmentSharePointDetails(assessmentId, questionNumber, categoryType);
        AttachmentDownloadDto attachmentDownloadDto = new AttachmentDownloadDto();
        attachmentDownloadDto.setName(assessmentSharePointDetails.getFileName());
        attachmentDownloadDto.setType(assessmentSharePointDetails.getType());
        attachmentDownloadDto.setDownloadedInputStream(sharepointUtils.downloadFile(assessmentSharePointDetails.getDocumentId()));
        return attachmentDownloadDto;

    }

    public void deleteAttachment(Long assessmentId, int questionNumber, AssessmentCategoryType categoryType, UUID userId) {
        Optional<Assessment> assessmentOptional = assessmentRepository.findByIdAndUserId(assessmentId, userId);
        if (assessmentOptional.isEmpty()) {
            log.error("Assessment details is not found for assessment id and requested user");
            throw new CustomException("Assessment details is not found for assessment id and requested user", HttpStatus.NOT_FOUND);
        }
        AssessmentSharePointDetails assessmentSharePointDetails = getAssessmentSharePointDetails(assessmentId, questionNumber, categoryType);
        sharepointUtils.deleteFile(assessmentSharePointDetails.getDocumentId());
        updateAttachmentDetails(questionNumber, categoryType, assessmentOptional);
        assessmentSharePointDetails.setDocumentId(null);
        assessmentSharePointDetails.setFileName(null);
        assessmentSharePointDetails.setType(null);
        //Mongo code commented
      //  assessmentSharePointRepository.save(assessmentSharePointDetails);
    }

    private void updateAttachmentDetails(int questionNumber, AssessmentCategoryType categoryType, Optional<Assessment> assessmentOptional) {
        Assessment assessment = assessmentOptional.get();
        List<MyTemplateCategory> templateCategoryList = assessment.getTemplateCategories();
        for (MyTemplateCategory templateCategory : templateCategoryList) {
            if (templateCategory.getName().equals(categoryType)) {
                List<Question> questionList = templateCategory.getQuestions();
                for (Question question : questionList) {
                    if (question.getNumber() == questionNumber) {
                        question.setFileName(null);
                        question.setDocumentId(null);
                    }
                }
            }
        }
        assessmentRepository.save(assessment);
    }

    private AssessmentSharePointDetails getAssessmentSharePointDetails(Long assessmentId, int questionNumber, AssessmentCategoryType categoryType) {
//        Optional<AssessmentSharePointDetails> sharePointDetailsOptional = assessmentSharePointRepository.findByAssessmentIdAndQuestionNumberAndAssessmentCategoryType(assessmentId, questionNumber, categoryType);
//        if (sharePointDetailsOptional.isEmpty()) {
//            log.error("Attachment details is not found");
//            throw new CustomException("Attachment details is not found", HttpStatus.NOT_FOUND);
//        }
 //       return sharePointDetailsOptional.get();
    	return new AssessmentSharePointDetails();
    }

    public void checkAllowedFileFormat(String fileExtension) {
        if (!allowedAssessmentFileFormat.contains(fileExtension.toLowerCase()))
            throw new CustomException("Invalid file format.", HttpStatus.BAD_REQUEST);
    }

    public AssessmentTrendsDetailsDto fetchTrendsDetails(UUID oid, AssessmentFilterDto assessmentFilterDto, AssessmentRole action) {
        log.info("AssessmentService:fetchTrendsDetails >> start");
        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = new AssessmentTrendsDetailsDto();
        getAverageTrend(assessmentTrendsDetailsDto, assessmentFilterDto, oid, action);
        getScoreTrend(assessmentTrendsDetailsDto, assessmentFilterDto, oid, action);
        log.info("AssessmentService:fetchTrendsDetails >> End");
        return assessmentTrendsDetailsDto;
    }


    private void getScoreTrend(AssessmentTrendsDetailsDto assessmentTrendsDetailsDto, AssessmentFilterDto assessmentFilterDto, UUID oid, AssessmentRole action) {
//           Mongo Template commented code
//        log.info("AssessmentService.getScoreTrend >> Start");
//        Criteria baseCriteria = new Criteria();
//        ChartDto chartDto = new ChartDto();
//        List<String> xAxisLabel = new ArrayList<>();
//
//        List<ChartXAxisDataDto> xAxisValues = new ArrayList<>();
//
//        if (Objects.nonNull(assessmentFilterDto.getAccountId()) && assessmentFilterDto.getAccountId() > 0) {
//            baseCriteria.and(ACCOUNT_ID).is(assessmentFilterDto.getAccountId());
//        }
//        if (Objects.nonNull(assessmentFilterDto.getProjectId()) && assessmentFilterDto.getProjectId() > 0) {
//            baseCriteria.and(PROJECT_ID).is(assessmentFilterDto.getProjectId());
//        }
//
//        if (AssessmentRole.ASSIGNED.equals(action)) {
//            baseCriteria.and(USER_ID).is(oid);
//        }
//        if (AssessmentRole.REVIEWER.equals(action)) {
//            baseCriteria.and(REVIEWER_ID).is(oid);
//        }
//        if (!mongoTemplate.exists(new Query(baseCriteria), Assessment.class)) {
//            log.info("AssessmentService.getScoreTrend >> No Assessment");
//            return;
//        }
//        Query baseQuery;
//        List<Double> score = new ArrayList<>();
//        List<DateRangeDto> dateRangeDtos;
//        List<Long> totalAssByMonth = new ArrayList<>();
//        int index = 0;
//        AtomicReference<Double> totalScore = new AtomicReference<>(0.0);
//
//        if (StringUtils.isNotBlank(assessmentFilterDto.getDateRangeStr())) {
//            dateRangeDtos = utilMethods.getChatDateRange(assessmentFilterDto.getDateRangeStr());
//
//        } else {
//            dateRangeDtos = utilMethods.getChatDateRange(ALL);
//        }
//        long totalReviewdAssessment = 0;
//        for (DateRangeDto dateRangeDto : dateRangeDtos) {
//
//            if (LAST_3_MONTHS.equalsIgnoreCase(assessmentFilterDto.getDateRangeStr())) {
//                xAxisLabel.add(WEEK + " " + ++index);
//            } else {
//                LocalDate date = Instant.ofEpochMilli(dateRangeDto.getStartDate())
//                        .atZone(ZoneId.systemDefault())
//                        .toLocalDate();
//                xAxisLabel.add(date.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()) + " " + date.getYear());
//            }
//            Criteria dateCriteria = new Criteria().and(STATUS).is(AssessmentStatus.REVIEWED.name()).and(REVIEWED_ON).gte(dateRangeDto.getStartDate()).lte(dateRangeDto.getEndDate());
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            List<Assessment> assessments = mongoTemplate.find(baseQuery, Assessment.class);
//            totalReviewdAssessment = totalReviewdAssessment + assessments.size();
//
//            double avg = assessments.stream().mapToDouble(assessment -> {
//
//                        Double val = Objects.nonNull(assessment.getScore()) ? assessment.getScore() : 0.0;
//                        totalScore.set(totalScore.get() + val);
//                        return val;
//                    }
//            ).average().orElse(0.0);
//            score.add(Double.parseDouble(formatter.format(avg)));
//            totalAssByMonth.add((long) assessments.size());
//        }
//        Double avgScore = totalScore.get() / totalReviewdAssessment;
//        xAxisValues.add(ChartXAxisDataDto.builder().name(SCORE).data(score).total(totalAssByMonth).build());
//        chartDto.setXAxisLabel(xAxisLabel);
//        chartDto.setXAxisValues(xAxisValues);
//        chartDto.setAverage(formatter.format(avgScore));
//        assessmentTrendsDetailsDto.setScoreTrend(chartDto);
//        log.info("AssessmentService.getScoreTrend >> End");
    }

    private void getAverageTrend(AssessmentTrendsDetailsDto assessmentTrendsDetailsDto, AssessmentFilterDto assessmentFilterDto, UUID oid, AssessmentRole action) {
//        Mongo Template commented code
//        log.info("AssessmentService.getAverageTrend >> Start");
//        Criteria baseCriteria = new Criteria();
//        ChartDto chartDto = new ChartDto();
//        List<String> xAxisLabel = new ArrayList<>();
//        List<Assessment> assessments = null;
//        List<ChartXAxisDataDto> xAxisValues = new ArrayList<>();
//
//        if (Objects.nonNull(assessmentFilterDto.getAccountId()) && assessmentFilterDto.getAccountId() > 0) {
//            baseCriteria.and(ACCOUNT_ID).is(assessmentFilterDto.getAccountId());
//        }
//        if (Objects.nonNull(assessmentFilterDto.getProjectId()) && assessmentFilterDto.getProjectId() > 0) {
//            baseCriteria.and(PROJECT_ID).is(assessmentFilterDto.getProjectId());
//        }
//
//        if (AssessmentRole.ASSIGNED.equals(action)) {
//            assessments = assessmentRepository.findByUserId(oid);
//      //      List<Long> assessmentIds = assessments.stream().filter(Objects::nonNull).map(IdentifiedEntity::getId).toList();
//         //   baseCriteria.and(ASSESSMENT_ID).in(assessmentIds);
//        }
//        if (AssessmentRole.REVIEWER.equals(action)) {
//            assessments = assessmentRepository.findByReviewerId(oid);
//            //commeted duto Mysql 
//         //   List<Long> assessmentIds = assessments.stream().filter(Objects::nonNull).map(IdentifiedEntity::getId).toList();
//         //   baseCriteria.and(ASSESSMENT_ID).in(assessmentIds);
//        }
//
//        if (!mongoTemplate.exists(new Query(baseCriteria), AssessmentHistory.class)) {
//            log.info("AssessmentService.getAverageTrend >> No Assessment");
//            return;
//        }
//        Query baseQuery;
//
//        List<AssessmentHistory> assessmentHistories;
//        Set<Long> countedSubIds = new HashSet<>();
//        Set<Long> countedReviewedIds = new HashSet<>();
//        Set<Long> countedOverDueIds = new HashSet<>();
//        List<Double> submitted = new ArrayList<>();
//        List<Double> overdue = new ArrayList<>();
//        List<Double> reviewed = new ArrayList<>();
//        List<DateRangeDto> dateRangeDtos;
//        if (StringUtils.isNotBlank(assessmentFilterDto.getDateRangeStr())) {
//            dateRangeDtos = utilMethods.getChatDateRange(assessmentFilterDto.getDateRangeStr());
//        } else {
//            dateRangeDtos = utilMethods.getChatDateRange(ALL);
//        }
//        Collections.reverse(dateRangeDtos);
//        int index = dateRangeDtos.size();
//        for (DateRangeDto dateRangeDto : dateRangeDtos) {
//            Set<Long> ids;
//            if (LAST_3_MONTHS.equalsIgnoreCase(assessmentFilterDto.getDateRangeStr())) {
//                xAxisLabel.add(WEEK + " " + index--);
//            } else {
//                LocalDate date = Instant.ofEpochMilli(dateRangeDto.getStartDate())
//                        .atZone(ZoneId.systemDefault())
//                        .toLocalDate();
//                xAxisLabel.add(date.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()) + " " + date.getYear());
//            }
//            Criteria dateCriteria = new Criteria().and(CREATE_DATE).gte(dateRangeDto.getStartDate()).lte(dateRangeDto.getEndDate());
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            assessmentHistories = mongoTemplate.find(baseQuery.addCriteria(Criteria.where(CURRENT_STATUS).is(AssessmentStatus.SUBMITTED.name())), AssessmentHistory.class);
//            ids = assessmentHistories.stream().map(AssessmentHistory::getAssessmentId).filter(assessmentId -> !countedSubIds.contains(assessmentId)).collect(Collectors.toSet());
//            submitted.add(UtilMethods.integerToDouble(ids.size()));
//            countedSubIds.addAll(ids);
//
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            assessmentHistories = mongoTemplate.find(baseQuery.addCriteria(Criteria.where(CURRENT_STATUS).is(AssessmentStatus.OVERDUE.name())), AssessmentHistory.class);
//            ids = assessmentHistories.stream().map(AssessmentHistory::getAssessmentId).filter(assessmentId -> !countedOverDueIds.contains(assessmentId)).collect(Collectors.toSet());
//            overdue.add(UtilMethods.integerToDouble(ids.size()));
//            countedOverDueIds.addAll(ids);
//
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            assessmentHistories = mongoTemplate.find(baseQuery.addCriteria(Criteria.where(CURRENT_STATUS).is(AssessmentStatus.REVIEWED.name())), AssessmentHistory.class);
//            ids = assessmentHistories.stream().map(AssessmentHistory::getAssessmentId).filter(assessmentId -> !countedReviewedIds.contains(assessmentId)).collect(Collectors.toSet());
//            reviewed.add(UtilMethods.integerToDouble(ids.size()));
//            countedReviewedIds.addAll(ids);
//        }
//        Collections.reverse(submitted);
//        Collections.reverse(reviewed);
//        Collections.reverse(overdue);
//        Collections.reverse(xAxisLabel);
//        xAxisValues.add(ChartXAxisDataDto.builder().name(SUBMITTED).data(submitted).build());
//        xAxisValues.add(ChartXAxisDataDto.builder().name(REVIEWED).data(reviewed).build());
//        xAxisValues.add(ChartXAxisDataDto.builder().name(OVERDUE).data(overdue).build());
//        chartDto.setXAxisLabel(xAxisLabel);
//        chartDto.setXAxisValues(xAxisValues);
//        assessmentTrendsDetailsDto.setAverageTrend(chartDto);
//        log.info("AssessmentService.getAverageTrend >> End");
    }

    public List<AssessmentResponseDto> fetchAssessments(UUID userId, AssessmentRole assessmentRole, AssessmentFilterDto filterDto) {
//   
    	log.info("assessmentService::fetchAllFilterAssessment:: call started");
//        Criteria baseCriteria = new Criteria();
//        List<Criteria> criteriaList = new ArrayList<>();
//
//        if (AssessmentRole.ASSIGNED.equals(assessmentRole)) {
//            baseCriteria.and(USER_ID).is(userId);
//        }
//        if (AssessmentRole.REVIEWER.equals(assessmentRole)) {
//            baseCriteria.and(REVIEWER_ID).is(userId).and(STATUS).in(List.of(AssessmentStatus.REVIEWED, AssessmentStatus.SUBMITTED));
//        }
//        if (filterDto.getAccountId() != null) {
//            criteriaList.add(Criteria.where(ACCOUNT_ID).is(filterDto.getAccountId()));
//        }
//        if (filterDto.getProjectId() != null) {
//            criteriaList.add(Criteria.where(PROJECT_ID).is(filterDto.getProjectId()));
//        }
//        if (filterDto.getDateRange() != null) {
//            if (filterDto.getDateRange().getStartDate() != null && filterDto.getDateRange().getEndDate() != null) {
//                criteriaList.add(Criteria.where(INITIATED_ON).gte(filterDto.getDateRange().getStartDate()).lte(filterDto.getDateRange().getEndDate()));
//            } else if (filterDto.getDateRange().getStartDate() != null) {
//                criteriaList.add(Criteria.where(INITIATED_ON).gte(filterDto.getDateRange().getStartDate()));
//            } else if (filterDto.getDateRange().getEndDate() != null) {
//                criteriaList.add(Criteria.where(INITIATED_ON).lte(filterDto.getDateRange().getEndDate()));
//            }
//        }
//        if (filterDto.getScoreStart() != null && filterDto.getScoreEnd() != null) {
//            criteriaList.add(Criteria.where(SCORE).gte(filterDto.getScoreStart()).lte(filterDto.getScoreEnd()));
//        }
//        if (filterDto.getStatus() != null) {
//            criteriaList.add(Criteria.where(STATUS).is(filterDto.getStatus()));
//        }
//        if (!criteriaList.isEmpty()) {
//            baseCriteria.orOperator(criteriaList);
//        }
//
//
//        Query query = new Query(baseCriteria);
//        if (StringUtils.isNotBlank(filterDto.getSortBy())) {
//            utilMethods.isValidField(Assessment.class, filterDto.getSortBy());
//            query.with(Sort.by(Sort.Direction.DESC, filterDto.getSortBy()));
//        } else {
//            query.with(Sort.by(Sort.Direction.DESC, INITIATED_ON));
//        }
//        List<AssessmentResponseDto> assessmentResponseDtoList = new ArrayList<>();
//        List<Assessment> assessmentList = mongoTemplate.find(query, Assessment.class);
//
//        assessmentList.forEach(assessment -> {
//            AssessmentResponseDto assessmentResponseDto = new AssessmentResponseDto();
//            BeanUtils.copyProperties(assessment, assessmentResponseDto);
//            projectRepository.findById(assessment.getProjectId()).ifPresent(project ->
//                    assessmentResponseDto.setProjectName(project.getProjectName())
//            );
//            accountRepository.findById(assessment.getAccountId()).ifPresent(account -> assessmentResponseDto.setAccountName(account.getAccountName()));
//            assessmentResponseDto.setTemplateCategory(null);
//            assessmentResponseDto.setAssessmentId(assessment.getId());
//            assessmentResponseDtoList.add(assessmentResponseDto);
//        });
//        log.info("assessmentService::fetchFilterAssessment:: call ended");
//        if (CollectionUtils.isEmpty(assessmentResponseDtoList)) {
//            return Collections.emptyList();
//        } else
//            return assessmentResponseDtoList;
    	return new ArrayList<AssessmentResponseDto>();
    }

    private Double getScore(List<Range> ranges, Double value) {
        for (Range range : ranges) {
            if (value >= range.getStart() && value <= range.getEnd()) {
                return range.getScore();
            }
        }
        throw new AssessmentException("The requested value is not within the defined range. Value - " + value);
    }

    public void reviewAssessment(UUID userId, ReviewAssessmentRequestDto requestDto, Long assessmentId) {
//        Optional<Assessment> assessmentOptional = assessmentRepository.findByIdAndReviewerId(assessmentId, userId);
//        if (assessmentOptional.isPresent()) {
//            Assessment assessment = assessmentOptional.get();
//            if (!assessment.getStatus().equals(AssessmentStatus.SUBMITTED)) {
//                throw new AssessmentException("Assessment is not ready for review");
//            }
//            Optional<Project> project = projectRepository.findById(assessmentOptional.get().getProjectId());
//            if (project.isEmpty()) {
//                throw new ProjectNotFoundException("Project not found");
//            }
//            List<MyTemplateCategory> templateCategoryList = assessment.getTemplateCategories();
//            AssessmentHistory history;
//            for (MyTemplateCategory templateCategory : templateCategoryList) {
//                if (templateCategory.getName().equals(requestDto.getCategoryType())) {
//                    if (templateCategory.getQuestions().size() != requestDto.getReviewComments().size()) {
//                        throw new AssessmentException("Request question size is not matching with assessment question");
//                    }
//                    templateCategory.getQuestions().forEach(question -> {
//                        String comments = requestDto.getReviewComments().stream().filter(c -> question.getNumber() == c.getQuestionNumber()).findAny().orElse(new ReviewComments()).getReviewComment();
//                        question.setReviewerComment(comments);
//                    });
//                }
//            }
//            assessment.setTemplateCategories(templateCategoryList);
//            assessment.setOverallComment(requestDto.getOverallComment());
//            if (requestDto.isSubmitted()) {
//                if (requestDto.isReassigned()) {
//                    throw new AssessmentException("Submitted and reassigned both status should not be true");
//                }
//                assessment.setReviewedOn(getCurrentDateValue());
//                assessment.setStatus(AssessmentStatus.REVIEWED);
//                history = AssessmentHistory.builder().assessmentId(assessmentId)
//                        .projectId(assessment.getProjectId())
//                        .accountId(assessment.getAccountId())
//                        .assessmentStartDate(assessment.getInitiatedOn())
//                        .previousStatus(AssessmentStatus.SUBMITTED)
//                        .currentStatus(AssessmentStatus.REVIEWED)
//                        .createDate(getCurrentDateValue())
//                        .createdBy(utilMethods.getDisplayName(userId))
//                        .build();
//                assessment.setScore(calculateScore(assessment));
//                assessmentRepository.save(assessment);
//
//                try {
//                    assessmentCreationAndNotification.sendEmailDetails(assessment, project.get(), REVIEWED_ASSESSMENT_SUBJECT, ASSESSMENT_REVIEWED_TEMPLATE, REVIEWED_ASSESSMENT, null,"ASSESSMENT_REVIEWED_EMAIL");
//                } catch (Exception e) {
//                    log.error("An error occurred while sending email for Assessment ID: {}", assessment.getId(), e);
//                }
//                assessmentHistoryRepository.save(history);
//            } else if (requestDto.isReassigned()) {
//                if (StringUtils.isBlank(requestDto.getReasonForReassign())) {
//                    throw new ValidationException(FailedMessage.VALIDATION_EXCEPTION.getMessage(), Collections.singletonList(new ErrorMessage("Reason", "Re-assign reason is mandatory")));
//
//                }
//                List<AssessmentHistory> assessmentHistoryList = assessmentHistoryRepository.findByAssessmentId(assessmentId);
//                assessment.setReasonForReassign(requestDto.getReasonForReassign());
//                assessment.setIsReassigned(requestDto.isReassigned());
//                if (assessmentHistoryList.isEmpty()) {
//                    assessment.setStatus(AssessmentStatus.IN_PROGRESS);
//                } else {
//                    boolean isOverDueAssessment = false;
//                    for (AssessmentHistory assessmentHistory : assessmentHistoryList) {
//                        if (assessmentHistory.getCurrentStatus().equals(AssessmentStatus.OVERDUE) ||
//                                assessmentHistory.getCurrentStatus().equals(AssessmentStatus.OVERDUE_IN_PROGRESS)) {
//                            isOverDueAssessment = true;
//                            break;
//                        }
//                    }
//                    if (isOverDueAssessment) {
//                        assessment.setStatus(AssessmentStatus.OVERDUE_IN_PROGRESS);
//                    } else {
//                        assessment.setStatus(AssessmentStatus.IN_PROGRESS);
//                    }
//                }
//                history = AssessmentHistory.builder().assessmentId(assessmentId)
//                        .projectId(assessment.getProjectId())
//                        .accountId(assessment.getAccountId())
//                        .assessmentStartDate(assessment.getInitiatedOn())
//                        .previousStatus(AssessmentStatus.SUBMITTED)
//                        .currentStatus(assessment.getStatus())
//                        .createDate(getCurrentDateValue())
//                        .createdBy(utilMethods.getDisplayName(userId))
//                        .build();
//                assessmentRepository.save(assessment);
//                try {
//                    assessmentCreationAndNotification.sendEmailDetails(assessment, project.get(), RETURNED_ASSESSMENT_SUBJECT, ASSESSMENT_REVIEWED_TEMPLATE, RETURNED_ASSESSMENT, null,"ASSESSMENT_RETURNED_EMAIL");
//                } catch (Exception e) {
//                    log.error("An error occurred while sending email for Assessment ID: {}", assessment.getId(), e);
//                }
//                assessmentHistoryRepository.save(history);
//            } else {
//                assessmentRepository.save(assessment);
//            }
//
//            //update the draft up to date.
//            Optional<AssessmentDraft> assessmentDraft = assessmentDraftRepository.findByAssessmentId(assessmentId);
//            assessmentDraft.ifPresentOrElse(draft -> {
//                Long draftId = draft.getId();
//                BeanUtils.copyProperties(assessment, draft);
//                draft.setAssessmentId(assessmentId);
//                draft.setId(draftId);
//                assessmentDraftRepository.save(draft);
//            },()->{
//                AssessmentDraft draft = new AssessmentDraft();
//                BeanUtils.copyProperties(assessment, draft);
//                draft.setAssessmentId(assessmentId);
//                draft.setId(null);
//                assessmentDraftRepository.save(draft);
//            });
//
//        } else {
//            log.error("Assessment not found");
//            throw new AssessmentException("The Assessment is not found");
//        }

    }

    public long getCurrentDateValue() {
        return ZonedDateTime.now(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli();
    }

    private double calculateScore(Assessment assessment) {
        double overallScore = 0;
        int sumOfWeightage = 0;
        for (MyTemplateCategory templateCategory : assessment.getTemplateCategories()) {
            for (Question question : templateCategory.getQuestions()) {
                if (!question.isNotApplicableUserResponse()) {

                    sumOfWeightage = sumOfWeightage + (question.getWeightage() == null ? 1 : question.getWeightage());

                    overallScore = overallScore + ((question.getQuestionLevelScore() == null ? 0 : question.getQuestionLevelScore()) *
                            (question.getWeightage() == null ? 1 : question.getWeightage()));
                }
            }
        }
        return overallScore == 0 && sumOfWeightage == 0 ? 0 : Double.parseDouble(formatter.format(overallScore / sumOfWeightage));
    }

//    public Map<String, String> createAssessment() {
////        log.info("AssessmentService::createAssessment() call started");
////        Map<String, List<JobNotificationDetails>> emailDetails = new HashMap<>();
////        int newAssessmentSuccessCount = 0;
////        int newAssessmentFailureCount = 0;
////
////        List<JobNotificationDetails> successFulProjects = new ArrayList<>();
////        List<Project> projectsForNewAssCreation = projectRepository.findByAssessmentStartDateAndStatus(LocalDate.now().atStartOfDay().atZone(ZoneOffset.UTC).toInstant(), ProjectStatus.Active);
////        log.info("count of projects picked for new assessments creation :" + projectsForNewAssCreation.size());
////        for (Project project : projectsForNewAssCreation) {
////            JobNotificationDetails success = new JobNotificationDetails();
////            try {
////                assessmentCreationAndNotification.createAssessmentForProject(project);
////                String accountName = accountRepository.findById(project.getAccountId()).orElse(new Account()).getAccountName();
////                success.setAccountName(accountName);
////                success.setProjectName(project.getProjectName());
////                successFulProjects.add(success);
////                newAssessmentSuccessCount++;
////            } catch (Exception e) {
////                log.error("Error creating new assessment for project {}: {}", project.getId(), e.getMessage(), e);
////                newAssessmentFailureCount++;
////                recordFailedProject(project.getId(), project.getStatus(), e.getMessage(), null);
////            }
////
////        }
////        int nextAssessmentSuccessCount = 0;
////        int nextAssessmentFailureCount = 0;
////        List<ProjectAssessmentDetails> projectsForNextAssessmentCreation = projectAssessmentDetailsRepository.findByNextAssessmentCreationDate(LocalDate.now().atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
////        int count = 0;
////        for (ProjectAssessmentDetails projectAssessmentDetails : projectsForNextAssessmentCreation) {
////            Optional<Project> optionalProject = projectRepository.findById(projectAssessmentDetails.getProjectId());
////            if (optionalProject.isPresent() && optionalProject.get().getStatus().equals(ProjectStatus.Active)) {
////                count++;
////                JobNotificationDetails success = new JobNotificationDetails();
////                try {
////                    assessmentCreationAndNotification.createNextAssessmentForProject(projectAssessmentDetails);
////                    String accountName = accountRepository.findById(optionalProject.get().getAccountId()).orElse(new Account()).getAccountName();
////                    success.setAccountName(accountName);
////                    success.setProjectName(optionalProject.get().getProjectName());
////                    successFulProjects.add(success);
////                    nextAssessmentSuccessCount++;
////                } catch (Exception e) {
////                    log.error("Error creating next assessment for project {}: {}", projectAssessmentDetails.getProjectId(), e.getMessage(), e);
////                    nextAssessmentFailureCount++;
////                    recordFailedProject(projectAssessmentDetails.getProjectId(), optionalProject.get().getStatus(), e.getMessage(), projectAssessmentDetails);
////                }
////            } else {
////                log.info("project is inactive {} and assessment is not created ", projectAssessmentDetails.getProjectId());
////            }
////        }
////        emailDetails.put("successList", successFulProjects);
////        emailDetails.put("count", List.of(new JobNotificationDetails(null, null, null, projectsForNewAssCreation.size() + count)));
////        assessmentCreationAndNotification.sendEmailDetails(null, null, CREATE_ASSESSMENT_SUBJECT, "CreateAssessment.ftl", CREATE_ASSESSMENT.concat(LocalDate.now().format(dateFormatter)), emailDetails,"SUPPORT_EMAIL");
////
////        String newAssessmentCount = "{Success= " + newAssessmentSuccessCount + " Failed= " + newAssessmentFailureCount + " }";
////        String nextAssessmentCount = "{Success= " + nextAssessmentSuccessCount + " Failed= " + nextAssessmentFailureCount + " }";
////        return Map.of("New-Assessment", newAssessmentCount, "Next-Assessment", nextAssessmentCount);
//    	
//    }
//
//    public void recordFailedProject(Long projectId, ProjectStatus status, String message, ProjectAssessmentDetails projectAssessmentDetails) {
//        AssessmentsSchedulerFailedLogs failedProject = new AssessmentsSchedulerFailedLogs();
//        failedProject.setProjectId(projectId);
//        failedProject.setFailedAt(Instant.now());
//        failedProject.setProjectAssessmentDetails(projectAssessmentDetails);
//        failedProject.setMessage(message);
//        failedProject.setStatus(status);
//        assessmentsSchedulerFailedLogsRepository.save(failedProject);
//    }
//
//    public Map<String, Integer> processFailedProjects() {
//        log.info("processFailedProjects() method execution started");
//        Map<String, List<JobNotificationDetails>> failedProjectsJobMap = new HashMap<>();
//        List<JobNotificationDetails> failedProjectDetailsDtoList = new ArrayList<>();
//        List<JobNotificationDetails> successProjectDetailsDtoList = new ArrayList<>();
//        List<AssessmentsSchedulerFailedLogs> failedProjectInDb = assessmentsSchedulerFailedLogsRepository.findByIsProcessedAndStatus(false, ProjectStatus.Active);
//        if (!failedProjectInDb.isEmpty()) {
//
//            for (AssessmentsSchedulerFailedLogs assessmentsLogTableEntry : failedProjectInDb) {
//                try {
//                    JobNotificationDetails success = new JobNotificationDetails();
//                    if (null == assessmentsLogTableEntry.getProjectAssessmentDetails()) {
//                        Optional<Project> project = projectRepository.findById(assessmentsLogTableEntry.getProjectId());
//                        if (project.isEmpty()) {
//                            log.error("Project not found:{} ", assessmentsLogTableEntry.getProjectId());
//                            throw new ProjectNotFoundException("Project not found ");
//                        }
//                        assessmentCreationAndNotification.createAssessmentForProject(project.get());
//                        success.setProjectName(project.get().getProjectName());
//                        String accountName = accountRepository.findById(project.get().getAccountId()).orElse(new Account()).getAccountName();
//                        success.setAccountName(accountName);
//                    }
//                    if (null != assessmentsLogTableEntry.getProjectAssessmentDetails()) {
//                        assessmentCreationAndNotification.createNextAssessmentForProject(assessmentsLogTableEntry.getProjectAssessmentDetails());
//                        Optional<Project> project = projectRepository.findById(assessmentsLogTableEntry.getProjectAssessmentDetails().getProjectId());
//                        if (project.isEmpty()) {
//                            log.error("Project not found:{}", assessmentsLogTableEntry.getProjectAssessmentDetails().getProjectId());
//                            throw new ProjectNotFoundException("Project not found");
//                        }
//                        success.setProjectName(project.get().getProjectName());
//                        String accountName = accountRepository.findById(project.get().getAccountId()).orElse(new Account()).getAccountName();
//
//                        success.setAccountName(accountName);
//                    }
//                    successProjectDetailsDtoList.add(success);
//                    Optional<AssessmentsSchedulerFailedLogs> assessmentsSchedulerFailedLogs = assessmentsSchedulerFailedLogsRepository.findById(assessmentsLogTableEntry.getId());
//                    assessmentsSchedulerFailedLogs.ifPresent(failedProject -> {
//                        failedProject.setIsProcessed(true);
//                        assessmentsSchedulerFailedLogsRepository.save(failedProject);
//                        log.info("Successfully processed and removed entry from AssessmentsLogTable with ID: {}", assessmentsLogTableEntry.getId());
//
//                    });
//
//                } catch (Exception e) {
//                    Optional<AssessmentsSchedulerFailedLogs> assessmentsSchedulerFailedLogs = assessmentsSchedulerFailedLogsRepository.findById(assessmentsLogTableEntry.getId());
//                    assessmentsSchedulerFailedLogs.get().setMessage(e.getMessage());
//                    log.info("exception occurred while processing failed projects, look into AssessmentLogTable for the failed entries," + e.getMessage());
//                }
//            }
//
//            List<AssessmentsSchedulerFailedLogs> failedProjectsToSendMail = assessmentsSchedulerFailedLogsRepository.findByIsProcessedAndStatus(false, ProjectStatus.Active);
//            for (AssessmentsSchedulerFailedLogs assessmentsSchedulerFailedLogs : failedProjectsToSendMail) {
//                JobNotificationDetails failedProjectDetailsDto = new JobNotificationDetails();
//                Optional<Project> project;
//                if (null == assessmentsSchedulerFailedLogs.getProjectAssessmentDetails()) {
//                    project = projectRepository.findById(assessmentsSchedulerFailedLogs.getProjectId());
//                    if (project.isEmpty()) {
//                        throw new ProjectNotFoundException("project is not found with the id " + assessmentsSchedulerFailedLogs.getProjectId());
//                    }
//                } else {
//                    project = projectRepository.findById(assessmentsSchedulerFailedLogs.getProjectAssessmentDetails().getProjectId());
//                    if (project.isEmpty()) {
//                        throw new ProjectNotFoundException("project is not found with the id " + assessmentsSchedulerFailedLogs.getProjectAssessmentDetails().getProjectId());
//                    }
//                }
//                failedProjectDetailsDto.setProjectName(project.get().getProjectName());
//                String accountName = accountRepository.findById(project.get().getAccountId()).orElse(new Account()).getAccountName();
//                failedProjectDetailsDto.setAccountName(accountName);
//                failedProjectDetailsDto.setErrorMessage(assessmentsSchedulerFailedLogs.getMessage());
//                failedProjectDetailsDtoList.add(failedProjectDetailsDto);
//            }
//            failedProjectsJobMap.put("success", successProjectDetailsDtoList);
//            failedProjectsJobMap.put("failed", failedProjectDetailsDtoList);
//            assessmentCreationAndNotification.sendEmailDetails(null, null, FAILURE_JOB_NOTIFICATION_SUBJECT, FAILED_ASSESSMENT_JOB_TEMPLATE, FAILURE_JOB_NOTIFICATION_SUBJECT, failedProjectsJobMap,"SUPPORT_EMAIL");
//        } else {
//            assessmentCreationAndNotification.sendEmailDetails(null, null, FAILURE_JOB_NOTIFICATION_SUBJECT, FAILED_ASSESSMENT_JOB_TEMPLATE, FAILURE_JOB_NOTIFICATION_SUBJECT, failedProjectsJobMap,"SUPPORT_EMAIL");
//            log.info("There are no failed records to process this job");
//        }
//        return Map.of(
//                "Success", successProjectDetailsDtoList.size(),
//                "Failed", failedProjectDetailsDtoList.size()
//        );
//    }
//   
    public Integer checkProjectStatus() {
    	//Mysql Migration
//    	LocalDate today = LocalDate.now();
//    	ZoneId zoneId = ZoneId.systemDefault(); // Get system time zone
//    	// Start of the day (00:00:00)
//    	Instant startOfDay = today.atStartOfDay(zoneId).toInstant();
//    	// End of the day (23:59:59.999)
//    	Instant endOfDay = today.atTime(LocalTime.MAX).atZone(zoneId).toInstant();
//
//       List<Project> projectList = projectRepository.findByEndDateBetween(getStartOfTodayInMillis(), getEndOfTodayInMillis());
//    //	List<Project> projectList = projectRepository.findByEndDateBetween(startOfDay, endOfDay);
//    	for (Project project : projectList) {                    
//            if (project.getStatus().equals(ProjectStatus.Active)) {
//                project.setStatus(ProjectStatus.Inactive);
//                projectRepository.save(project);
//                List<AssessmentsSchedulerFailedLogs> assessmentsSchedulerFailedLogsList = assessmentsSchedulerFailedLogsRepository.findByProjectId(project.getId());
//                assessmentsSchedulerFailedLogsList
//                        .forEach(assessmentsSchedulerFailedLogs -> {
//                            assessmentsSchedulerFailedLogs.setStatus(ProjectStatus.Inactive);
//                            assessmentsSchedulerFailedLogsRepository.save(assessmentsSchedulerFailedLogs);
//                        });
//                List<UUID> oidList = project.getDedRoles().stream()
//                       .filter(dedRoles -> dedRoles.getRole().equalsIgnoreCase("DM") || dedRoles.getRole().equalsIgnoreCase("DP"))
//                        .map(DedRolesmy::getOid).toList();
//                for (UUID oid : oidList) {
//                    Optional<AzureUsers> azureUser = azureUserRepository.findById(oid);
//                    if (azureUser.isEmpty()) {
//                        throw new CustomException("User is not found with id ", HttpStatus.NOT_FOUND);
//                    }
//                    prepareEmailDetails(project, azureUser.get().getMail(), azureUser.get().getDisplayName());
//                }
//            }
//
//        }
//        return projectList.size();
    	return 0;
    }
//
    private void prepareEmailDetails(Project project, String mail, String userName) {
    	
    
//        SendEmailDetailsDto sendEmailDetailsDto = new SendEmailDetailsDto();
//        String accountName = accountRepository.findById(project.getAccountId()).orElse(new Account()).getAccountName();
//        sendEmailDetailsDto.setAccountName(accountName);
//        sendEmailDetailsDto.setProjectName(project.getProjectName());
//        sendEmailDetailsDto.setTemplateName(ASSESSMENT_SUBMISSION_REMAINDER_TEMPLATE);
//        sendEmailDetailsDto.setSubject("DE Dashboard - Project ".concat(project.getProjectName()).concat("ended"));
//        sendEmailDetailsDto.setMessage(PROJECT_ENDED);
//        sendEmailDetailsDto.setProjectType(project.getDeliveryInfo().getProjectType());
//        sendEmailDetailsDto.setEmailId(List.of(mail));
//        sendEmailDetailsDto.setUserName(userName);
//        sendEmailDetailsDto.setEmailType("PROJECT_ENDDATE_CHECK_EMAIL");
//        emailService.send(sendEmailDetailsDto);
   }

    public static long getStartOfTodayInMillis() {
        LocalDate today = LocalDate.now();
        ZonedDateTime startOfDay = today.atStartOfDay(ZoneId.systemDefault());
        return startOfDay.toInstant().toEpochMilli();
    }
//
    public static long getEndOfTodayInMillis() {
        LocalDate today = LocalDate.now();
        ZonedDateTime endOfDay = today.plusDays(1).atStartOfDay(ZoneId.systemDefault());
        return endOfDay.toInstant().toEpochMilli() - 1;
    }
//
    public void saveAssessmentDraft(AssessmentDraftRequestDto assessmentDraftRequestDto, Long assessmentId, String action,UUID userId) {

//        log.info("AssessmentService.saveAssessmentDraft - {}:: start", assessmentId);
//        AssessmentDraft assessmentDraft = new AssessmentDraft();
//
//        Optional<AssessmentDraft> existingAssessmentDraft = assessmentDraftRepository.findByAssessmentId(assessmentId);
//
//        existingAssessmentDraft.ifPresentOrElse(existingDraft -> BeanUtils.copyProperties(existingDraft, assessmentDraft),
//                () -> {
//                    Optional<Assessment> existingAssessment = assessmentRepository.findById(assessmentId);
//                    existingAssessment.ifPresentOrElse(assessment -> BeanUtils.copyProperties(assessment, assessmentDraft), () -> {
//                        throw new CustomException("Assessment not found", HttpStatus.NOT_FOUND);
//                    });
//                });
//   //    List<TemplateCategory> existingTemplateCategories = assessmentDraft.getTemplateCategory();
//       
//       List<TemplateCategory> existingTemplateCategories = assessmentDraft.getTemplateCategory().stream()
//    		    .map(myCategory -> {
//    		        TemplateCategory category = new TemplateCategory(myCategory.getName(), null);
//    		        List<MyQuestion> questions = fetchQuestionsForCategory(category);
//    		        category.setQuestions(questions);
//    		        return category;
//    		    })
//    		    .collect(Collectors.toList());
//
//       
//        if (SUBMIT.equalsIgnoreCase(action)) {
//
//            existingTemplateCategories.stream()
//                    .filter(existingCategory -> assessmentDraftRequestDto.getCategoryType().equals(existingCategory.getName()))
//                    .forEach(existingCategory -> {
//                        List<Question> questions = QuestionMapper.MAPPER.questionDtoListToQuestionList(assessmentDraftRequestDto.getQuestions(), existingCategory.getQuestions());
//                        existingCategory.setQuestions(questions);
//                      log.info("Questions",questions);
//                    });
//
//
//        } else if (REVIEW.equalsIgnoreCase(action)) {
//
//            existingTemplateCategories.stream()
//                    .filter(existingCategory -> assessmentDraftRequestDto.getCategoryType().equals(existingCategory.getName()))
//                    .forEach(templateCategory ->
//                            templateCategory.getQuestions().forEach(question -> {
//                                String comments = assessmentDraftRequestDto.getReviewComments().stream().filter(c -> question.getNumber() == c.getQuestionNumber()).findAny().orElse(new ReviewComments()).getReviewComment();
//                                question.setReviewerComment(comments);
//                            })
//                    );
//            assessmentDraft.setOverallComment(assessmentDraftRequestDto.getOverallComment());
//            assessmentDraft.setReasonForReassign(assessmentDraftRequestDto.getReasonForReassign());
//        }
//        assessmentDraft.setTemplateCategory(existingTemplateCategories);
//        assessmentDraft.setAssessmentId(assessmentId);
//        assessmentDraft.setUpdatedBy(utilMethods.getDisplayName(userId));
//        assessmentDraftRepository.save(assessmentDraft);
//        log.info("AssessmentService.saveAssessmentDraft - {}:: end", assessmentId);
//
//    }
    }

}
