package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.ArtifactType;
import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.Entity.Template;
import com.maveric.delivery.utils.JsonFileReader;
//import io.mongock.api.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Query;

import java.io.IOException;
import java.util.List;

//@ChangeUnit(id = "ArtifactTypes-v.0.2", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@AllArgsConstructor
public class ArtifactTypesMigration implements Migration{
 //  private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/artifactTypes.json";


 //   @BeforeExecution
    @Override
    public void before() {
        log.info("ArtifactTypes Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
   // @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("ArtifactTypes Migration RollbackBeforeExecution");
    }

    
    //Comment du to mongo template
    
    @Override
    public void migrationMethod() throws IOException {
        log.info("ArtifactTypes migrationMethod");
//        mongoTemplate.remove(new Query(), ArtifactType.class);
//        List<ArtifactType> artifactTypes= jsonFileReader.readJsonFileToList(filePath, ArtifactType.class);
//        mongoTemplate.insertAll(artifactTypes);
    }

    
    @Override
    public void rollback() {
        log.info("ArtifactTypes Migration RollbackBeforeExecution");
    }
}
