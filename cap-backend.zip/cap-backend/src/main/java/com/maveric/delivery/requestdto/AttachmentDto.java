package com.maveric.delivery.requestdto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttachmentDto {
        @NotBlank(message = "Name is required")
        private String name;
        @NotBlank(message = "File type is required")
        private String type;
}
