package com.maveric.delivery.requestdto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeamMemberFilterDto {

    @Size(max = 3, message = "A maximum of 3 ProjectRoles are allowed")
    private List<String> projectRole;
    private String location;
    private List<String> skillSet;
    private Boolean isBillable;
    @Min(value = 0)
    private Long allocationFrom;
    @Max(value = 100)
    private Long allocationTo;
    private String sortBy;

}
