package com.maveric.delivery.model.embedded;

public enum AssessmentStatus {

    PENDING,IN_PROGRESS,OVERDUE_IN_PROGRESS,SUBMITTED,OVERDUE,REVIEWED,EXPIRED;
}
