package com.maveric.delivery.repository;

import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.model.embedded.ProjectStatus;
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;


public class ProjectRepository {// extends MongoRepository<Project,Long> {
//    boolean existsByProjectName(String accountName);
//    List<Project> findByAccountId(Long accountId);
//    List<Project> findByAccountIdAndStatus(Long accountId, String status);
//    List<Project> findByAccountIdInAndStatus(List<Long> accountIds, ProjectStatus status);
//
//    Optional<Project> findByIdAndAccountId(Long Id,Long accountId);
//    List<Project> findByIdIn(Set<Long> list);
//
//    @Query("{ 'deliveryInfo.assessmentStartDate' : ?0, 'status' : ?1 }")
//    List<Project> findByAssessmentStartDateAndStatus(Instant assessmentStartDate, ProjectStatus status);
//
//    long countByAccountId(Long accountId);
//    long countByAccountIdAndStatus(Long accountId,ProjectStatus status);
//
//    @Query("{ 'endDate': { $gte: ?0, $lte: ?1 } }")
//    List<Project> findByEndDateBetween(long startOfDay, long endOfDay);




}
