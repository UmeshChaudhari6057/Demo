package com.maveric.delivery.requestdto;



import com.maveric.delivery.Entity.Artifact;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArtifactDto {
    @NotBlank(message = "Artifact name is required")
    @Size(min=3,max = 50, message = "Minimum of 3 and maximum of 50 char are allowed")
    @Pattern(regexp = "^[a-zA-Z0-9,\\.\\&\\- ]+$", message = "Name can only contain alphabets, numbers, comma, dot, & and hyphen")
    private String name;
    @NotBlank(message = "Artifact name is required")
    private String type;
    
    //MySQL code and class references have changed
    private Artifact attachment;
    @Size(min=3,max = 150, message = "Minimum of 3 and maximum of 150 char are allowed")
    private String link;
    @NotNull
    @Size(min=3, max = 100, message = "Minimum of 3 and maximum of 100 char are allowed")
    @Pattern(regexp = "^[a-zA-Z0-9,\\.\\&\\(\\)\\- ]+$", message = "Comments can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String comments;
    private Long createdAt;
    private String creatorName;
    private UUID createdBy;
    @NotNull
    private Long projectId;

    public void setLink(String link) {

        if (!StringUtils.isEmpty(link) && !StringUtils.isEmpty(attachment.getLink())) {
            throw new IllegalArgumentException("Either attachment or link should be available in the request ");
        }

    }
}
