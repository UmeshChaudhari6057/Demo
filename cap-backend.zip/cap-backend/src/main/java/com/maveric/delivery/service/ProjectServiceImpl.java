package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.ACCOUNTS;
import static com.maveric.delivery.utils.Constants.ACCOUNT_ADMIN_;
import static com.maveric.delivery.utils.Constants.ACCOUNT_ID;
import static com.maveric.delivery.utils.Constants.ACCOUNT_PARTNER;
import static com.maveric.delivery.utils.Constants.ACTING_DELIVERY_MANAGER;
import static com.maveric.delivery.utils.Constants.ADM;
import static com.maveric.delivery.utils.Constants.ALL_CHANGES;
import static com.maveric.delivery.utils.Constants.AP;
import static com.maveric.delivery.utils.Constants.ARTIFACTS;
import static com.maveric.delivery.utils.Constants.ARTIFACTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.ASSESSMENTS;
import static com.maveric.delivery.utils.Constants.ASSESSMENTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.CHANGE_HISTORY_UPDATED_AT;
import static com.maveric.delivery.utils.Constants.CREATED_AT;
import static com.maveric.delivery.utils.Constants.DED_ROLES;
import static com.maveric.delivery.utils.Constants.DELIVERY_IMPACT;
import static com.maveric.delivery.utils.Constants.DELIVERY_IMPACT_EDIT;
import static com.maveric.delivery.utils.Constants.DELIVERY_IMPACT_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.DELIVERY_MANAGER;
import static com.maveric.delivery.utils.Constants.DELIVERY_PARTNER;
import static com.maveric.delivery.utils.Constants.DH;
import static com.maveric.delivery.utils.Constants.DM;
import static com.maveric.delivery.utils.Constants.DP;
import static com.maveric.delivery.utils.Constants.ENGAGEMENT_PARTNER;
import static com.maveric.delivery.utils.Constants.EP;
import static com.maveric.delivery.utils.Constants.FULL_ACCESS;
import static com.maveric.delivery.utils.Constants.ID;
import static com.maveric.delivery.utils.Constants.LAST_30_DAYS;
import static com.maveric.delivery.utils.Constants.NAME;
import static com.maveric.delivery.utils.Constants.NO;
import static com.maveric.delivery.utils.Constants.NO_ACCESS;
import static com.maveric.delivery.utils.Constants.NO_CHANGES;
import static com.maveric.delivery.utils.Constants.OLDER_30_DAYS;
import static com.maveric.delivery.utils.Constants.O_ID;
import static com.maveric.delivery.utils.Constants.PROJECTS;
import static com.maveric.delivery.utils.Constants.PROJECTS_EDIT;
import static com.maveric.delivery.utils.Constants.PROJECTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.PROJECTS_VIEW_ASSOCIATED;
import static com.maveric.delivery.utils.Constants.PROJECT_ID;
import static com.maveric.delivery.utils.Constants.ROLE;
import static com.maveric.delivery.utils.Constants.STATUS;
import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.TEMPLATE;
import static com.maveric.delivery.utils.Constants.YES;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Sort;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.maveric.delivery.Entity.Frequency;
import com.maveric.delivery.Entity.Template;
import com.maveric.delivery.exception.AccountNotFoundException;
import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.DuplicateProjectsException;
import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.exception.ProjectDateException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.exception.ProjectStatusException;
import com.maveric.delivery.exception.ValidationException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Assessment;
import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.DeliveryImpact;
import com.maveric.delivery.Entity.EngagementType;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.ProjectAssessmentDetails;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.model.embedded.ChangeHistory;
import com.maveric.delivery.model.embedded.ClientContacts;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.DeliveryInformation;
import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.model.embedded.ExternalSystemInfo;
import com.maveric.delivery.model.embedded.OtherInformation;
import com.maveric.delivery.model.embedded.ProjectClientInfo;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.mysqlrepository.EngagementTypemysqlRepository;
import com.maveric.delivery.mysqlrepository.FrequencymysqlRepository;

import com.maveric.delivery.mysqlrepository.TemplatemysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.mysqlrepository.AssessmentmysqlRepository;
import com.maveric.delivery.mysqlrepository.AssessmentTemplatemysqlRepository;
import com.maveric.delivery.mysqlrepository.BusinessSubverticalmysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.mysqlrepository.DeliveryImpactmysqlRepository;
import com.maveric.delivery.mysqlrepository.ProjectAssessmentDetailsmysqlRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.requestdto.AccountRoles;
import com.maveric.delivery.requestdto.DateRangeDto;
import com.maveric.delivery.requestdto.DeliveryImpactDto;
import com.maveric.delivery.requestdto.DeliveryInformationDto;
import com.maveric.delivery.requestdto.ProjectFilterDto;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.DeliveryImpactResponseDto;
import com.maveric.delivery.responsedto.FilterRolesResponseDto;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.UtilMethods;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProjectServiceImpl implements ProjectService {

  //  private final ProjectRepository projectRepository;
  //  private final AccountRepository accountRepository;
    private final DedRolesRepository dedRolesRepository;
    private final UserServiceImpl userServiceImpl;
    private final UtilMethods utils;
    private final BusinessSubverticalmysqlRepository businessSubverticalRepository;
    private final FrequencymysqlRepository frequencyRepository;
    private final EngagementTypemysqlRepository engagementTypeRepository;
//    private final MongoTemplate mongoTemplate;
    private final DeliveryImpactmysqlRepository deliveryImpactRepository;
    private final TemplatemysqlRepository templateRepository;
    private final AssessmentTemplatemysqlRepository assessmentTemplateRepository;
    private final ProjectAssessmentDetailsmysqlRepository projectAssessmentDetailsRepository;
    private final AssessmentCreationAndNotification assessmentCreationAndNotification;
    private final AssessmentmysqlRepository assessmentRepository;


    @Override
    public ProjectResponseDto saveProject(ProjectRequestDto projectDto,UUID oid) {
//        Optional<Account> account = accountRepository.findById(projectDto.getAccountId());
//        if(account.isEmpty()){
//            log.error("ProjectServiceImpl::saveProject::  Account not found:{}",projectDto.getAccountId());
//            throw new AccountNotFoundException("Account not found");
//        }
//        List<Project> projectList = projectRepository.findByAccountId(projectDto.getAccountId());
//        if (projectList != null && projectList.stream().anyMatch(p -> p.getProjectName().equals(projectDto.getProjectName()))) {
//            log.error("ProjectServiceImpl::saveProject::error - Duplicate project name");
//            throw new DuplicateProjectsException("Project name '" + projectDto.getProjectName() + "' already exists");
//        }
//        validateClientContactDetails(projectDto.getClientInformation());
//        LocalDate startDate = Instant.ofEpochMilli(projectDto.getStartDate())
//                .atZone(ZoneId.systemDefault())
//                .toLocalDate();
//        if (startDate.isAfter(LocalDate.now())) {
//            log.error("ProjectServiceImpl::Future date is not allowed::error");
//            throw new ProjectDateException("Future date is not allowed: start date must be a past or current date");
//        }
//
//        //check project start date is after account start date
//         if (isValidProjectAndAccountDate(projectDto.getStartDate(), account.get().getDateOnboarded())) {
//            log.error("ProjectServiceImpl::Project start date::error");
//            throw new ProjectDateException("Project start date should be after account onboarded date");
//        }
//
//        LocalDate assessmentStartDate = Instant.ofEpochMilli(projectDto.getDeliveryInfo().getAssessmentStartDate())
//                .atZone(ZoneOffset.UTC)
//                .toLocalDate();
//         if(assessmentStartDate.isEqual(startDate) || startDate.isAfter(assessmentStartDate)){
//             throw new ProjectDateException("Assessment Start date should be after project start date");
//         }
//
//        validateBusinessSubVerticalAndFrequencyAndEngagementType(projectDto.getBusinessSubVertical(),
//                projectDto.getDeliveryInfo().getFrequency(),projectDto.getEngagementType());
//        OtherInformation otherInformation = projectDto.getOtherInformation();
//        if (otherInformation != null) {
//            List<ExternalSystemInfo> externalSystemInfoList = otherInformation.getExternalSystemInfo();
//            if (externalSystemInfoList != null) {
//                for (ExternalSystemInfo info : externalSystemInfoList) {
//                    if (info.getId() == null || info.getName() == null) {
//                        throw new IllegalArgumentException("Both id and name are required for external system info");
//                    }
//                }
//            }
//            log.info("OtherInformation is null.");
//        }
//        utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getAccountPartner().getUserId(),AP);
//        utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getEngagementPartner().getUserId(), EP);
//        utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getDeliveryPartner().getUserId(),DP);
//        Project project = new Project();
//        log.info("ProjectServiceImpl::existsByAccountName::started");
//        BeanUtils.copyProperties(projectDto, project);
//        project.setDedRoles(mapToDedRoles(projectDto));
//        project.setStatus(ProjectStatus.Active);
//        DeliveryInformation deliveryInformation = new DeliveryInformation();
//        projectDto.getDeliveryInfo().getAssessmentTemplates().forEach(baseInfo -> {
//            Optional<AssessmentTemplate> deliveryTemplate = assessmentTemplateRepository.findById(baseInfo.getId());
//            if (deliveryTemplate.isEmpty()) {
//                log.error("Template not found with ID: {}",  baseInfo.getId());
//                throw new CustomException("Template not found ", HttpStatus.NOT_FOUND);
//            }
//            deliveryTemplate.ifPresent(assessmentTemplate -> baseInfo.setName(assessmentTemplate.getTemplateName()));
//        });
//        BeanUtils.copyProperties(projectDto.getDeliveryInfo(), deliveryInformation);
//        project.setDeliveryInfo(deliveryInformation);
//        project.setEndDate(null);
//        deliveryInformation.setAssessmentStartDate(assessmentStartDate);
//        projectRepository.save(project);
//        ProjectResponseDto projectResponseDto= mapProjectToResponseDto(project);
//        userServiceImpl.saveRole(projectResponseDto);
//        return setPrivilegesToResponse(projectResponseDto,oid);
    	return new ProjectResponseDto();

    }

private boolean isValidProjectAndAccountDate(Long prStartDate, Long accStartDate){
    LocalDate projectStartDate = Instant.ofEpochMilli(prStartDate)
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    LocalDate accountStartDate = Instant.ofEpochMilli(accStartDate)
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    return !(projectStartDate.isAfter(accountStartDate)||projectStartDate.isEqual(accountStartDate));
}


    @Override
    public ProjectResponseDto editProject(ProjectRequestDto projectDto,Long projectId,UUID oid)  {
//        Optional<Project> projectObj=projectRepository.findById(projectId);
//        if(projectObj.isEmpty()){
//            log.error("ProjectServiceImpl::editProject:: Project id not found");
//            throw new ProjectNotFoundException("No project found with Id "+projectId);
//        }
//        boolean updateAssessment=false;
//        if(!projectObj.get().getDeliveryInfo().getFrequency().equalsIgnoreCase(projectDto.getDeliveryInfo().getFrequency())){
//           updateAssessment=true;
//        }
//        validateClientContactDetails(projectDto.getClientInformation());
//        Long accountId=projectObj.get().getAccountId();
//        String highestRole=userServiceImpl.getHighestRole(oid,accountId,projectId);
//        List<String> privileges=utils.getPrivilegesString(highestRole,List.of(PROJECTS));
//        if(highestRole.equalsIgnoreCase(SUPER_ADMIN_)
//                ||(dedRolesRepository.existsByOidAndAccount_IdAndRole(oid,accountId, DH)
//                && utils.getPrivilegesString(ACCOUNT_ADMIN_,List.of(PROJECTS)).contains(PROJECTS_EDIT))
//                ||privileges.contains(PROJECTS_EDIT))
//        {
//            Optional<Account> account = accountRepository.findById(projectDto.getAccountId());
//            if (account.isEmpty()) {
//                log.error("ProjectServiceImpl::editProject:: Account not found :{}",projectDto.getAccountId());
//                throw new AccountNotFoundException("Account not found");
//
//            }
//            Optional<Project> projectOptional = projectRepository.findByIdAndAccountId(projectId, projectDto.getAccountId());
//            if (projectOptional.isPresent()) {
//                Project project = projectOptional.get();
//                if (!project.getProjectName().trim().equals(projectDto.getProjectName().trim())) {
//                    List<Project> projectList = projectRepository.findByAccountId(projectDto.getAccountId());
//                    if (projectList.stream().anyMatch(p -> p.getProjectName().equals(projectDto.getProjectName()))) {
//                        log.error("ProjectServiceImpl::saveProject::error - Duplicate project name");
//                        throw new DuplicateProjectsException("Project name '" + projectDto.getProjectName() + "' already exists");
//                    }
//                }
//                Long startDateMills=  project.getStartDate();
//                LocalDate startDate = Instant.ofEpochMilli(startDateMills)
//                        .atZone(ZoneId.systemDefault())
//                        .toLocalDate();
//                if (startDate.isAfter(LocalDate.now())) {
//                    throw new ProjectDateException("Future date is not allowed: start date must be a past or current date");
//                }
//                if (projectDto.getEndDate() != null) {
//                    LocalDate endDate = Instant.ofEpochMilli(projectDto.getEndDate())
//                            .atZone(ZoneId.systemDefault())
//                            .toLocalDate();
//                    if (startDate.isAfter(endDate)) {
//                        throw new ProjectDateException("End date must be a after start date");
//                    }
//                }
//                if (isValidProjectAndAccountDate(project.getStartDate(), account.get().getDateOnboarded())) {
//                    log.error("ProjectServiceImpl::Edit: Project start date::error");
//                    throw new ProjectDateException("Project start date should be after account onboarded date");
//                }
//                LocalDate assessmentStartDate = project.getDeliveryInfo().getAssessmentStartDate();
//
//                if(assessmentStartDate.isEqual(startDate) || startDate.isAfter(assessmentStartDate)){
//                    throw new ProjectDateException("Assessment Start date should be after project start date");
//                }
//                validateBusinessSubVerticalAndFrequencyAndEngagementType(projectDto.getBusinessSubVertical(),
//                        projectDto.getDeliveryInfo().getFrequency(), projectDto.getEngagementType());
//                OtherInformation otherInformation = projectDto.getOtherInformation();
//                if (otherInformation != null) {
//                    List<ExternalSystemInfo> externalSystemInfoList = otherInformation.getExternalSystemInfo();
//                    if (externalSystemInfoList != null) {
//                        for (ExternalSystemInfo info : externalSystemInfoList) {
//                            if (info.getId() == null || info.getName() == null) {
//                                throw new IllegalArgumentException("Both id and name are required for external system info");
//                            }
//                        }
//                    }
//                }
//                if (projectDto.getStatus() == null) {
//                    log.error("ProjectServiceImpl::editProject:: Status should not be null");
//                    throw new ProjectStatusException("Status should not be null");
//                }
//
//                utils.checkValidRole(projectDto.getAccountId(), projectDto.getDeliveryInfo().getAccountPartner().getUserId(), AP);
//                utils.checkValidRole(projectDto.getAccountId(), projectDto.getDeliveryInfo().getEngagementPartner().getUserId(), EP);
//                utils.checkValidRole(projectDto.getAccountId(), projectDto.getDeliveryInfo().getDeliveryPartner().getUserId(), DP);
//                BeanUtils.copyProperties(projectDto, project);
//                project.setDedRoles(mapToDedRoles(projectDto));
//                DeliveryInformation deliveryInformation = new DeliveryInformation();
//                projectDto.getDeliveryInfo().getAssessmentTemplates().forEach(baseInfo -> {
//                    Optional<AssessmentTemplate> deliveryTemplate = assessmentTemplateRepository.findById(baseInfo.getId());
//                    if (deliveryTemplate.isEmpty()) {
//                        log.error("Template not found with ID: {}" , baseInfo.getId());
//                        throw new CustomException("Template not found ", HttpStatus.NOT_FOUND);
//                    }
//                    deliveryTemplate.ifPresent(assessmentTemplate -> baseInfo.setName(assessmentTemplate.getTemplateName()));
//                });
//                BeanUtils.copyProperties(projectDto.getDeliveryInfo(), deliveryInformation);
//                project.setDeliveryInfo(deliveryInformation);
//                project.setStartDate(startDateMills);
//                deliveryInformation.setAssessmentStartDate(assessmentStartDate);
//                projectRepository.save(project);
//                ProjectResponseDto projectResponseDto = mapProjectToResponseDto(project);
//                dedRolesRepository.deleteByAccount_IdAndProject_Id(projectDto.getAccountId(), projectId);
//                userServiceImpl.saveRole(projectResponseDto);
//                if(updateAssessment){
//                    Optional<ProjectAssessmentDetails> latestAssessmentOfTheProject=projectAssessmentDetailsRepository.findFirstByProjectIdOrderByNextAssessmentCreationDateDesc(projectId);
//                    if(latestAssessmentOfTheProject.isPresent()){
//                        Frequency frequency=frequencyRepository.findByName(project.getDeliveryInfo().getFrequency());
//                        Optional<Assessment> ass=assessmentRepository.findById(latestAssessmentOfTheProject.get().getAssessmentId());
//                        if(ass.isPresent()) {
//                            assessmentCreationAndNotification.updateProjectAssessmentDetails(latestAssessmentOfTheProject.get(), ass.get(), frequency.getDays());
//                            ass.get().setDueOn(assessmentCreationAndNotification.calculateDueDate(System.currentTimeMillis(), frequency.getDays() - 1));
//                            assessmentRepository.save(ass.get());
//                        }
//                    }
//                }
//                return setPrivilegesToResponse(projectResponseDto, oid);
//            } else {
//                log.error("ProjectServiceImpl::editProject:: Incorrect combination of account id and project id");
//                throw new ProjectNotFoundException("Incorrect combination of account id and project id");
//            }
//        }
//        throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
         
    	return new ProjectResponseDto();
  
    }

    private void validateClientContactDetails(ProjectClientInfo clientInformation) throws ValidationException {

        if(!CollectionUtils.isEmpty(clientInformation.getClientContacts())){
            Predicate<ClientContacts> predicate = clientContacts -> (clientContacts.getContactName() == null || clientContacts.getContactNumber() == null
                    || clientContacts.getDesignation() == null || clientContacts.getEmailId() == null);
            if (clientInformation.getClientContacts().stream().anyMatch(predicate)) {
                throw new ValidationException(FailedMessage.VALIDATION_EXCEPTION.getMessage(),Collections.singletonList(new ErrorMessage("Client Contacts", "The request could not be processed. Please Add Name, Designation, Email ID, Contact Number")));
            }
        }
    }


    public ProjectResponseDto getProjectById(Long projectId,UUID oid) {
//        log.info("ProjectServiceImpl::getProjectById:: call start");
//        Optional<Project> optionalProject = projectRepository.findById(projectId);
//        AtomicReference<ProjectResponseDto> projectResponseDto = new AtomicReference<>();
//        optionalProject.ifPresentOrElse(project -> {
//            projectResponseDto.set(mapProjectToResponseDto(project));
//            setPrivilegesToResponse(projectResponseDto.get(), oid);
//        }, () -> {
//            log.error("Project not found : {}", projectId);
//            throw new ProjectNotFoundException("Project not found");
//        });
//        log.info("ProjectServiceImpl::getProjectById:: call ended");
//        return projectResponseDto.get();
    	return new ProjectResponseDto();

    }

    public ProjectResponseDto setPrivilegesToResponse(ProjectResponseDto projectResponseDto,UUID oid){
        String appLevelHighestRole = userServiceImpl.getHighestRole(oid,null,null);
        if(appLevelHighestRole.isBlank()){
            projectResponseDto.setPrivileges(List.of(NO_ACCESS));
            return projectResponseDto;
        }
        if (appLevelHighestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
            projectResponseDto.setPrivileges(List.of(FULL_ACCESS));
            return projectResponseDto;
        }
        if (dedRolesRepository.existsByOidAndAccount_IdAndRole(oid, projectResponseDto.getAccountId(), DH)){//account level DH allowing allcthe access of artifcats, team members and assessmnets
            projectResponseDto.setPrivileges(utils.getPrivilegesString(ACCOUNT_ADMIN_, List.of(PROJECTS, ARTIFACTS, TEAM_MEMBERS, ASSESSMENTS,DELIVERY_IMPACT)));
            return projectResponseDto;
        }
        String projectLevelHighestRole = userServiceImpl.getHighestRole(oid, projectResponseDto.getAccountId(), projectResponseDto.getProjectId());
        String highestRoleAccLevel = userServiceImpl.getHighestRole(oid, projectResponseDto.getAccountId(),null);
        List<String> privileges=utils.getPrivilegesString(projectLevelHighestRole,List.of(PROJECTS,ARTIFACTS, TEAM_MEMBERS, ASSESSMENTS,DELIVERY_IMPACT));
        if (!projectLevelHighestRole.isBlank()) {
            projectResponseDto.setPrivileges(privileges);
            return projectResponseDto;
        } else if (!highestRoleAccLevel.isBlank()) {//not associated to project,send only view access to artifacts, teammembers , assessments,delivery impact
            List<String> accLevelPrivileges= utils.getPrivilegesString(highestRoleAccLevel,List.of(PROJECTS,ARTIFACTS, TEAM_MEMBERS, ASSESSMENTS,DELIVERY_IMPACT));
            List<String> privilegesList=new ArrayList<>();
            if(accLevelPrivileges.contains(TEAM_MEMBERS_VIEW_ALL)){
                privilegesList.add(TEAM_MEMBERS_VIEW_ALL);
            }
            if(accLevelPrivileges.contains(ARTIFACTS_VIEW_ALL)){
                privilegesList.add(ARTIFACTS_VIEW_ALL);
            }
            if(accLevelPrivileges.contains(ASSESSMENTS_VIEW_ALL)){
                privilegesList.add(ASSESSMENTS_VIEW_ALL);
            }
            if(accLevelPrivileges.contains(DELIVERY_IMPACT_VIEW_ALL)){
                privilegesList.add(DELIVERY_IMPACT_VIEW_ALL);
            }
            projectResponseDto.setPrivileges(privilegesList);
            return projectResponseDto;
        }else{
            List<String> accLevelPrivileges= utils.getPrivilegesString(appLevelHighestRole,List.of(PROJECTS,ARTIFACTS, TEAM_MEMBERS, ASSESSMENTS,DELIVERY_IMPACT));
            List<String> privilegesList=new ArrayList<>();
            if(accLevelPrivileges.contains(TEAM_MEMBERS_VIEW_ALL)){
                privilegesList.add(TEAM_MEMBERS_VIEW_ALL);
            }
            if(accLevelPrivileges.contains(ARTIFACTS_VIEW_ALL)){
                privilegesList.add(ARTIFACTS_VIEW_ALL);
            }
            if(accLevelPrivileges.contains(ASSESSMENTS_VIEW_ALL)){
                privilegesList.add(ASSESSMENTS_VIEW_ALL);
            }
            if(accLevelPrivileges.contains(DELIVERY_IMPACT_VIEW_ALL)){
                privilegesList.add(DELIVERY_IMPACT_VIEW_ALL);
            }
            projectResponseDto.setPrivileges(privilegesList);
            return projectResponseDto;
        }

    }



    private List<DedRolesmy> mapToDedRoles(ProjectRequestDto projectDto) {
        List<DedRolesmy> dedRoles = new ArrayList<>();
        Set<String> existingUserIds = new HashSet<>();
        addDedRoles(projectDto.getDeliveryInfo().getDeliveryManager(), existingUserIds, dedRoles,DELIVERY_MANAGER);
        addDedRoles(projectDto.getDeliveryInfo().getActingDeliveryManager(), existingUserIds, dedRoles, ACTING_DELIVERY_MANAGER);
        addDedRoles(projectDto.getDeliveryInfo().getAccountPartner(), existingUserIds, dedRoles,ACCOUNT_PARTNER);
        addDedRoles(projectDto.getDeliveryInfo().getEngagementPartner(), existingUserIds, dedRoles,ENGAGEMENT_PARTNER);
        addDedRoles(projectDto.getDeliveryInfo().getDeliveryPartner(), existingUserIds, dedRoles,DELIVERY_PARTNER);

            return dedRoles;
    }

    private void addDedRoles(AccountRoles role, Set<String> existingUserIds, List<DedRolesmy> dedRoles,String roleName) {
       if(Objects.nonNull(role)){
           userServiceImpl.checkAndAddUserId(existingUserIds, role,roleName);
           dedRoles.add(new DedRolesmy(role.getUserId(), null, null, role.getName(), mapRoleName(roleName)));
       }
    }

    private String mapRoleName(String roleName) {
        return switch (roleName) {
            case DELIVERY_MANAGER -> DM;
            case ACCOUNT_PARTNER -> AP;
            case ENGAGEMENT_PARTNER -> EP;
            case DELIVERY_PARTNER -> DP;
            case ACTING_DELIVERY_MANAGER -> ADM;
            default -> roleName;
        };
    }

    private ProjectResponseDto mapProjectToResponseDto(Project project) {
//        ProjectResponseDto responseDto = new ProjectResponseDto();
//        BeanUtils.copyProperties(project, responseDto);
//
//        if (Objects.nonNull(project.getAccountId())){
//            accountRepository.findById(project.getAccountId()).ifPresent(account ->
//                responseDto.setAccountName(account.getAccountName())
//            );
//        }
//
//        responseDto.setProjectId(project.getId());
//        responseDto.setIsBillable(project.getIsBillable().equals(true)?YES:NO);
//        DeliveryInformationDto deliveryInformationDto = new DeliveryInformationDto();
//        if (project.getDeliveryInfo() != null) {
//            BeanUtils.copyProperties(project.getDeliveryInfo(), deliveryInformationDto);
//        }
//        responseDto.setDeliveryInfo(deliveryInformationDto);
//        deliveryInformationDto.setDeliveryManager(returnUserRole(project.getDedRoles(), DM));
//        deliveryInformationDto.setActingDeliveryManager(returnUserRole(project.getDedRoles(), ADM));
//        deliveryInformationDto.setAccountPartner(returnUserRole(project.getDedRoles(), AP));
//        deliveryInformationDto.setEngagementPartner(returnUserRole(project.getDedRoles(), EP));
//        deliveryInformationDto.setDeliveryPartner(returnUserRole(project.getDedRoles(), DP));
//        LocalDateTime localDateTime = project.getDeliveryInfo().getAssessmentStartDate().atStartOfDay();
//        deliveryInformationDto.setAssessmentStartDate(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
//        return responseDto;
    	return new ProjectResponseDto();
    }


    private AccountRoles returnUserRole(List<DedRolesmy> dedRoles, String roleName) {
       return dedRoles.stream().filter(dedRole -> roleName.equals(dedRole.getRole())).findAny().map(dedRole ->new AccountRoles(dedRole.getOid(), dedRole.getName())).orElse(null);
    }

    @Override
    public boolean validateProjectName(Long accountId, String value) {
//         Optional<Account> account=accountRepository.findById(accountId);
//         if(account.isEmpty()){
//             log.error("ProjectServiceImpl::validateProjectName:: Account not found");
//             throw new AccountNotFoundException("Account ID "+account+" not found");
//         }
//        List<Project> projectList = projectRepository.findByAccountId(accountId);
//        if(!projectList.isEmpty()){
//            return projectList.stream().noneMatch(project -> project.getProjectName().trim().equalsIgnoreCase(value));
//        }else {
//            return true;
//        }
    	return true;
    }
    //Due to Mongo Template code is comment
    public ProjectsListDto getProjectDetailsList(UUID oid, Long accountId, ProjectFilterDto filter)  {
//        ProjectsListDto projectsListDto=new ProjectsListDto();
//        log.info("ProjectServiceImpl::getProjectDetailsList:: call started");
//        List<DedRolesmy> dedRolesList;
//        Criteria criteria = new Criteria();
//        List<Criteria> criteriaList=new ArrayList<>();
//        String highestRole = userServiceImpl.getHighestRole(oid, null, null);
//        List<String> privileges = utils.getPrivilegesString(highestRole, List.of(ACCOUNTS, PROJECTS));
//        List<String> privilegesAccLevel = null;
//        if (accountId != 0) {
//            String highestRoleAccLevel = userServiceImpl.getHighestRole(oid, accountId, null);
//            privilegesAccLevel = utils.getPrivilegesString(highestRoleAccLevel, List.of(ACCOUNTS, PROJECTS));
//        }
//        if (accountId == 0 && (privileges.contains(PROJECTS_VIEW_ALL) || highestRole.equalsIgnoreCase(SUPER_ADMIN_))) {
//            dedRolesList = dedRolesRepository.findAll();
//        }else if (accountId != 0 && highestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
//            dedRolesList = dedRolesRepository.findByAccount_Id(accountId);
//            projectsListDto.setPrivileges(List.of(FULL_ACCESS));
//        } else if (accountId == 0 && privileges.contains(PROJECTS_VIEW_ASSOCIATED)) {
//            dedRolesList = dedRolesRepository.findByOid(oid);
//        } else if ((accountId != 0) && privilegesAccLevel.contains(PROJECTS_VIEW_ALL)) {
//            projectsListDto.setPrivileges(utils.getPrivilegesString(userServiceImpl.getHighestRole(oid, accountId, null), List.of(PROJECTS)));
//            dedRolesList = dedRolesRepository.findByAccount_Id(accountId);
//        } else if ((accountId != 0) && privilegesAccLevel.contains(PROJECTS_VIEW_ASSOCIATED)) {
//            projectsListDto.setPrivileges(utils.getPrivilegesString(userServiceImpl.getHighestRole(oid, accountId, null), List.of(PROJECTS)));
//            dedRolesList = dedRolesRepository.findByOidAndAccount_Id(oid, accountId);
//        } else if ((accountId != 0) && privileges.contains(PROJECTS_VIEW_ALL)) {
//            dedRolesList = dedRolesRepository.findByAccount_Id(accountId);
//        }
//        else if ((accountId != 0) && privileges.contains(PROJECTS_VIEW_ASSOCIATED)) {
//            dedRolesList = dedRolesRepository.findByOidAndAccount_Id(oid, accountId);
//        }else {
//            return new ProjectsListDto(Collections.emptyList(), Collections.emptySet(), List.of(NO_ACCESS));
//        }
//        if (CollectionUtils.isEmpty(dedRolesList)) {
//            return projectsListDto;
//        }
//
//        Set<Long> projectIdSet = dedRolesList.stream().filter(dedRoles -> (dedRoles.getAccountId() != null && dedRoles.getProjectId() != null)).map(DedRolesmy::getProjectId).collect(Collectors.toSet());
//        projectsListDto.setProjectsList(projectIdSet);
//
//        if (accountId != null && accountId > 0) {
//            criteria.and(ACCOUNT_ID).is(accountId);
//        }
//            criteria.and(ID).in(projectIdSet);
//        if(!CollectionUtils.isEmpty(filter.getDeliveryManager()))
//        {
//            filter.getDeliveryManager().forEach(deliveryManager -> {
//                criteriaList.add(  Criteria.where(DED_ROLES).elemMatch(
//                        Criteria.where(O_ID).is(deliveryManager).and(ROLE).is(DM)));
//            });
//        }
//        if(!CollectionUtils.isEmpty(filter.getDeliveryPartner()))
//        {
//            filter.getDeliveryPartner().forEach(deliveryPartner -> {
//                criteriaList.add(  Criteria.where(DED_ROLES).elemMatch(
//                        Criteria.where(O_ID).is(deliveryPartner).and(ROLE).is(DP)));
//            });
//        }
//        if(!CollectionUtils.isEmpty(filter.getEngagementPartner()))
//        {
//            filter.getEngagementPartner().forEach(engagementPartner -> {
//                criteriaList.add(  Criteria.where(DED_ROLES).elemMatch(
//                        Criteria.where(O_ID).is(engagementPartner).and(ROLE).is(EP)));
//            });
//        }
//        if(!CollectionUtils.isEmpty(filter.getAccountPartner()))
//        {
//            filter.getAccountPartner().forEach(accountPartner -> {
//                criteriaList.add(  Criteria.where(DED_ROLES).elemMatch(
//                        Criteria.where(O_ID).is(accountPartner).and(ROLE).is(AP)));
//            });
//        }
//        if(StringUtils.isNotBlank(filter.getProjectName()))
//        {
//            criteriaList.add(Criteria.where(NAME).regex(filter.getProjectName(),"i"));
//        }
//        if(StringUtils.isNotBlank(filter.getStatus()))
//        {
//            criteriaList.add(Criteria.where(STATUS).in(filter.getStatus()));
//        }
//        if(StringUtils.isNotBlank(filter.getDeliveryImpactRange()))
//        {
//            switch (filter.getDeliveryImpactRange()){
//                case ALL_CHANGES ->{
//                    List<DeliveryImpact> deliveryImpacts=deliveryImpactRepository.findByProjectIdIn(projectIdSet);
//                    List<Long> projectIds=deliveryImpacts.stream().map(DeliveryImpact::getProjectId).toList();
//                    criteriaList.add(Criteria.where(ID).in(projectIds));
//                }
//                case NO_CHANGES->{
//                    List<DeliveryImpact> deliveryImpacts=deliveryImpactRepository.findByProjectIdIn(projectIdSet);
//                    List<Long> projectIds=deliveryImpacts.stream().map(DeliveryImpact::getProjectId).toList();
//                    criteriaList.add(Criteria.where(ID).nin(projectIds));
//                }
//                case LAST_30_DAYS, OLDER_30_DAYS->{
//                    DateRangeDto dateRangeDto = utils.getDateRange(filter.getDeliveryImpactRange());
//                    Long startDateMillis = dateRangeDto.getStartDate();
//                    Long endDateMillis = dateRangeDto.getEndDate();
//                    Criteria deliveryImpactCriteria = Criteria.where(PROJECT_ID).in(projectIdSet)
//                            .and(CHANGE_HISTORY_UPDATED_AT).gte(startDateMillis).lte(endDateMillis);
//                    Query deliveryImpactQuery = new Query(deliveryImpactCriteria);
//                    deliveryImpactQuery.fields().include(PROJECT_ID);
//                    List<DeliveryImpact> deliveryImpactsInRange = mongoTemplate.find(deliveryImpactQuery, DeliveryImpact.class);
//                    List<Long> filteredProjectIds = deliveryImpactsInRange.stream()
//                            .map(DeliveryImpact::getProjectId)
//                            .distinct()
//                            .toList();
//                    criteriaList.add(Criteria.where(ID).in(filteredProjectIds));
//                }
//            }
//        }
//        if(!criteriaList.isEmpty())
//        {
//            criteria.orOperator(criteriaList);
//        }
//        Query query = new Query(criteria);
//        if(StringUtils.isNotBlank(filter.getSortBy())){
//            utils.isValidField(Project.class,filter.getSortBy());
//            query.with(Sort.by(Sort.Direction.ASC, filter.getSortBy()));
//        }else {
//            query.with(Sort.by(Sort.Direction.DESC, CREATED_AT));
//        }
//        List<ProjectListResponseDto> projectList;
//        List<Project> projects = mongoTemplate.find(query, Project.class);
//        projectList = projects.stream().map(this::setProjectListResponseDetails).toList();
//        projectsListDto.setProjectListResponseDtos(projectList);
//        log.info("ProjectServiceImpl::getProjectFilterList:: call ended");
//        return projectsListDto;
    	return new ProjectsListDto();
    }

    @Override
    public List<BaseDto> fetchActiveProjects(Long accountId) {
//        log.debug("ProjectServiceImpl.fetchActiveProjects > start");
//        if(Objects.isNull(accountId) || accountId == 0)
//            return List.of();
//     List<Project> projectList = projectRepository.findByAccountIdAndStatus(accountId,ProjectStatus.Active.name());
//        log.debug("ProjectServiceImpl.fetchActiveProjects > end");
//        return projectList.stream().map(project ->
//                new BaseDto(project.getId(),project.getProjectName())
//        ).toList();
    	return new ArrayList<BaseDto>();
    }

    public ProjectListResponseDto setProjectListResponseDetails(Project projectDetails) {
        ProjectListResponseDto projectListDto = new ProjectListResponseDto();
        projectListDto.setId(projectDetails.getId());
        projectListDto.setName(projectDetails.getProjectName());
        projectListDto.setStatus(projectDetails.getStatus());
        projectListDto.setCustomerLOB(projectDetails.getCustomerLOB());
        projectListDto.setIsBillable(projectDetails.getIsBillable().equals(true)?YES:NO);
        projectListDto.setStartDate(projectDetails.getStartDate());
        projectListDto.setEndDate(projectDetails.getEndDate());

        for (DedRolesmy dedRolesDto : projectDetails.getDedRoles()) {
            if (dedRolesDto.getRole().equalsIgnoreCase(DM))
                projectListDto.setDeliveryManager(dedRolesDto.getName());
            else if (dedRolesDto.getRole().equalsIgnoreCase(DP))
                projectListDto.setDeliveryPartner(dedRolesDto.getName());
            else if (dedRolesDto.getRole().equalsIgnoreCase(EP))
                projectListDto.setEngagementPartner(dedRolesDto.getName());
            else if (dedRolesDto.getRole().equalsIgnoreCase(AP))
                projectListDto.setAccountPartner(dedRolesDto.getName());

        }
        return projectListDto;


    }

    private void validateBusinessSubVerticalAndFrequencyAndEngagementType(String subVertical,String frequency,
                                                                         String engagementType){
        List<BusinessSubvertical> businessVerticals =businessSubverticalRepository.findAll();
        if(businessVerticals.stream().noneMatch(businessSubvertical ->
                businessSubvertical.getName().trim().equals(subVertical.trim()))){
            throw new IllegalArgumentException("Provided business sub vertical is incorrect");
        }

        List<Frequency> frequencies =frequencyRepository.findAll();
        if(frequencies.stream().noneMatch(frequency1 ->
                frequency1.getName().trim().equals(frequency.trim()))){
            throw new IllegalArgumentException("Provided frequency is incorrect");
        }

        List<EngagementType> engagementTypes =engagementTypeRepository.findAll();
        if(engagementTypes.stream().noneMatch(engagementType1 ->
                engagementType1.getName().trim().equals(engagementType))){
            throw new IllegalArgumentException("Provided engagement type is incorrect");
        }

    }

    @Override
    public FilterRolesResponseDto getFilterMembers(UUID oid, Long accountId) {
        log.info("ProjectServiceImpl::getFilterMembers: {}", accountId);
        ProjectsListDto projectsListDto = getProjectDetailsList(oid, accountId, new ProjectFilterDto());

        log.info("Fetching Project list by accountId::{}", accountId);
        FilterRolesResponseDto filterRolesResponseDto = new FilterRolesResponseDto();

        Set<AccountRoles> deliveryManagers = new HashSet<>();
        Set<AccountRoles> deliveryPartners = new HashSet<>();
        Set<AccountRoles> accountPartners = new HashSet<>();
        Set<AccountRoles> engagementPartners = new HashSet<>();

        if(!CollectionUtils.isEmpty(projectsListDto.getProjectsList())) {
            List<DedRolesmy> dedRoles = dedRolesRepository.findByProject_IdIn(projectsListDto.getProjectsList());
            deliveryManagers.addAll(mapToProjectRolesOrList(dedRoles, DM));
            deliveryPartners.addAll(mapToProjectRolesOrList(dedRoles, DP));
            accountPartners.addAll(mapToProjectRolesOrList(dedRoles, AP));
            engagementPartners.addAll(mapToProjectRolesOrList(dedRoles, EP));
        }
        filterRolesResponseDto.setEngagementPartner(engagementPartners);
        filterRolesResponseDto.setAccountPartner(accountPartners);
        filterRolesResponseDto.setDeliveryManager(deliveryManagers);
        filterRolesResponseDto.setDeliveryPartner(deliveryPartners);
        log.info("ProjectServiceImpl::getFilterMembers::Ended");
        return filterRolesResponseDto;
    }

    private Set<AccountRoles> mapToProjectRolesOrList(List<DedRolesmy> dedRoles, String roleName) {
        Set<AccountRoles> accountRolesSet = new HashSet<>();
        for (DedRolesmy role : dedRoles) {
            if (roleName.equals(role.getRole())) {
                accountRolesSet.add(new AccountRoles(role.getOid(), role.getName()));
            }
        }
        return accountRolesSet;
    }

    @Override
    public List<BaseDto> fetchAllProjectNames (UUID userId, Long accountId, AssessmentRole assessmentRole){
//        log.info("ProjectServiceImpl::fetchAllProjectNames:: call started");
//        ProjectsListDto projectList;
//        //        if AssessmentRole is ALL need to send full accounts
//        if(AssessmentRole.ALL.equals(assessmentRole)){
//            List<Project> projects = projectRepository.findAll();
//            return projects.stream().map(project ->
//                    new BaseDto(project.getId(),project.getProjectName())
//            ).toList();
//        }else {
//            projectList = getProjectDetailsList(userId, accountId, new ProjectFilterDto());
//        }
//
//
//        if( Objects.nonNull( projectList) && !CollectionUtils.isEmpty(projectList.getProjectListResponseDtos()))
//            return projectList.getProjectListResponseDtos().stream().map(project ->
//                    new BaseDto(project.getId(),project.getName())
//            ).toList();
//        return Collections.emptyList();
    	
    	return new ArrayList<BaseDto>();
    }

    @Override
    public DeliveryImpactResponseDto createDeliveryImpact(UUID userId, Long projectId, DeliveryImpactDto deliveryImpactDto) {
//        log.info("ProjectServiceImpl::createDeliveryImpact:: started");
//        Long accountId=projectRepository.findById(projectId).get().getAccountId();
//        boolean roleExists=dedRolesRepository.existsByOidAndAccount_IdAndRole(userId,accountId,"DH");
//
//        String highestRole = userServiceImpl.getHighestRole(userId,accountId , projectId);
//        List<String> privileges = utils.getPrivilegesString(highestRole, List.of(DELIVERY_IMPACT));
//
//        if(highestRole.equalsIgnoreCase(SUPER_ADMIN_)||roleExists||privileges.contains(DELIVERY_IMPACT_EDIT)) {
//            Optional<Project> project = projectRepository.findById(projectId);
//            if (project.isEmpty()) {
//                log.error("ProjectServiceImpl::createDeliveryImpact::  Project id not found");
//                throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
//            }
//
//            Optional<DeliveryImpact> deliveryImpactOptional = deliveryImpactRepository.findByProjectId(projectId);
//            DeliveryImpact deliveryImpact;
//
//            ChangeHistory changeHistory = new ChangeHistory();
//            changeHistory.setUserId(userId);
//            changeHistory.setName(userServiceImpl.getDisplayName(userId));
//            changeHistory.setUpdatedAt(System.currentTimeMillis());
//
//            if (deliveryImpactOptional.isPresent()) {
//                deliveryImpact = deliveryImpactOptional.get();
//                deliveryImpact.setContent(deliveryImpactDto.getContent());
//                deliveryImpact.getChangeHistory().add(changeHistory);
//            } else {
//                deliveryImpact = new DeliveryImpact();
//                deliveryImpact.setProjectId(projectId);
//                deliveryImpact.setContent(deliveryImpactDto.getContent());
//                deliveryImpact.setChangeHistory(Collections.singletonList(changeHistory));
//            }
//            DeliveryImpact response = deliveryImpactRepository.save(deliveryImpact);
//            DeliveryImpactResponseDto responseDto = mapToDeliveryImpact(response);
//            log.info("ProjectServiceImpl::createDeliveryImpact:: ended");
//            return responseDto;
//        }
//        else{
//            throw new CustomException("Not authorized to edit delivery impact", HttpStatus.UNAUTHORIZED);
//        }
    	return new DeliveryImpactResponseDto();
    }

    @Override
    public DeliveryImpactResponseDto fetchDeliverImpact(Long projectId,UUID userId) {
        log.info("ProjectServiceImpl::fetchDeliverImpact:: started");
        Optional<DeliveryImpact> deliveryImpactOptional=deliveryImpactRepository.findByProjectId(projectId);

        if (deliveryImpactOptional.isEmpty()) {
            Optional<Template> template= templateRepository.findByType(TEMPLATE);
            DeliveryImpactResponseDto responseDto=new DeliveryImpactResponseDto();
           responseDto.setContent(template.orElse(new Template()).getContent());
           responseDto.setProjectId(projectId);
           return responseDto;
        }

        DeliveryImpactResponseDto deliveryImpact = mapToDeliveryImpact(deliveryImpactOptional.get());
        log.info("ProjectServiceImpl::fetchDeliverImpact:: ended");
        return deliveryImpact;
    }
    public DeliveryImpactResponseDto mapToDeliveryImpact(DeliveryImpact deliveryImpact){
        DeliveryImpactResponseDto deliveryImpactDto=new DeliveryImpactResponseDto();
        BeanUtils.copyProperties(deliveryImpact,deliveryImpactDto);
        return deliveryImpactDto;
    }
}
