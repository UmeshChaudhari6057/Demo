package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "project_role")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectRole extends IdentifiedEntity{
	@Column(nullable = false, unique = true)
	private String name;

    public ProjectRole(long l, String projectRole1) {
        super();
    }
}
