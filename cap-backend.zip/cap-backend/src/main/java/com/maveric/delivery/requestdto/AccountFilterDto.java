package com.maveric.delivery.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountFilterDto {
    private List<Long> accountIds;
    private List<UUID> deliveryHeads;
    private List<UUID> accountPartners;
    private List<UUID> engagementPartners;
    private List<UUID> deliveryPartners;
    private String status;
    private String sortBy;

}
