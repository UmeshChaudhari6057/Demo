package com.maveric.delivery.migration;

import java.io.IOException;
import java.util.List;

//import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.maveric.delivery.Entity.Country;
import com.maveric.delivery.Entity.EngagementType;
import com.maveric.delivery.mysqlrepository.EngagementTypemysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

//@ChangeUnit(id = "EngagementType", order = "001", author = "delivery-excellence", systemVersion = "1")
@Service
@Slf4j
@AllArgsConstructor
public class EngagementTypeMigration implements Migration{

   // private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/engagement-type.json";
    private final EngagementTypemysqlRepository engagementTypemysqlRepository;

    
    @Override
    public void before() {
        log.info("EngagementType Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
  //  @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("EngagementType Migration RollbackBeforeExecution");
    }

    @Transactional
    @Override
    public void migrationMethod() throws IOException {
        log.info("EngagementType migrationMethod");
//        List<EngagementType> engagementTypes= jsonFileReader.readJsonFileToList(filePath, EngagementType.class);
//        mongoTemplate.insertAll(engagementTypes);
        
        
        try {
            List<EngagementType> engagementTypes = jsonFileReader.readJsonFileToList(filePath, EngagementType.class);

            if (!engagementTypes.isEmpty()) {
            	engagementTypemysqlRepository.saveAll(engagementTypes);
                log.info("Migration completed: {} records inserted", engagementTypes.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
        
    }
    

  //  @RollbackExecution
    @Override
    public void rollback() {
        log.info("EngagementType Migration RollbackBeforeExecution");
        engagementTypemysqlRepository.deleteAll();
    }

}
