package com.maveric.delivery.requestdto;

import com.maveric.delivery.Entity.Privileges;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrivilegesDto {

    private String name;
    private String value;
    private String description;
    private List<PrivilegesDto> privileges;
    private boolean isEnabled;

}
