package com.maveric.delivery.responsedto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class AssessmentSubmissionDto {

    private String accountName;
    @JsonIgnore
    private Long accountId;
    private Long total;
    private Long reviewed;
    private double percentage;
}
