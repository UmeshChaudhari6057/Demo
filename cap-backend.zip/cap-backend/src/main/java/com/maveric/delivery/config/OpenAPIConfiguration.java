package com.maveric.delivery.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "${maveric.de-dashboard.api-docs.title}",
                description = "${maveric.de-dashboard.api-docs.description}",
                version = "${maveric.de-dashboard.api-docs.version}",
                contact = @io.swagger.v3.oas.annotations.info.Contact(
                        name = "${maveric.de-dashboard.api-docs.contact.name}",
                        email = "${maveric.de-dashboard.api-docs.contact.email}",
                        url = "${maveric.de-dashboard.api-docs.contact.url}"
                )

        ),
        security = { @SecurityRequirement(name = "Bearer")}
)
@SecurityScheme(
        name = "Bearer",
        type = SecuritySchemeType.HTTP,
        bearerFormat = "JWT",
        scheme = "bearer",
        description = "Azure Access Token"

)
@ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "OK"),
        @ApiResponse(responseCode = "400", description = "Bad Request"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "403", description = "Forbidden"),
        @ApiResponse(responseCode = "404", description = "Not Found"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
})
public class OpenAPIConfiguration {

}
