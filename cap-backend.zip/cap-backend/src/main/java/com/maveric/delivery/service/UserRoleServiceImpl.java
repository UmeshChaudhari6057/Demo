package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.ACCOUNT_ADMIN_;
import static com.maveric.delivery.utils.Constants.ORGANIZATION_LEADER;
import static com.maveric.delivery.utils.Constants.ORGANIZATION_LEADER_;
import static com.maveric.delivery.utils.Constants.STATUS;
import static com.maveric.delivery.utils.Constants.SUPER_ADMIN;
import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBER;
import static com.maveric.delivery.utils.Constants.TM;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.maveric.delivery.exception.ActiveAccountFoundException;
import com.maveric.delivery.exception.NoOtherUserMappedWithSuperAdminException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.exception.UserRoleException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.Roles;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.model.embedded.UserRoleDto;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.mysqlrepository.RolesmysqlRepository;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.responsedto.AdditionalRoleDto;
import com.maveric.delivery.responsedto.AssignUserRoleResponseDto;
import com.maveric.delivery.responsedto.UserRoleListResponseDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserRoleServiceImpl implements UserRoleService {

 //   private final ProjectRepository projectRepository;

 //   private final AccountRepository accountRepository;

    private final AzureUsermysqlRepository azureUserRepository;

    private final UserServiceImpl userService;

    private final RolesmysqlRepository rolesRepository;

    private final DedRolesRepository dedRolesRepository;

    @Override
    public AssignUserRoleResponseDto assignUserRole(UserRoleDto userRoleDto) {
        log.info("UserRoleServiceImpl::assignUserRole:: call started");
        List<DedRolesmy> savedDedRoles = new ArrayList<>();
        List<ErrorMessage> usersWithRoleAlreadyAssigned = new ArrayList<>();
        String roleGroup = getGroupByRoleName(userRoleDto.getRole());
        for (UserDto userDto : userRoleDto.getUsers()) {
            log.info("UserRoleServiceImpl::assignUserRole:: Processing user: {}", userDto.getName());
            Optional<AzureUsers> userOptional = azureUserRepository.findById(userDto.getOid());
            if (userOptional.isPresent()) {
                AzureUsers user = userOptional.get();
                List<String> specifiedRoles = Arrays.asList(SUPER_ADMIN_, ORGANIZATION_LEADER_, ACCOUNT_ADMIN_);
                List<String> mappedRoles = specifiedRoles.stream()
                        .map(this::getGroupByRoleName).toList();
                List<DedRolesmy> dedRoles = dedRolesRepository.findByOidAndRoleInAndAccount_IdIsNullAndProject_IdIsNull(user.getId(), mappedRoles);
                if (!CollectionUtils.isEmpty(dedRoles)) {
                    String roles = dedRoles.stream().map(dedRoles1 ->getRoleByGroup(dedRoles1.getRole())).collect(Collectors.joining(","));
                    String message = "User '" + userDto.getName() + "' already has the role '" + roles + "' assigned.";
                    log.info("UserRoleServiceImpl::assignUserRole:: {}", message);
                    usersWithRoleAlreadyAssigned.add(new ErrorMessage(STATUS,message));
                } else {
                    log.info("UserRoleServiceImpl::assignUserRole:: User does not have a role assigned with an account ID. Assigning new role.");
                    DedRolesmy newDedRole = convertToDedRoles(userDto);
                    newDedRole.setRole(roleGroup);
                    savedDedRoles.add(dedRolesRepository.save(newDedRole));
                }
            } else {
                log.info("UserRoleServiceImpl::assignUserRole:: User '{}' not found.", userDto.getName());
                throw new UserNotFoundException("User '" + userDto.getName() + "' not found.");
            }
        }
        return new AssignUserRoleResponseDto(savedDedRoles, usersWithRoleAlreadyAssigned);
    }

    public List<UserRoleListResponseDto> getAllUserRoleList() {
        log.info("UserRoleServiceImpl::getAllUserRoleList::Fetching all user roles...");
        List<DedRolesmy> userRoleslist = dedRolesRepository.findByAccount_IdIsNullAndProject_IdIsNull();
        List<UserRoleListResponseDto> userRoleListResponseDtos = new ArrayList<>();
        Set<UUID> distinctUser = new HashSet<>();
            for (DedRolesmy user : userRoleslist) {
                if (!distinctUser.contains(user.getOid())) {
                    distinctUser.add(user.getOid());
                    UserRoleListResponseDto userDto = new UserRoleListResponseDto();
                    List<AdditionalRoleDto> additionalRoles = getAdditionalRolesForUser(user.getOid());
                    userDto.setId(user.getId());
                    userDto.setUser(user.getName());
                    userDto.setRole(getRoleByGroup(user.getRole()));
                    userDto.setAdditionalRoles(additionalRoles);
                    userRoleListResponseDtos.add(userDto);
                }
            }
            log.info("UserRoleServiceImpl::getAllUserRoleList::All user roles fetched successfully.");
            return userRoleListResponseDtos;

    }

    private List<AdditionalRoleDto> getAdditionalRolesForUser(UUID oid) {
    	// // Commented out MongoDB code

//        log.info("UserRoleServiceImpl::getAdditionalRolesForUser::Fetching additional roles for user with OID {}...", oid);
//        List<DedRolesmy> additionalRoles = dedRolesRepository.findByOidAndAccount_IdIsNotNull(oid);
//        List<AdditionalRoleDto> additionalRoleDtos = new ArrayList<>();
//        for (DedRolesmy roles : additionalRoles) {
//            AdditionalRoleDto additionalRoleDto = new AdditionalRoleDto();
//            if (roles.getAccountId() != null) {
//                Optional<Account> account = accountRepository.findById(roles.getAccountId());
//                additionalRoleDto.setAccount(account.map(Account::getAccountName).orElse(null));
//            }
//            if (roles.getProjectId() != null) {
//                Optional<Project> project = projectRepository.findById(roles.getProjectId());
//                additionalRoleDto.setProject(project.map(Project::getProjectName).orElse(null));
//            }
//            additionalRoleDto.setGroup(roles.getRole().replace(TEAM_MEMBER,TM));
//            additionalRoleDto.setRole(getRoleByGroup(roles.getRole()));
//            additionalRoleDtos.add(additionalRoleDto);
//        }
//        log.info("UserRoleServiceImpl::getAdditionalRolesForUser::Additional roles fetched successfully for user with OID {}.", oid);
//        return additionalRoleDtos;
    	return new ArrayList<AdditionalRoleDto>();
    }

    public String updateUserRole(Long id, String role) {
        log.info("UserRoleServiceImpl::updateUserRole::updating role for user with ID {}...", id);
        Optional<DedRolesmy> dedRole = dedRolesRepository.findById(id);
        if (dedRole.isPresent()) {
            UUID oid = dedRole.get().getOid();
            List<DedRolesmy> dedRolesList = dedRolesRepository.findByOid(oid);
            if (dedRolesList.stream().anyMatch(dedRoles -> dedRoles.getAccountId() != null || dedRoles.getProjectId() != null)) {
                throw new UserRoleException("User has additional roles at Account/Project. The role cannot be updated");
            }
            if (role.equals(SUPER_ADMIN_)) {
                List<DedRolesmy> dedRolesWithSuperAdmin = dedRolesRepository.findByRoleInAndAccount_IdIsNullAndProject_IdIsNull(Collections.singletonList("SUPER_ADMIN"));
                if (dedRolesWithSuperAdmin != null && dedRolesWithSuperAdmin.size() == 1) {
                    throw new NoOtherUserMappedWithSuperAdminException("No any other user mapped with super admin.");
                }
            }
            String mappedRole = getGroupByRoleName(role);
            DedRolesmy newDedRoles = dedRole.get();
            newDedRoles.setRole(mappedRole);
            dedRolesRepository.save(newDedRoles);
            return "Role updated successfully";
        } else {
            throw new UserRoleException("No user role found");
        }

    }

    public String deleteUserRole(Long id) {
        log.info("UserRoleServiceImpl::deleteUserRole::Deleting role for user with ID {}...", id);
        Optional<DedRolesmy> dedRole = dedRolesRepository.findById(id);
        if (dedRole.isPresent()) {
            UUID oid = dedRole.get().getOid();
            String role = dedRole.get().getRole();
            List<DedRolesmy> dedRolesList = dedRolesRepository.findByOid(oid);
            if (dedRolesList.stream().anyMatch(dedRoles -> dedRoles.getAccountId() != null || dedRoles.getProjectId() != null)) {
                throw new ActiveAccountFoundException("User has already mapped with another account. So we can't delete");
            }
            if (role.equals(SUPER_ADMIN_)) {                                                                                
                List<DedRolesmy> dedRolesWithSuperAdmin = dedRolesRepository.findByRoleInAndAccount_IdIsNullAndProject_IdIsNull(Collections.singletonList("SUPER_ADMIN"));
                if (dedRolesWithSuperAdmin != null && dedRolesWithSuperAdmin.size() == 1) {
                    throw new NoOtherUserMappedWithSuperAdminException("No any other user mapped with super admin. So we can't delete");
                }
            }
            dedRolesRepository.deleteById(id);
            return "Role deleted successfully";
        } else {
            throw new UserRoleException("No user role found");
        }

    }


    private String getGroupByRoleName(String role) {
        log.info("UserRoleServiceImpl::MapToRole:: Mapping role '{}' to group", role);
        Roles roles = rolesRepository.findByName(role);
        if (roles != null) {
            if (ORGANIZATION_LEADER_.equalsIgnoreCase(roles.getName())) {
                return roles.getGroup().stream()
                        .filter(ORGANIZATION_LEADER::equalsIgnoreCase)
                        .findAny()
                        .orElse(null);
            } else {
                return roles.getGroup().stream()
                        .findAny()
                        .orElse(null);
            }
        }
        return null;
    }


    private String getRoleByGroup(String role) {
        log.info("UserRoleServiceImpl::MapToRole:: Mapping role '{}' to group", role);
        Roles roles = rolesRepository.findByGroupContaining(role);
        return roles != null ? roles.getName() : null;
    }


    private DedRolesmy convertToDedRoles(UserDto userDto) {
        DedRolesmy dedRoles = new DedRolesmy();
        dedRoles.setOid(userDto.getOid());
        dedRoles.setName(userDto.getName());
        return dedRoles;
    }
}



