package com.maveric.delivery.mysqlrepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.maveric.delivery.Entity.Assessment;

public interface AssessmentmysqlRepository extends JpaRepository<Assessment, Long> {

	    List<Assessment> findByUserId(UUID userId);

	    @Query("SELECT a FROM Assessment a WHERE a.projectId IN :projectIds AND a.status IN ('SUBMITTED', 'REVIEWED')")
	    List<Assessment> findByProjectIdIn(List<Long> projectIds);

	    List<Assessment> findByReviewerId(UUID reviewerId);

	    Optional<Assessment> findByIdAndProjectId(Long assessmentId, Long projectId);
	    
	    Optional<Assessment> findByIdAndUserId(Long id, UUID userId);

	    List<Assessment> findByProjectId(Long id);

	    @Query("SELECT a FROM Assessment a WHERE a.projectId = :projectId AND a.reviewedOn IS NOT NULL ORDER BY a.reviewedOn DESC")
	    Assessment findFirstReviewedAssessmentByProjectId(Long projectId);
	    
	 //   Assessment findFirstByProjectIdAndReviewedOnIsNotNullOrderByReviewedOnDesc(Long projectId);

	    Optional<Assessment> findByIdAndReviewerId(Long id, UUID reviewerId);

}
