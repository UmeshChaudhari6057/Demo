package com.maveric.delivery.mysqlrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.AssessmentsSchedulerFailedLogs;
import com.maveric.delivery.model.embedded.ProjectStatus;

public interface AssessmentsSchedulerFailedLogsmysqlRepository extends JpaRepository<AssessmentsSchedulerFailedLogs, Long> {
    
    List<AssessmentsSchedulerFailedLogs> findByIsProcessedAndStatus(Boolean value, ProjectStatus status);

    List<AssessmentsSchedulerFailedLogs> findByProjectId(Long projectId);
}
