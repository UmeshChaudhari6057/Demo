package com.maveric.delivery.controller;

import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.PrivilegesService;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Privileges Management", description = "Endpoints for managing Privileges")
public class PrivilegesController {

    private final PrivilegesService privilegesService;

    private final ValidateApiAccess validateApiAccess;

    @Operation(summary = "This API is intended to retrieve roles.",description = "Api to Get All Roles")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles Retrieve Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/privileges")
    public ResponseEntity<ResponseDto<List<PrivilegesDetailsDto>>> get(HttpServletRequest servletRequest) {
        log.debug("PrivilegesController::get: start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ROLE_PERMISSIONS, VIEW_ALL);
        List<PrivilegesDetailsDto> response = privilegesService.getPrivileges();
        log.debug("PrivilegesController::get: end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.ROLES_FETCHED.getCode(), SuccessMessage.ROLES_FETCHED.getMessage(), null, response));
    }
}