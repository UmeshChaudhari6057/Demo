package com.maveric.delivery.service;

import java.util.List;
import java.util.UUID;

import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.requestdto.AccountFilterDto;
import com.maveric.delivery.requestdto.AccountListDto;
import com.maveric.delivery.requestdto.AccountRequestDto;
import com.maveric.delivery.requestdto.AccountSummaryCountDto;
import com.maveric.delivery.requestdto.AccountSummaryDto;
import com.maveric.delivery.responsedto.AccountMemberDto;
import com.maveric.delivery.responsedto.AccountNamesResponseDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.responsedto.BaseDto;

/**
 * @author ankushk
 */
public interface AccountService {
    AccountResponseDto createAccount(AccountRequestDto accountRequestDto,UUID oid);

    List<AccountSummaryDto> getAllAccounts(UUID userId,AccountFilterDto filter) throws Exception;

    AccountResponseDto getAccountById(Long accountId,UUID oid);


    AccountResponseDto editAccount(AccountRequestDto accountRequestDto,Long accountId,UUID oid);

    AccountSummaryCountDto getCountOfAccount(UUID userId) throws Exception;
    Boolean duplicateAccountName(String accountName);

    AccountMemberDto getAccountMembers(Long accountId);
    AccountNamesResponseDto getAccountsList(UUID oid)throws Exception;

    List<AccountListDto> getAccountsListResponse(UUID oid, AssessmentRole assessmentRole);

    List<BaseDto> fetchActiveAccounts();
    
    
}

