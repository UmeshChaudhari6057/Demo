package com.maveric.delivery.requestdto;

import com.maveric.delivery.responsedto.JobNotificationDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendEmailDetailsDto {
    private String userName;
    private String projectCode;
    private String projectName;
    private String projectType;
    private String accountName;
    private String submittedBy;
    private String submittedOn;
    private String status;
    private List<String> emailId;
    private String reviewedBy;
    private String reviewOn;
    private String reviewerEmail;
    private String dueDate;
    private String subject;
    private String templateName;
    private String message;
    private String emailType;
    private Map<String,List<JobNotificationDetails>> failureJobNotificationDetailsMap;

}
