package com.maveric.delivery.model.embedded;

import com.maveric.delivery.requestdto.UserDto;
import lombok.Data;

import java.util.List;

/**
 * @author ankushk
 */
@Data
public class UserRoleDto {
    List<UserDto> users;

    String role;
}
