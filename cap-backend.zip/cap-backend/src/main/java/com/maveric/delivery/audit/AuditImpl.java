package com.maveric.delivery.audit;

import com.maveric.delivery.Entity.Audit;
import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.mysqlrepository.AuditmysqlRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditImpl {

    private final AuditmysqlRepository auditRepository;
    private final AzureUsermysqlRepository azureUserRepository;
    public void log(Audit audit) {
        audit.setTimestamp(LocalDateTime.now());
        if(null != audit.getOid())
            audit.setUsername((azureUserRepository.findById(audit.getOid())).map(AzureUsers::getDisplayName).orElse(null));
        log.info("Audit logged");
        auditRepository.save(audit);
    }


}