package com.maveric.delivery.controller;

import com.maveric.delivery.requestdto.DashboardFilterDto;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.responsedto.*;
import com.maveric.delivery.service.AccountService;
import com.maveric.delivery.service.DashboardService;
import com.maveric.delivery.service.ProjectService;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Dashboard Management", description = "Endpoints for managing Dashboard")
public class DashboardController {

    private final DashboardService dashboardService;
    private final ValidateApiAccess validateApiAccess;
    private final AccountService accountService;
    private final ProjectService projectService;
    private final UtilMethods utilMethods;

    @Operation(summary = "The API is designed to retrieve dashboard details.",description = "Api to Get Dashboard details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Get Dashboard details Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/dashboard")
    public ResponseEntity<ResponseDto<DashboardDetailsDto>> fetchDashboardDetails(HttpServletRequest servletRequest, @RequestBody DashboardFilterDto dashboardFilterDto) throws Exception {
        log.info("DashboardController::fetchDashboardDetails Start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, DASHBOARD, VIEW);
        DashboardDetailsDto dashboardDetails = dashboardService.fetchDashboardDetails(dashboardFilterDto);
        log.info("DashboardController::fetchDashboardDetails end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_DASHBOARD_DETAILS.getCode(), SuccessMessage.FETCH_DASHBOARD_DETAILS.getMessage(), null, dashboardDetails));
    }

    @Operation(summary = "The API is designed to retrieve dashboard Trends details.",description = "Api to Get Dashboard Trends details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Get dashboard Trends details Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/dashboard/trends")
    public ResponseEntity<ResponseDto<AssessmentTrendsDetailsDto>> fetchDashboardTrendsDetails(HttpServletRequest servletRequest, @RequestBody DashboardFilterDto dashboardFilterDto) throws Exception {
        log.info("DashboardController::fetchDashboardTrendsDetails Start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, DASHBOARD, VIEW);
        AssessmentTrendsDetailsDto dashboardDetails = dashboardService.fetchDashboardTrendsDetails(dashboardFilterDto);
        log.info("DashboardController::fetchDashboardTrendsDetails end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_DASHBOARD_TRENDS_DETAILS.getCode(), SuccessMessage.FETCH_DASHBOARD_TRENDS_DETAILS.getMessage(), null, dashboardDetails));
    }

    @Operation(summary = "The API is designed to retrieve Top Assessment Submission/Score details.",description = "Api to retrieve Top Assessment Submission/Score details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Get Top Assessment Submission/Score details Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/dashboard/top-assessment")
    public ResponseEntity<ResponseDto<AssessmentDetailsDto>> fetchTopAssessment(HttpServletRequest servletRequest) throws Exception {
        log.info("DashboardController::fetchTopAssessment Start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, DASHBOARD, VIEW);
        AssessmentDetailsDto topAssessmentDetails = dashboardService.fetchTopAssessment();
        log.info("DashboardController::fetchTopAssessment end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_TOP_ASSESSMENT_DETAILS.getCode(), SuccessMessage.FETCH_TOP_ASSESSMENT_DETAILS.getMessage(), null, topAssessmentDetails));
    }

    @Operation(summary = "The API is designed to retrieve Active Accounts.",description = "Api to Get Action Accounts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve Active Accounts Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/dashboard/accounts")
    public ResponseEntity<ResponseDto<List<BaseDto>>> fetchActiveAccounts(HttpServletRequest servletRequest) throws Exception {
        log.info("DashboardController::fetchActiveAccounts Start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, DASHBOARD, VIEW);
        List<BaseDto> response = accountService.fetchActiveAccounts();
        log.info("DashboardController::fetchActiveAccounts end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ACTIVE_ACCOUNTS_DETAILS.getCode(), SuccessMessage.FETCH_ACTIVE_ACCOUNTS_DETAILS.getMessage(), null, response));
    }

    @Operation(summary = "The API is designed to retrieve Active Projects based on accounts details.",description = "Api to Get Active Projects based on accounts details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve Active Projects based on accounts details successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/dashboard/projects")
    public ResponseEntity<ResponseDto<List<BaseDto>>> fetchActiveProjects(HttpServletRequest servletRequest, @NonNull @RequestParam String accountId) throws Exception {
        log.info("DashboardController::fetchActiveProjects Start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, DASHBOARD, VIEW);
        List<BaseDto> response = projectService.fetchActiveProjects(utilMethods.stringToLong(accountId));
        log.info("DashboardController::fetchActiveProjects end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ACTIVE_PROJECTS_DETAILS.getCode(), SuccessMessage.FETCH_ACTIVE_PROJECTS_DETAILS.getMessage(), null, response));
    }
}
