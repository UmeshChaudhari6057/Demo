package com.maveric.delivery.utils;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class Constants {

    public static final String TEAM_MEMBER = "TEAM_MEMBER";
    public static final String DH = "DH";
    public static final String DP = "DP";
    public static final String DM = "DM";
    public static final String AP = "AP";
    public static final String EP = "EP";
    public static final String TM = "TM";
    public static final String ADM = "ADM";


    public static final String SUCCESS = "Success";
    public static final String FAILED = "Failed";
    public static final String DELIVERY_HEAD = "Delivery Head";
    public static final String ACCOUNT_PARTNER = "Account Partner";
    public static final String ENGAGEMENT_PARTNER = "Engagement Partner";
    public static final String DELIVERY_PARTNER = "Delivery Partner";

    public static final String DELIVERY_MANAGER = "Delivery Manager";
    public static final String ACTING_DELIVERY_MANAGER ="Acting Delivery Manager";
    public static final String FREQUENCY = "frequency";
    public static final String ENGAGEMENT_TYPE = "engagement-type";
    public static final String BUSINESS_SUB_VERTICAL = "business-subvertical";

    public static final String LOCATION = "Location";
    public static final String PROJECT_ROLE = "Project-Role";
    public static final String ARTIFACT_TYPE = "Artifact-Type";
    public static final String ACCOUNTS = "Accounts";
    public static final String PROJECTS = "Projects";
    public static final String FULL_ACCESS = "FULL_ACCESS";
    public static final String NO_ACCESS = "NO_ACCESS";
    public static final String ACCOUNTS_VIEW_ALL = "ACCOUNTS_VIEW_ALL";
    public static final String ACCOUNTS_VIEW_ASSOCIATED = "ACCOUNTS_VIEW_ASSOCIATED";
    public static final String ACCOUNTS_CREATE = "ACCOUNTS_CREATE";
    public static final String ACCOUNTS_EDIT = "ACCOUNTS_EDIT";
    public static final String ACCOUNTS_DELETE = "ACCOUNTS_DELETE";
    public static final String PROJECTS_VIEW_ALL = "PROJECTS_VIEW_ALL";
    public static final String PROJECTS_VIEW_ASSOCIATED = "PROJECTS_VIEW_ASSOCIATED";
    public static final String PROJECTS_CREATE = "PROJECTS_CREATE";
    public static final String PROJECTS_EDIT = "PROJECTS_EDIT";
    public static final String PROJECTS_DELETE = "PROJECTS_DELETE";
    public static final String ASSESSMENTS_VIEW_ALL = "ASSESSMENTS_VIEW_ALL";
    public static final String ASSESSMENTS_VIEW_ASSOCIATED = "ASSESSMENTS_VIEW_ASSOCIATED";
    public static final String DELIVERY_IMPACT_VIEW_ALL = "DELIVERY_IMPACT_VIEW_ALL";
    public static final String DELIVERY_IMPACT_EDIT = "DELIVERY_IMPACT_EDIT";
    public static final String DELIVERY_IMPACT_VIEW_ASSOCIATED = "DELIVERY_IMPACT_VIEW_ASSOCIATED";
    public static final String ASSESSMENTS_REVIEW = "ASSESSMENTS_REVIEW";
    public static final String TEAM_MEMBERS_VIEW_ASSOCIATED = "TEAM_MEMBERS_VIEW_ASSOCIATED";
    public static final String TEAM_MEMBERS_VIEW_ALL = "TEAM_MEMBERS_VIEW_ALL";
    public static final String TEAM_MEMBERS_EDIT = "TEAM_MEMBERS_EDIT";
    public static final String TEAM_MEMBERS_ADD = "TEAM_MEMBERS_ADD";
    public static final String DASHBOARD_VIEW = "DASHBOARD_VIEW";
    public static final String ARTIFACTS_VIEW_ALL = "ARTIFACTS_VIEW_ALL";
    public static final String ARTIFACTS_VIEW_ASSOCIATED = "ARTIFACTS_VIEW_ASSOCIATED";
    public static final String ARTIFACTS_CREATE = "ARTIFACTS_CREATE";
    public static final String ARTIFACTS_EDIT = "ARTIFACTS_EDIT";
    public static final String ARTIFACTS_DELETE = "ARTIFACTS_DELETE";


    public static final String YES = "Yes";
    public static final String NO = "No";


    public static final String SUPER_ADMIN_ = "Super Admin";
    public static final String SUPER_ADMIN = "SUPER_ADMIN";
    public static final String ACCOUNT_ADMIN_ = "Account Admin";
    public static final String PROJECT_ADMIN_ = "Project Admin";
    public static final String DELIVERY_OWNER_ = "Delivery Owner";
    public static final String ORGANIZATION_LEADER_ = "Organization Leader";
    public static final String TEAM_MEMBER_ = "Team Member";
    public static final String DELETE = "Delete";


    public static final String HIERARCHY = "hierarchy";

    public static final String ARTIFACTS = "Artifacts";
    public static final String TEAM_MEMBERS = "Team Members";
    public static final String ADD = "Add";

    public static final String ASSESSMENTS = "Assessments";
    public static final String DELIVERY_IMPACT = "Delivery Impact";
    public static final String USER_PROFILES = "User Profiles";
    public static final String DASHBOARD = "Dashboard";

    public static final String ROLE_PERMISSIONS = "Role Permissions";

    public static final String ASSESSMENT_TEMPLATES = "Assessment Templates";
    public static final String USER_ROLES = "User Roles";
    public static final String FULL_ACCESS_TO = "Full Access To";

    public static final String CREATE = "Create";
    public static final String EDIT = "Edit";
    public static final String VIEW_ALL = "View_All";
    public static final String VIEW = "View";

    public static final String VIEW_ASSOCIATED = "View_Associated";
    public static final String TRACE_ID_HEADER = "X-Trace-Id";
    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer ";
    public static final String T_ID = "tid";
    public static final String APP_ID = "aud";
    public static final String O_ID = "oid";
    public static final String SHOW_ACCOUNTS_TAB = "SHOW_ACCOUNTS_TAB";
    public static final String SHOW_PROJECTS_TAB = "SHOW_PROJECTS_TAB";
    public static final String SHOW_ASSESSMENTS_TAB = "SHOW_ASSESSMENTS_TAB";
    public static final String SHOW_REVIEW_ASSESSMENTS_TAB = "SHOW_REVIEW_ASSESSMENTS_TAB";
    public static final String SHOW_MY_ASSESSMENTS_TAB = "SHOW_MY_ASSESSMENTS_TAB";
    public static final String SHOW_ALL_ASSESSMENTS_TAB = "SHOW_ALL_ASSESSMENTS_TAB";
    public static final String SHOW_DASHBOARD_TAB = "SHOW_DASHBOARD_TAB";
    public static final String ALL = "ALL";



    //    Dashboard
    public static final String LAST_3_MONTHS = "LAST_3_MONTHS";
    public static final String LAST_6_MONTHS = "LAST_6_MONTHS";
    public static final String LAST_1_YEAR = "LAST_1_YEAR";
    public static final String LAST_2_YEAR = "LAST_2_YEAR";
    public static final String CURRENT_STATUS = "currentStatus";
    public static final String ACCOUNT_ID = "accountId";
    public static final String PROJECT_ID = "projectId";
    public static final String WEEK ="Week";
    public static final String REVIEWED_ON = "reviewedOn";
    public static final String SCORE ="Score";
    public static final String CREATE_DATE ="createDate";
    public static final String ASSESSMENT_ID ="assessmentId";
    public static final String SUBMITTED ="Submitted";
    public static final String REVIEWED ="Reviewed";
    public static final String OVERDUE ="Overdue";
    public static final String STATUS ="status";
    public static final String DATE_ON_BOARDED ="dateOnboarded";
    public static final String ID ="id";
    public static final String START_DATE ="startDate";
    public static final String DED_ROLES = "dedRoles";
    public static final String NAME = "projectName";
    public static final String ROLE="role";

    public static final String INITIATED_ON="initiatedOn";
    public static final String REVIEWER_ID="reviewerId";
    public static final String USER_ID="userId";
    public static final String  REVIEW = "Review";

    public static final String  SUBMIT = "Submit";
    public static final String ORGANIZATION_LEADER = "ORGANIZATION_LEADER";
    public static final String PARTIAL_SUCCESS = "Partial Success";
    public static final String PROJECT_ROLE_="projectRole";
    public static final String LOCATION_="location";
    public static final String SKILL_SET="skillSet";
    public static final String IS_BILLABLE="isBillable";
    public static final String ALLOCATION="allocation";
    public static final String TYPE="type";
    public static final String CREATED_AT="createdAt";

    public static final String NEW_ASSESSMENT ="<p> A new assessment for the below project is assigned to you.\n" +
            "Please complete it before it is overdue on ";
    public static final String NEW_ASSESSMENT_SUBJECT="DE Dashboard - New Assessment created for ";
    public static final String ASSESSMENT_OVERDUE_SUBJECT="DE Dashboard - Assessment is overdue for ";
    public static final String ASSESSMENT_OVERDUE= "<p style=\"color: red;\">The assessment for the below project is now overdue.\n" +
            "Please complete it before it expires on ";
    public static final String ASSESSMENT_EXPIRED_SUBJECT="DE Dashboard - Your Assessment submission is expired";
    public static final String ASSESSMENT_EXPIRED="<p style=\"color: red;\">Your assessment  submission is expired.</p>";
    public static final String ASSESSMENT_REMAINDER_SUBJECT="DE Dashboard - Reminder to submit Assessment";
    public static final String ASSESSMENT_REMAINDER="Your Assessment is In-Progress, submission is due in next ";
    public static final String ASSESSMENT_SUBMISSION_SUBJECT="DE Dashboard - Assessment submitted successfully";
    public static final String ASSESSMENT_SUBMISSION="Your assessment was  submitted successfully.";
    public static final String REVIEW_ASSESSMENT_SUBJECT="DE Dashboard - Assessment submitted for review";
    public static final String REVIEW_ASSESSMENT="Following submission is now available  for review.";
    public static final String REVIEWED_ASSESSMENT="Your assessment submission was reviewed.";
    public static final String REVIEWED_ASSESSMENT_SUBJECT="DE Dashboard - Your submission was reviewed";
    public static final String RETURNED_ASSESSMENT_SUBJECT="DE Dashboard - Your assessment returned for update";
    public static final String RETURNED_ASSESSMENT="Your assessment submission was returned by reviewer with comments. Kindly update and resubmit.";
    public static final String ASSESSMENT_OVERDUE_INPROGRESS_SUBJECT="DE Dashboard - Your assessment submission is Overdue-Inprogress";
    public static final String ASSESSMENT_OVERDUE_INPROGRESS="<p style=\"color: red;\"> Your assessment submission is Overdue-Inprogress. </p>";
    public static final String ASSESSMENT_REVIEWED_TEMPLATE="AssessmentReviewed.ftl";
    public static final String ASSESSMENT_SUBMISSION_REMAINDER_TEMPLATE="AssessmentSubmissionRemainder.ftl";
    public static final String REVIEW_ASSESSMENT_TEMPLATE="ReviewAssessment.ftl";
    public static final String SUBMITTED_ASSESSMENT_TEMPLATE="submitedAssessmentEmail.ftl";
    public static final String FAILED_ASSESSMENT_JOB_TEMPLATE="FailedAssessmentsJobNotificationTemplate.ftl";
    public static final String FAILURE_JOB_NOTIFICATION_SUBJECT="DE Dashboard - Reprocess Failed Assessment Creation Job";
    public static final String CREATE_ASSESSMENT_SUBJECT="DE Dashboard - Create Assessments Job Status";
    public static final String CREATE_ASSESSMENT="The create assessments job has been completed successfully for the day ";
    public static final String PROJECT_ENDED="The below project has been marked as inactive effective today.   \n" +
            "The project end date and status can be modified in the Delivery Excellence Dashboard using the Edit Project option.";
    public static final String TEMPLATE="DELIVERY_IMPACT";
    public static final String SELECT="Select";
    public static final String CRON_TRACE_ID ="cron-trace-id";
    public static final String TRACE_ID ="traceId";
    public static final String API="API";
    public static final String CRON_JOB="CRON_JOB";
    public static final String SYSTEM="SYSTEM";
    public static final String IN_PROGRESS="IN_PROGRESS";

    public static final String COMPLETED="COMPLETED";
    public static final String ABORTED ="ABORTED";
    public static final String FAILED_CAP = "FAILED";

    //Scheduler Jobs
    public static final String REFRESH_USERS_JOB ="REFRESH_USERS_JOB";
    public static final String CREATE_ASSESSMENTS_JOB="CREATE_ASSESSMENTS_JOB";
    public static final String REMAINDER_MAILS_JOB="REMAINDER_MAILS_JOB";
    public static final String FAILED_ASSESSMENTS_JOB="FAILED_ASSESSMENTS_JOB";
    public static final String PROJECT_END_DATE_CHECK_JOB="PROJECT_END_DATE_CHECK_JOB";
    public static final String SCHEDULER_JOB ="SCHEDULER_JOB";
    public static final String TAKE_ASSESSMENT ="TAKE_ASSESSMENT";

    public static final String LAST_30_DAYS = "LAST_30_DAYS";
    public static final String OLDER_30_DAYS = "OLDER_30_DAYS";
    public static final String ALL_CHANGES = "ALL_CHANGES";
    public static final String NO_CHANGES = "NO_CHANGES";
    public  static final String CHANGE_HISTORY_UPDATED_AT="changeHistory.updatedAt";



}
