package com.maveric.delivery.controller;


import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.UserRoleDto;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.responsedto.AssignUserRoleResponseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.responsedto.UserRoleListResponseDto;
import com.maveric.delivery.service.UserRoleServiceImpl;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1/users")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "User Role Management", description = "Endpoints for managing User Roles")
public class UserRoleController {

    private final UserRoleServiceImpl userRoleService;

    private final ValidateApiAccess validateApiAccess;


    @Operation(summary = "Assign Role",description = "Api to assign role to user")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "206", description = "Partial Success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping("/assign-role")
    public ResponseEntity<ResponseDto<List<DedRolesmy>>> assignUserRole(HttpServletRequest servletRequest, @RequestBody UserRoleDto userRoleDto) {
        log.info("UserRoleController::assignUserRole:: call started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, CREATE);
        AssignUserRoleResponseDto assignedRoles = userRoleService.assignUserRole(userRoleDto);
        if (!CollectionUtils.isEmpty(assignedRoles.getNewlyAssignedRoles()) && CollectionUtils.isEmpty(assignedRoles.getErrorMessage())) {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ResponseDto<>(SUCCESS, SuccessMessage.ROLES_ASSIGN_SUCCESSFULLY.getCode(), SuccessMessage.ROLES_ASSIGN_SUCCESSFULLY.getMessage(), null, assignedRoles.getNewlyAssignedRoles()));
        } else if (!CollectionUtils.isEmpty(assignedRoles.getNewlyAssignedRoles())) {
            return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
                    .body(new ResponseDto<>(PARTIAL_SUCCESS, SuccessMessage.ROLES_ASSIGN_PARTIALLY.getCode(), SuccessMessage.ROLES_ASSIGN_PARTIALLY.getMessage(), assignedRoles.getErrorMessage(), assignedRoles.getNewlyAssignedRoles()));
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseDto<>(FAILED, FailedMessage.ROLES_ASSIGN_FAILED.getCode(), FailedMessage.ROLES_ASSIGN_FAILED.getMessage(), assignedRoles.getErrorMessage(), null));
        }
    }

    @Operation(summary = "Fetch user role",description = "Api to Fetch user roles")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping("/assign-role")
    public ResponseEntity<ResponseDto<List<UserRoleListResponseDto> >> getAllUserRoles(HttpServletRequest servletRequest) {
        log.info("UserRoleController::getAllUserRoles:: call started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, VIEW);
        List<UserRoleListResponseDto> userRolesDto = userRoleService.getAllUserRoleList();
        if (userRolesDto != null) {
            log.info("User roles fetched successfully");
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_USER_ROLES.getCode(), SuccessMessage.FETCH_USER_ROLES.getMessage(), null, userRolesDto));

        } else {
            log.error("Failed to fetch user roles");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseDto<>(FAILED, FailedMessage.FETCH_USER_ROLES_FAILED.getCode(), FailedMessage.FETCH_USER_ROLES_FAILED.getMessage(), null, null));
        }
    }

    @Operation(summary = "Update user role",description = "Api to Update user role")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping("/assign-role/{id}")
    public ResponseEntity<ResponseDto<String>> updateUserRole(HttpServletRequest servletRequest,@PathVariable long id, @RequestParam String role) {
        log.info("UserRoleController::updateUserRole:: call started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, EDIT);
        String userRole = userRoleService.updateUserRole(id, role);
        if (userRole != null) {
            log.info("User role is updated successfully");
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(SUCCESS, SuccessMessage.UPDATE_USER_ROLES.getCode(), SuccessMessage.UPDATE_USER_ROLES.getMessage(), null, userRole));

        } else {
            log.error("Failed to update user role");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseDto<>(FAILED, FailedMessage.UPDATE_USER_ROLES_FAILED.getCode(), FailedMessage.UPDATE_USER_ROLES_FAILED.getMessage(), null, null));
        }
    }

    @Operation(summary = "Remove user role",description = "Api to Remove user role")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @DeleteMapping("/assign-role/{id}")
    public ResponseEntity<ResponseDto<String>> deleteUserRole(HttpServletRequest servletRequest,@PathVariable long id) {
        log.info("UserRoleController::deleteUserRole:: call started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, DELETE);
        String userRole = userRoleService.deleteUserRole(id);
        if (userRole != null) {
            log.info("User role is deleted successfully");
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(SUCCESS, SuccessMessage.DELETE_USER_ROLES.getCode(), SuccessMessage.DELETE_USER_ROLES.getMessage(), null, userRole));

        } else {
            log.error("Failed to delete user role:");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseDto<>(FAILED, FailedMessage.DELETE_USER_ROLES.getCode(), FailedMessage.DELETE_USER_ROLES.getMessage(), null, null));
        }
    }

}
