package com.maveric.delivery.responsedto;

import lombok.Data;

import java.util.List;

@Data
public class AssessmentDetailsDto {
    private List<AssessmentSubmissionDto> submission;
    private List<AssessmentScoreDto> score;
}
