package com.maveric.delivery.responsedto;

import lombok.Data;

@Data
public class DashboardDetailsDto {

    private Long accounts;
    private Long projects;
    private Long projectTypes;
    private Long pending;
    private Long submitted;
    private Long inProgress;
    private Long overdue;
    private Long reviewed;
    private Long expired;
    private Long totalAssessment;
    private Long totalSubmitted;
    private Long totalReviewed;

}
