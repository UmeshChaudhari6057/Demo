package com.maveric.delivery.model.embedded;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Question {

    private int number;
    @NotBlank(message = "Question text is required")
    private String questionText;
    private String subHeading;
    private boolean attachmentRequired;
    private String fileName;
    private String documentId;
    private boolean comments;
    private String commentText;
    private QuestionType type;
    private CheckBoxOptions checkBoxOptions;
    private RadioOptions radioOptions;
    private Numerical numerical;
    private Slider slider;
    private String reviewerComment;
    @JsonProperty("isNotApplicable")
    private boolean isNotApplicable;
    @JsonProperty("isNotApplicableUserResponse")
    private boolean isNotApplicableUserResponse;
    private Double questionLevelScore;
    private Integer weightage;
}
