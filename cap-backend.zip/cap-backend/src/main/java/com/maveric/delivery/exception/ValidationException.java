package com.maveric.delivery.exception;

import com.maveric.delivery.model.embedded.ErrorMessage;
import lombok.Data;

import java.util.List;

@Data
public class ValidationException extends RuntimeException {
    private final List<ErrorMessage> errorMessages;
    private final String message;
    public ValidationException(String message,List<ErrorMessage> errorMessages) {
        this.message = message;
        this.errorMessages = errorMessages;

    }
}
