package com.maveric.delivery.service;

import com.maveric.delivery.Entity.DeliveryImpact;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.requestdto.DeliveryImpactDto;
import com.maveric.delivery.requestdto.ProjectFilterDto;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.DeliveryImpactResponseDto;
import com.maveric.delivery.responsedto.FilterRolesResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;

import java.util.List;
import java.util.UUID;

public interface ProjectService {
  ProjectResponseDto saveProject(ProjectRequestDto projectDto,UUID oid);
  ProjectResponseDto editProject(ProjectRequestDto projectDto,Long projectId,UUID oid);
  ProjectResponseDto getProjectById(Long projectId,UUID oid);
  boolean validateProjectName(Long accountId,String value);

  ProjectsListDto getProjectDetailsList(UUID oid, Long accountId, ProjectFilterDto projectFilterDto);

  List<BaseDto> fetchActiveProjects(Long accountId);

  FilterRolesResponseDto getFilterMembers(UUID oid, Long accountId);

  List<BaseDto> fetchAllProjectNames (UUID userId, Long accountId, AssessmentRole assessmentRole);

  DeliveryImpactResponseDto createDeliveryImpact(UUID userId, Long projectId, DeliveryImpactDto deliveryImpactDto);
  DeliveryImpactResponseDto fetchDeliverImpact( Long projectId,UUID userId);
}
