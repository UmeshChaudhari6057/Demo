package com.maveric.delivery.exception;

public class ProjectStatusException extends RuntimeException {

    public ProjectStatusException(String message) {
        super(message);
    }
}
