package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.mysqlrepository.PrivilegesmysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "privileges-v.0.2", order = "001", author = "delivery-excellence", systemVersion = "1")
@Service
@Slf4j
@AllArgsConstructor
public class PrivilegesMigration implements Migration {

  //  private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/privileges.json";

    private final PrivilegesmysqlRepository privilegesmysqlRepository;

   
    @Override
    public void before() {
        log.info("Privileges Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("Privileges Migration RollbackBeforeExecution");
    }

    @Transactional
    @Override
    public void migrationMethod() throws IOException {
        log.info("Privileges migrationMethod");
        
//        mongoTemplate.remove(new Query(), Privileges.class);
//        List<Privileges> roles= jsonFileReader.readJsonFileToList(filePath, Privileges.class);
//            mongoTemplate.insertAll(roles);
            
            privilegesmysqlRepository.deleteAll();
        
            log.info("All existing privileges deleted.");

           
            List<Privileges> roles = jsonFileReader.readJsonFileToList(filePath, Privileges.class);
            log.info("Loaded {} privilege records from JSON file.", roles.size());

           
            privilegesmysqlRepository.saveAll(roles);
            log.info("Privileges migration completed successfully.");
              
            
    }

    
    @Override
    public void rollback() {
        log.info("Privileges Migration RollbackBeforeExecution");
        privilegesmysqlRepository.deleteAll();
        
}
}
