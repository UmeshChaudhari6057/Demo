package com.maveric.delivery.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "business_subvertical")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusinessSubvertical extends IdentifiedEntity {

    @Column(name = "name", nullable = false)
    private String name;

    public BusinessSubvertical(Long id, String name) {
        super();
        this.setId(id); // Ensuring the ID is set from IdentifiedEntity
        this.name = name;
    }
}