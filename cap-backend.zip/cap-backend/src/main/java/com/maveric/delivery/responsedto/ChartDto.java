package com.maveric.delivery.responsedto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ChartDto {

    @JsonProperty("xAxisLabel")
    List<String> xAxisLabel;

    @JsonProperty("xAxisValues")
    List<ChartXAxisDataDto> xAxisValues;

    String average;
}
