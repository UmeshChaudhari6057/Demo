package com.maveric.delivery.responsedto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.InputStream;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttachmentDownloadDto {
    private String name;
    private String type;
    private InputStream downloadedInputStream;
}
