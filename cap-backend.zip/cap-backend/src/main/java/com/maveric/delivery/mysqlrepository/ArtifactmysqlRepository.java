package com.maveric.delivery.mysqlrepository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.Artifact;

public interface ArtifactmysqlRepository extends JpaRepository<Artifact, Long> {
    
    List<Artifact> findByProjectId(Long projectId);

    List<Artifact> findByProjectIdIn(List<Long> projectIds);  // Renamed parameter for clarity

    List<Artifact> findByIdAndCreatedBy(Long artifactId, UUID userId);
}