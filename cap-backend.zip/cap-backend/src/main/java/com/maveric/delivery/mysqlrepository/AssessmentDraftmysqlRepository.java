package com.maveric.delivery.mysqlrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.AssessmentDraft;


public interface AssessmentDraftmysqlRepository  extends JpaRepository<AssessmentDraft, Long> {

    Optional<AssessmentDraft> findByAssessmentId(Long assessmentId);
    
}
