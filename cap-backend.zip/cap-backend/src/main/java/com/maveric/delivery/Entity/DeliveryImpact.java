package com.maveric.delivery.Entity;

import java.util.List;

import com.maveric.delivery.model.embedded.ChangeHistory;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "delivery_impact")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DeliveryImpact extends IdentifiedEntity {

    @Column(nullable = false)
    private Long projectId;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    // Mapping ChangeHistory as a separate entity
    @ElementCollection
    @CollectionTable(name = "change_history", joinColumns = @JoinColumn(name = "delivery_impact_id"))
    private List<ChangeHistory> changeHistory;
}
