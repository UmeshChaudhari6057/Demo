package com.maveric.delivery.repository;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.maveric.delivery.model.embedded.DedRolesmy;

@Repository
public interface DedRolesRepository extends JpaRepository<DedRolesmy,Long> {
//    List<DedRolesmy> findByOidAndProjectIdAndAccountId(UUID oid, Long projectId, Long accountId);
//    List<DedRolesmy> findByOid(UUID oid);
//    List<DedRolesmy> findByOidAndAccountId(UUID oid, Long accountId);
//    List<DedRolesmy> findByAccountId(Long accountId);
//    List<DedRolesmy> findByOidAndProjectId(UUID oid, Long projectId);
//    List<DedRolesmy> findByAccountIdAndProjectIdIsNull(Long accountId);
//    List<DedRolesmy> findByAccountIdAndProjectIdIsNotNull(Long accountId);
//
//    List<DedRolesmy> findByAccountIdAndRoleAndProjectIdIsNull(Long accountId, String role);
//    void deleteByAccountIdAndProjectId(Long accountId,Long projectId);
//    void deleteByAccountIdAndProjectIdIsNull(Long accountId);
//    void deleteByOidAndProjectIdAndRole(UUID oid,Long projectId,String role);
//
//    List<DedRolesmy> findByOidInAndAccountIdIsNullAndProjectIdIsNull(UUID oid);
//
//    Boolean existsByOidAndRole(UUID oid, String role);
//
//    boolean existsByOidAndAccountIdAndRole(UUID oid, Long accountId,String role);
//
//    List<DedRolesmy> findByAccountIdIn(List<Long> accountIds);
//    boolean existsByRole(String role);
//
//    boolean existsByOidAndRoleInAndAccountIdIsNullAndProjectIdIsNull(UUID oid, Collection<String> roles);
//
//    List<DedRolesmy> findByProjectIdIn(Set<Long> projectIds);
//    List<DedRolesmy> findByOidAndAccountIdIsNotNull(@Param("oid") UUID oid);
//
//    List<DedRolesmy>  findByAccountIdIsNullAndProjectIdIsNull();
//
//
//    List<DedRolesmy> findById(UUID oid);
//
//    List<DedRolesmy> findByRoleInAndAccountIdIsNullAndProjectIdIsNull(String superAdmin);
//
//    List<DedRolesmy> findByOidAndRoleInAndAccountIdIsNullAndProjectIdIsNull(UUID oid, Collection<String> roles);
//    
//    
    
	  // Find methods
    List<DedRolesmy> findByOidAndProject_IdAndAccount_Id(UUID oid, Long projectId, Long accountId);
    List<DedRolesmy> findByOid(UUID oid);
    List<DedRolesmy> findByOidAndAccount_Id(UUID oid, Long accountId);
    List<DedRolesmy> findByAccount_Id(Long accountId);
    List<DedRolesmy> findByOidAndProject_Id(UUID oid, Long projectId);
    List<DedRolesmy> findByAccount_IdAndProject_IdIsNull(Long accountId);
    List<DedRolesmy> findByAccount_IdAndProject_IdIsNotNull(Long accountId);
    List<DedRolesmy> findByAccount_IdAndRoleAndProject_IdIsNull(Long accountId, String role);
    List<DedRolesmy> findByOidInAndAccount_IdIsNullAndProject_IdIsNull(Collection<UUID> oids);
    List<DedRolesmy> findByAccount_IdIn(List<Long> accountIds);
    List<DedRolesmy> findByProject_IdIn(Set<Long> projectIds);
    List<DedRolesmy> findByOidAndAccount_IdIsNotNull(UUID oid);
    List<DedRolesmy> findByAccount_IdIsNullAndProject_IdIsNull();
    List<DedRolesmy> findByOidAndRoleInAndAccount_IdIsNullAndProject_IdIsNull(UUID oid, Collection<String> roles);
    List<DedRolesmy> findByRoleInAndAccount_IdIsNullAndProject_IdIsNull(Collection<String> roles);
    

    // Exists methods
    boolean existsByOidAndRole(UUID oid, String role);
    boolean existsByOidAndAccount_IdAndRole(UUID oid, Long accountId, String role);
    boolean existsByRole(String role);
    boolean existsByOidAndRoleInAndAccount_IdIsNullAndProject_IdIsNull(UUID oid, Collection<String> roles);

    // Delete methods
    void deleteByAccount_IdAndProject_Id(Long accountId, Long projectId);
    
    @Modifying
    @Query("DELETE FROM DedRolesmy d WHERE d.account.id = :accountId AND d.project IS NULL")
    void deleteByAccount_IdAndProject_IdIsNull(@Param("accountId") Long accountId);

    void deleteByOidAndProject_IdAndRole(UUID oid, Long projectId, String role);
    
}
