package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReviewAssessmentRequestDto {
    private AssessmentCategoryType categoryType;
    @JsonProperty("isSubmitted")
    private boolean isSubmitted;
    @JsonProperty("isReassigned")
    private boolean isReassigned;
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- \n]+$", message = "Reason fo re-assign can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    @Size(min = 3,max = 500, message = "Reason for re-assign must be between 3 and 500 characters")
    private String reasonForReassign;
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- \n]+$", message = "Overall comment can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    @Size(min = 3,max = 500, message = "Overall comment must be between 3 and 500 characters")
    private String overallComment;
    @Valid
    private List<ReviewComments> reviewComments;

    private void  setReasonForReassign(String reasonForReassign){
        if(!this.isReassigned){
            this.reasonForReassign = null;
        }else{
            this.reasonForReassign =reasonForReassign;
        }
    }
}
