package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "frequency")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Frequency extends IdentifiedEntity {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private int days;
    
    public Frequency(Long id, String name, int days) {
        super(id); // Assuming IdentifiedEntity has a field `id`
        this.name = name;
        this.days=days;
    }
}
