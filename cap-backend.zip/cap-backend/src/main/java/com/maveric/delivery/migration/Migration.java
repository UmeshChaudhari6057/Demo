package com.maveric.delivery.migration;

public interface Migration {

    void before();
    void rollbackBefore();
    void migrationMethod() throws Exception;
    void rollback();
}
