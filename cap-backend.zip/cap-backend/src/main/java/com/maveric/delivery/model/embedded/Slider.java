package com.maveric.delivery.model.embedded;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Slider {

    private Integer min;
    private Integer max;
    private Integer increment;
    @Column(name = "slider_value")
    private Double value;
    @ElementCollection
    private List<Range> range;
}
