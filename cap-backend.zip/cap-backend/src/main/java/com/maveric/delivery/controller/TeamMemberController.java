package com.maveric.delivery.controller;

import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.TeamMember;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.requestdto.TeamMemberFilterDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;
import com.maveric.delivery.service.TeamMemberService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;
import static com.maveric.delivery.utils.Constants.CREATE;


@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Team Member Management", description = "Endpoints for managing Team Members")
public class TeamMemberController {

    private final TeamMemberService teamMemberService;
    private final ValidateApiAccess validateApiAccess;
    private final UtilMethods utilMethods;
    @Operation(summary = "Save Team Member",description = "Api to Save Team Member")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Saved team member successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/teamMembers")
    public ResponseEntity<ResponseDto<TeamMemberResponseDto>> saveTeamMember(@Valid @RequestBody TeamMemberDto teamMemberDto, HttpServletRequest servletRequest,@RequestParam("projectId") String projectId) {
        log.info("TeamMemberController::Saving teamMember: {}", teamMemberDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, TEAM_MEMBERS,VIEW_ALL,VIEW_ASSOCIATED);
        TeamMemberResponseDto createdTeamMember = teamMemberService.saveTeamMember(teamMemberDto,rolesDto.getOid(),utilMethods.stringToLong(projectId));
        log.info("TeamMember saved successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.TEAM_MEMBER_CREATED.getCode(), SuccessMessage.TEAM_MEMBER_CREATED.getMessage(), null, createdTeamMember));
    }

    @Operation(summary = "Fetch All Team Members",description = "Api to Get all Team Members")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch team members Successfully"),
            @ApiResponse(responseCode = "404", description = "Team Members not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/teamMembers")
    public ResponseEntity<ResponseDto<List<TeamMemberResponseListDto>>> fetchAllTeamMembers(@RequestParam("projectId") String projectId,HttpServletRequest servletRequest) {
        log.info("TeamMemberController::fetchAllTeamMembers() started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, TEAM_MEMBERS,VIEW_ALL,VIEW_ASSOCIATED);
        List<TeamMemberResponseListDto> teamMemberList=teamMemberService.getAllTeamMembers(rolesDto.getOid(),utilMethods.stringToLong(projectId), new TeamMemberFilterDto());
        log.info("TeamMemberController::fetchAllTeamMembers() ended");
        return ResponseEntity.ok(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.TEAM_MEMBER_LIST_FETCHED.getCode(), SuccessMessage.TEAM_MEMBER_LIST_FETCHED.getMessage(),null, teamMemberList));
    }
    @Operation(summary = "Get By Team Member Id",description = "Api to Get By Team Member Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Team Member found by ID"),
            @ApiResponse(responseCode = "404", description = "TeamMember not found for the given ID"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/teamMembers/{teamMemberId}")
    public ResponseEntity<ResponseDto<TeamMemberResponseListDto>> getTeamMemberById(HttpServletRequest servletRequest, @PathVariable String teamMemberId) {
        log.info("TeamMemberController::Fetching TeamMember by ID: {}", teamMemberId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, TEAM_MEMBERS,VIEW_ALL,VIEW_ASSOCIATED);
        TeamMemberResponseListDto teamMemberResponse = teamMemberService.getTeamMemberById(utilMethods.stringToLong(teamMemberId));
        log.info("TeamMemberController::getTeamMemberById::Ended");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_TEAM_MEMBER.getCode(),SuccessMessage.FETCH_TEAM_MEMBER.getMessage(), null, teamMemberResponse));

    }


    @Operation(summary = "Edit Team Member",description = "Api to Edit Team Member")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Team Member edited successfully"),
            @ApiResponse(responseCode = "404", description = "Team Member not found for the given ID"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(path = "/teamMembers/{teamMemberId}")
    public ResponseEntity<ResponseDto<TeamMemberResponseDto>> editTeamMember(HttpServletRequest servletRequest, @RequestBody @Valid TeamMemberDto teamMemberDto, @PathVariable String teamMemberId) {
        log.info("TeamMemberController::Editing teamMember with ID: {}, {}", teamMemberId, teamMemberDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, TEAM_MEMBERS,VIEW_ALL,VIEW_ASSOCIATED);
        TeamMemberResponseDto editTeamMember = teamMemberService.editTeamMember(teamMemberDto,rolesDto.getOid(),utilMethods.stringToLong(teamMemberId));
        log.info("teamMember edited successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.UPDATE_TEAM_MEMBER_DETAILS.getCode(),SuccessMessage.UPDATE_TEAM_MEMBER_DETAILS.getMessage(), null, editTeamMember));
    }

    @Operation(summary = "Fetch All skills from Team Members",description = "Api to Fetch All skills from Team Members")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch skills Successfully"),
            @ApiResponse(responseCode = "404", description = "Skills not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/teamMembers/skills")
    public ResponseEntity<ResponseDto> fetchAllSkills(@RequestParam("projectId") String projectId,HttpServletRequest servletRequest) {
        log.info("TeamMemberController::fetchAllSkills() started");
        Set<String> skills=teamMemberService.getAllSkills(utilMethods.stringToLong(projectId));
        log.info("TeamMemberController::fetchAllSkills ended");
        return ResponseEntity.ok(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.TEAM_MEMBERS_SKILLS.getCode(), SuccessMessage.TEAM_MEMBERS_SKILLS.getMessage(),null, skills));
    }

    @Operation(summary = "Team Member filter",description = "Api to Filter Team Member")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Filtered team member successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/teamMembers/filters")
    public ResponseEntity<ResponseDto<List<TeamMemberResponseListDto>>> filterTeamMember(@Valid @RequestBody TeamMemberFilterDto teamMemberFilterDto, HttpServletRequest servletRequest, @RequestParam("projectId") String projectId) {
        log.info("TeamMemberController::Filtering teamMember: {}", teamMemberFilterDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, TEAM_MEMBERS,VIEW_ALL,VIEW_ASSOCIATED);
        List<TeamMemberResponseListDto> teamMemberList=teamMemberService.getAllTeamMembers(rolesDto.getOid(),utilMethods.stringToLong(projectId),teamMemberFilterDto);
        log.info("TeamMemberController::filterTeamMember() ended");
        return ResponseEntity.ok(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.TEAM_MEMBER_LIST_FETCHED.getCode(), SuccessMessage.TEAM_MEMBER_LIST_FETCHED.getMessage(),null, teamMemberList));
    }
}
