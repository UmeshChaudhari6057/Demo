package com.maveric.delivery.Entity;



import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name = "artifactType")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class ArtifactType extends IdentifiedEntity{
    private String name;

    public ArtifactType(long l, String artifactType1) {
        super();
    }
}

