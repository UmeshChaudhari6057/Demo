package com.maveric.delivery.exception;

public class DuplicateProjectsException extends RuntimeException {
    public DuplicateProjectsException(String message) {
        super(message);
    }
}
