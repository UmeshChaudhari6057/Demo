package com.maveric.delivery.Entity;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "assessment_sharepoint_details")
public class AssessmentSharePointDetails extends IdentifiedEntity {

    @Column(name = "assessment_id", nullable = false)
    private Long assessmentId;

    @Column(name = "question_number", nullable = false)
    private int questionNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "assessment_category_type")
    private AssessmentCategoryType assessmentCategoryType;

    @Column(name = "document_id")
    private String documentId;

    @Column(name = "folder_document_id")
    private String folderDocumentId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "type")
    private String type;
}