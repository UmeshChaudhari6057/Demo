package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.ErrorMessage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssignUserRoleResponseDto {
    private List<DedRolesmy> newlyAssignedRoles;
    private List<ErrorMessage> errorMessage;

}
