package com.maveric.delivery.Entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "privileges")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Privileges extends IdentifiedEntity {

    @Column(nullable = false, unique = true)
    private String name;

    @Column(nullable = false)
    private String value;

    @Column(columnDefinition = "TEXT")
    private String description;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_privilege_id")
    private List<Privileges> privileges;  // Self-referencing relationship
}
