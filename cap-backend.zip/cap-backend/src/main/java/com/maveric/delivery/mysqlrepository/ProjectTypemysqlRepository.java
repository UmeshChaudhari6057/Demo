package com.maveric.delivery.mysqlrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.ProjectType;

public interface ProjectTypemysqlRepository extends JpaRepository<ProjectType,Long> {

    Optional<ProjectType> findByNameIgnoreCase(String projectType);
}
