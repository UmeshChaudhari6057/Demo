package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maveric.delivery.Entity.BusinessSubvertical;

@Repository
public interface BusinessSubverticalmysqlRepository extends JpaRepository<BusinessSubvertical, Long> {
}
