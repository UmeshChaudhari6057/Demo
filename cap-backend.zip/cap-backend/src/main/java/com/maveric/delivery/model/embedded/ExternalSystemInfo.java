package com.maveric.delivery.model.embedded;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class ExternalSystemInfo {
    @Size(min = 2, max = 50, message = "External System Id must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "External System Id can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String id;
    @Size(min = 2, max = 50, message = "External System Name must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "External System Name can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String name;
}
