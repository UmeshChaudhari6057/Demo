package com.maveric.delivery.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectFilterDto {
    private String projectName;
    private List<UUID> deliveryManager;
    private List<UUID> deliveryPartner;
    private List<UUID> engagementPartner;
    private List<UUID> accountPartner;
    private String status;
    private String sortBy;
    private String deliveryImpactRange;
}
