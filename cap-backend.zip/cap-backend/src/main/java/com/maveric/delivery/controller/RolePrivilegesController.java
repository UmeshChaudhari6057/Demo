package com.maveric.delivery.controller;

import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.RolePrivilegesService;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Validated
@Tag(name = "Role Privileges", description = "Endpoints for managing Role Privileges")
public class RolePrivilegesController {

    private final RolePrivilegesService rolePrivilegesService;

    private final ValidateApiAccess validateApiAccess;

    @Operation(summary = "The API will efficiently manage and preserve role privileges.",description = "Api to Save Role privileges")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Role privileges created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/role-privileges")
    public ResponseEntity<ResponseDto<List<RolePrivilegesDto>>> save(HttpServletRequest servletRequest,@Valid @NotEmpty @RequestBody List<RolePrivilegesDto> rolePrivilegesDtoList) {
        log.debug("RolePrivilegesController::save: start -> request:{}", rolePrivilegesDtoList);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, CREATE);
        List<RolePrivilegesDto> response = rolePrivilegesService.save(rolePrivilegesDtoList);
        log.debug("RolePrivileges save successfully");
        log.debug("RolePrivilegesController::save: end");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SuccessMessage.ROLE_PRIVILEGES_SAVE.getCode(), SuccessMessage.ROLE_PRIVILEGES_SAVE.getMessage(), null, response));
    }

    @Operation(summary = "This API is intended to retrieve the privileges associated with roles.",description = "Api to Get Role privileges")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Role privileges retrieve successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/role-privileges")
    public ResponseEntity<ResponseDto<List<RolePrivilegesDto>>> get(HttpServletRequest servletRequest) {
        log.debug("RolePrivilegesController::get: start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, VIEW_ALL);
        List<RolePrivilegesDto> response = rolePrivilegesService.findAll();
        log.debug("RolePrivilegesController::get: end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.ROLE_PRIVILEGES_FETCHED.getCode(), SuccessMessage.ROLE_PRIVILEGES_FETCHED.getMessage(), null, response));
    }
    @Operation(summary = "This API is intended to retrieve the privileges associated with roles.",description = "Api to Get Role privilege")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Role privileges retrieve successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/role-privileges/role/{roleId}")
    public ResponseEntity<ResponseDto<RolePrivilegesDto>> findByRoleId(HttpServletRequest servletRequest,@Valid @NonNull @PathVariable Long roleId) {
        log.debug("RolePrivilegesController::findByRoleId: start -> roleId:{}",roleId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, VIEW_ALL);
        RolePrivilegesDto response = rolePrivilegesService.findByRoleId(roleId);
        log.debug("RolePrivilegesController::findByRoleId: end -> roleId:{}",roleId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.ROLE_PRIVILEGES_FETCHED.getCode(), SuccessMessage.ROLE_PRIVILEGES_FETCHED.getMessage(), null, response));
    }
}
