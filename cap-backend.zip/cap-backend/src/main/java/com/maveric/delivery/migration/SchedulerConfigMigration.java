package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.Roles;
import com.maveric.delivery.Entity.SchedulerConfig;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.mysqlrepository.SchedulerConfigmysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Slf4j
@Service
//@ChangeUnit(id = "SchedulerConfig-v.0.2", order = "001", author = "delivery-excellence", systemVersion = "1")
public class SchedulerConfigMigration implements Migration {
  //  private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/schedulerConfig.json";
    
    private final SchedulerConfigmysqlRepository schedulerConfigmysqlRepository;

    
    @Override
    public void before() {
        log.info("SchedulerConfig Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("SchedulerConfig Migration RollbackBeforeExecution");
    }

    
    @Override
    public void migrationMethod() throws IOException {
        log.info("mongock migrationMethod");
//        mongoTemplate.remove(new Query(), SchedulerConfig.class);
//        List<SchedulerConfig> schedulerConfigs = jsonFileReader.readJsonFileToList(filePath, SchedulerConfig.class);
//        mongoTemplate.insertAll(schedulerConfigs);
//        
        schedulerConfigmysqlRepository.deleteAll();
        
        try {
            List<SchedulerConfig> schedulerConfigs = jsonFileReader.readJsonFileToList(filePath, SchedulerConfig.class);

            if (!schedulerConfigs.isEmpty()) {
            	schedulerConfigmysqlRepository.saveAll(schedulerConfigs);
                log.info("Migration completed: {} records inserted", schedulerConfigs.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
          
        
    }

    
    @Override
    public void rollback() {
        log.info("SchedulerConfig Migration RollbackBeforeExecution");
        schedulerConfigmysqlRepository.deleteAll();
    }
}