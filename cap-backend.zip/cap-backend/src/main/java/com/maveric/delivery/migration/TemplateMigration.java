package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.Entity.Template;
import com.maveric.delivery.mysqlrepository.TemplatemysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "Template-v.0.4", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@Service
@AllArgsConstructor
public class TemplateMigration implements Migration{
  //  private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/template.json";

    private final TemplatemysqlRepository templatemysqlReposiotry;
    
    @Override
    public void before() {
        log.info("Delivery Impact Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("Delivery Impact Migration RollbackBeforeExecution");
    }

    
    @Override
    public void migrationMethod() throws IOException {
        log.info("Delivery migrationMethod");
//        mongoTemplate.remove(new Query(), Template.class);
//        List<Template> templates = jsonFileReader.readJsonFileToList(filePath, Template.class);
//        mongoTemplate.insertAll(templates);
//        
        templatemysqlReposiotry.deleteAll();
        try {
            List<Template> templates = jsonFileReader.readJsonFileToList(filePath, Template.class);

            if (!templates.isEmpty()) {
            	templatemysqlReposiotry.saveAll(templates);
                log.info("Migration completed: {} records inserted", templates.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
    }

    
    @Override
    public void rollback() {
        log.info("Delivery Impact Migration RollbackBeforeExecution");
        templatemysqlReposiotry.deleteAll();
    }

}
