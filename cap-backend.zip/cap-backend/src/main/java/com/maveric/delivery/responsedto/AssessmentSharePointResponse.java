package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class AssessmentSharePointResponse {

    private Long assessmentId;
    private int questionNumber;
    private AssessmentCategoryType assessmentCategoryType;
    private String itemDocumentId;
}
