package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.ProjectStatus;

public interface ProjectStatusmysqlRepository extends JpaRepository<ProjectStatus,Long>  {

}
