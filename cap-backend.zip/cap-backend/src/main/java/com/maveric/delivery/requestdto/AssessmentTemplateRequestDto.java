package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.TemplateStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

import static com.maveric.delivery.model.embedded.AssessmentCategoryType.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssessmentTemplateRequestDto {
    private AssessmentCategoryType assessmentType;
    @NotBlank(message = "Template name is required")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "Template name can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    @Size(min = 3,max = 50, message = "Template name must be between 3 and 50 characters")
    private String templateName;
    @Size(min = 3,max = 50, message = "Project type must be between 3 and 50 characters")
    private String projectType;
    @NotNull(message = "Status is required")
    private TemplateStatus status;
    @Size(min = 3,max = 500, message = "Description must be between 3 and 500 characters")
    private String description;
    @Valid
    @Size(max = 50,message = "The number of questions cannot exceed 50")
    private List<TemplateQuestionDto> questions;

    public void setProjectType(String projectType){
        if(this.assessmentType.equals(DELIVERY_MATURITY) || this.assessmentType.equals(PROJECT_MATURITY)){
            this.projectType = null;
        }else {
            if(!projectType.matches("^[a-zA-Z0-9\\- ]+$")){
                throw new IllegalArgumentException("Project Type can only contains number , alphabets and hyphen");
            }
            this.projectType = projectType;
        }

    }

    public void setDescription(String description){
        if(StringUtils.isBlank(description)){
            this.description = null;
        }else {
            if(!description.matches("^[a-zA-Z0-9,.&()\\- \\n/?%\":#'+*=]+$")){
                throw new IllegalArgumentException("Description can only contain alphabets, numbers, comma, dot, &, (),/,?,%,\",:,#,',+,*,= and hyphen");
            }
            this.description = description;
        }

    }


}
