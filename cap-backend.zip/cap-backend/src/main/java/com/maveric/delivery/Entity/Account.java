package com.maveric.delivery.Entity;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AccountType;
import com.maveric.delivery.model.embedded.ClientInformation;
import com.maveric.delivery.model.embedded.DedRolesmy;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "accounts")
public class Account extends IdentifiedEntity {

    @Column(name = "account_name", nullable = false)
    private String accountName;

    @Enumerated(EnumType.STRING)
    @Column(name = "account_type")
    private AccountType accountType;

    @ElementCollection
    @CollectionTable(name = "account_tags", joinColumns = @JoinColumn(name = "account_id"))
    @Column(name = "tag")
    private List<String> tags;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id")
    private List<DedRolesmy> dedRoles;

    @Column(name = "date_onboarded")
    private Long dateOnboarded;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private AccountStatus status;

    @Column(name = "external_id", unique = true)
    private String externalId;

    @Embedded
    private ClientInformation clientInfo;

    @Column(name = "created_by", nullable = false, updatable = false)
    private UUID createdBy;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Long createdAt;

    @Column(name = "updated_by")
    private UUID updatedBy;

    @Column(name = "updated_at")
    private Long updatedAt;
    
    
    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Project> projects;
    
    public List<DedRolesmy> getDedRolesmy() {
        return dedRoles;
    }
    
    public Account(Long id) {
        this.id = id;
    }

}
