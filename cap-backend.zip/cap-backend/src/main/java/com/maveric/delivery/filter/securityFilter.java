package com.maveric.delivery.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.Entity.Audit;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.UserService;
import com.maveric.delivery.utils.CustomAuthToken;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.JwtTokenDecoder;
//import io.mongock.utils.CollectionUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.util.CollectionUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RequiredArgsConstructor
public class securityFilter extends OncePerRequestFilter {

    private final JwtTokenDecoder jwtTokenDecoder;
    private final UserService userService;

    private final AuditImpl audit;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        String header = request.getHeader(AUTHORIZATION);
        updateTraceId(request,response);
        if (StringUtils.contains(request.getRequestURI(), "/swagger-ui/")
                || StringUtils.contains(request.getRequestURI(), "api-docs")) {
            filterChain.doFilter(request, response);
            return;
        }
        try {
            if (StringUtils.isBlank(header) || !header.startsWith(BEARER)) {
                throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
            }
            String token = header.substring(7);

            String oId = (String) jwtTokenDecoder.decodeToken(token).getClaim(O_ID);
            request.setAttribute(O_ID, oId);
            if (StringUtils.isBlank(oId))
                throw new PermissionDeniedException(FailedMessage.INVALID_TOKEN.getMessage(), FailedMessage.INVALID_TOKEN.getCode());

//            List<String> roles = userService.getRolesName(UUID.fromString(oId));
//            if (CollectionUtils.isNullEmpty(roles)) {
//                throw new PermissionDeniedException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());
//            }
            
         // Updated Code
            List<String> roles = userService.getRolesName(UUID.fromString(oId));
            if (CollectionUtils.isEmpty(roles)) {  // Spring's CollectionUtils
                throw new PermissionDeniedException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());
            }

            List<SimpleGrantedAuthority> simpleGrantedAuthorities = roles.stream()
                    .map(str -> str.toUpperCase().replace(" ", "_")).toList()
                    .stream().map(SimpleGrantedAuthority::new).toList();
            List<GrantedAuthority> grantedAuthorityList = new ArrayList<>(simpleGrantedAuthorities);
            CustomAuthToken customAuthToken = new CustomAuthToken(request, grantedAuthorityList);
            customAuthToken.setDetails(new WebAuthenticationDetails(request));
            SecurityContextHolder.setContext(new SecurityContextImpl(customAuthToken));

            filterChain.doFilter(request, response);
        } catch (PermissionDeniedException e) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            ResponseDto<Object> errorResponse = new ResponseDto<>();
            errorResponse.setStatus(FAILED);
            errorResponse.setCode(e.getCode());
            errorResponse.setMessage(e.getMessage());
            audit.log( auditDetails(request,response,e));
            writeJsonResponse(response, errorResponse);
        }finally {
            // Clear the trace ID from the MDC after the request is processed
            MDC.remove(TRACE_ID);
        }
    }

    private Audit auditDetails(HttpServletRequest request, HttpServletResponse response, PermissionDeniedException e) {
        Audit audit = new Audit();
        audit.setAuditEntity(request.getRequestURI().split("/")[2]);
        audit.setRequestUrl(String.valueOf(request.getRequestURL()));
        UUID userId = request.getAttribute(O_ID) != null ? UUID.fromString((String) request.getAttribute(O_ID)) :null;
        audit.setOid(userId);
        audit.setTraceId(response.getHeader(TRACE_ID_HEADER));
        audit.setAction(request.getMethod().concat(" ").concat(request.getRequestURI()));
        audit.setStatus(String.valueOf(response.getStatus()));
        audit.setErrorMessage(e.getMessage());
        return audit;
    }

    private void writeJsonResponse(HttpServletResponse response, Object responseObject) throws IOException {
        response.setContentType("application/json");
        PrintWriter writer = response.getWriter();
        ObjectMapper objectMapper = new ObjectMapper();
        writer.write(objectMapper.writeValueAsString(responseObject));
        writer.flush();
    }
    private void updateTraceId(HttpServletRequest request,HttpServletResponse response){

        // Generate a new trace ID or use an existing one from the request
        String traceId = UUID.randomUUID().toString();
        String existingTraceId = request.getHeader(TRACE_ID_HEADER);
        if (existingTraceId != null && !existingTraceId.isEmpty()) {
            traceId = existingTraceId;
        }
        // Set the trace ID in the MDC
        MDC.put(TRACE_ID, traceId);
        response.setHeader(TRACE_ID_HEADER,traceId);
    }
}
