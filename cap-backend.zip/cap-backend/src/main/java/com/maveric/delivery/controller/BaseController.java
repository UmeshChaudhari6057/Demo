package com.maveric.delivery.controller;


import com.maveric.delivery.Entity.SchedulerConfig;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.BaseService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.maveric.delivery.utils.Constants.FAILED;
import static com.maveric.delivery.utils.Constants.SUCCESS;
import static com.maveric.delivery.utils.SuccessMessage.FETCHED_PROJECT_STATUS;
import static com.maveric.delivery.utils.FailedMessage.*;
import static com.maveric.delivery.utils.FailedMessage.ARTIFACTTYPE_CREATION_FAILED;
import static com.maveric.delivery.utils.SuccessMessage.*;
import static com.maveric.delivery.utils.SuccessMessage.SAVE_ARTIFACT_TYPE;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Base Details Management", description = "Endpoints for managing Base Details")
public class BaseController {

    private final BaseService baseService;

    @Operation(summary = "Fetch All BasedTypes",description = "Api to Get All BasedTypes")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch All BasedTypes Successfully"),
            @ApiResponse(responseCode = "404", description = "Types not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/types/{typeName}")
    public ResponseEntity<ResponseDto<List<BaseDto>>> fetchAllType(@PathVariable String typeName) {
        log.info("BasedController::FetchAllType() started");
        List<BaseDto> baseDtoList = baseService.fetchAllTypes(typeName);
        if (CollectionUtils.isEmpty(baseDtoList)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(FAILED, FailedMessage.TYPE_NOT_FOUND.getCode(), FailedMessage.TYPE_NOT_FOUND.getMessage().replaceAll("Type", typeName), null, baseDtoList));
        }
        log.info("BasedController::FetchAllType() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_TYPE.getCode(), typeName + SuccessMessage.FETCH_TYPE.getMessage(), null, baseDtoList));
    }

    @Operation(summary = "Fetch All Project Status",description = "Api to Get All Project Status")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch All Project Status Successfully"),
            @ApiResponse(responseCode = "404", description = "Project Status not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })

    @GetMapping(path = "/types/project-status")
    public ResponseEntity<ResponseDto<List<BaseDto>>> fetchAllProjectStatus() {
        log.info("BasedController::fetchAllProjectStatus() started");
        List<BaseDto> baseDtoList = baseService.fetchAllProjectStatus();
        if (CollectionUtils.isEmpty(baseDtoList)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(FAILED, FailedMessage.FETCHED_PROJECT_STATUS_FAILED.getCode(), FailedMessage.FETCHED_PROJECT_STATUS_FAILED.getMessage(), null, baseDtoList));
        }
        log.info("BasedController::fetchAllProjectStatus() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, FETCHED_PROJECT_STATUS.getCode(), FETCHED_PROJECT_STATUS.getMessage(), null, baseDtoList));
    }
    @Operation(summary = "Save Location",description = "Api to Save Location")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Save Location Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping (path = "/types/location/{location}")
    public ResponseEntity<ResponseDto<BaseDto>> saveLocation(@PathVariable("location") String name) {
        log.info("BasedController::saveLocation() started");
        BaseDto saveLocation = baseService.saveLocation(name);
        if (saveLocation == null) {
            return ResponseEntity.ok(new ResponseDto<>(FAILED, LOCATION_CREATION_FAILED.getCode(), LOCATION_CREATION_FAILED.getMessage(), null, null));
        }
        log.info("BasedController::saveLocation() ended");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SAVE_LOCATION.getCode(), SAVE_LOCATION.getMessage(), null, saveLocation));
    }
    @Operation(summary = "Save ProjectRole",description = "Api to Save ProjectRole")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Save ProjectRole Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping (path = "/types/projectRole/{projectRole}")
    public ResponseEntity<ResponseDto<BaseDto>> saveProjectRole(@PathVariable("projectRole") String name) {
        log.info("BasedController::saveProjectRole() started");
        BaseDto projectRole = baseService.saveProjectRole(name);
        if (projectRole == null) {
            return ResponseEntity.ok(new ResponseDto<>(FAILED, PROJECTROLE_CREATION_FAILED.getCode(), PROJECTROLE_CREATION_FAILED.getMessage(), null, null));
        }
        log.info("BasedController::saveProjectRole() ended");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SAVE_PROJECT_ROLE.getCode(), SAVE_PROJECT_ROLE.getMessage(), null, projectRole));
    }
    @Operation(summary = "Save ArtifactType",description = "Api to Save ArtifactType")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Save ArtifactType Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping (path = "/types/artifactType/{artifactType}")
    public ResponseEntity<ResponseDto<BaseDto>> saveArtifactType(@PathVariable("artifactType") String name) {
        log.info("BasedController::saveArtifactType() started");
        BaseDto artifactType= baseService.saveArtifactType(name);
        if (artifactType == null) {
            return ResponseEntity.ok(new ResponseDto<>(FAILED, ARTIFACTTYPE_CREATION_FAILED.getCode(), ARTIFACTTYPE_CREATION_FAILED.getMessage(), null, null));
        }
        log.info("BasedController::saveArtifactType() ended");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SAVE_ARTIFACT_TYPE.getCode(), SAVE_ARTIFACT_TYPE.getMessage(), null, artifactType));
    }

}
