package com.maveric.delivery.mysqlrepository;

import com.maveric.delivery.Entity.Roles;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RolesmysqlRepository extends JpaRepository<Roles, Long> {

   // @Cacheable(value = "findByGroupContaining", key = "#group")
    Roles findByGroupContaining(String group);

    List<Roles> findByGroupIn(List<String> groups);

    //@Cacheable(value = "findByName", key = "#name")
    Roles findByName(String name);
}