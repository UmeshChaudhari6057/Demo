package com.maveric.delivery.model.embedded;
import com.maveric.delivery.Entity.Question;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Embeddable
public class TemplateCategory {

	@Enumerated(EnumType.STRING)
    private AssessmentCategoryType name;
	
	
	private List<Question> questions;
	
	 
	
}
