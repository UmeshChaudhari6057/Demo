package com.maveric.delivery.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArtifactFilterDto {
   private String type;
   private long startDate;
   private long endDate;
   private String sortBy;
}
