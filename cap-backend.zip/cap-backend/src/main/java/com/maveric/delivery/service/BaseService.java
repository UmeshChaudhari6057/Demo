package com.maveric.delivery.service;

import com.maveric.delivery.Entity.SchedulerConfig;
import com.maveric.delivery.responsedto.BaseDto;

import java.util.List;

public interface BaseService {
    public List<BaseDto> fetchAllTypes(String type);
    List<BaseDto> fetchAllProjectStatus();

    BaseDto saveLocation(String name);
    BaseDto saveProjectRole(String name);
    BaseDto saveArtifactType(String name);

}
