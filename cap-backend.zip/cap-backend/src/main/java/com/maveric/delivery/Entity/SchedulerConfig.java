package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "scheduler_config")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SchedulerConfig extends IdentifiedEntity {

    @Column(name="config_key")
    private String key;

    
    private String value;
}
