package com.maveric.delivery.mysqlrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maveric.delivery.Entity.RolePrivileges;

@Repository
public interface RolePrivilegesmysqlRepository extends JpaRepository<RolePrivileges, Long> {

    // Uncomment this if caching is enabled in your project
    // @Cacheable(value = "findByRoleId", key = "#roleId")
    Optional<RolePrivileges> findByRoleId(Long roleId);
}