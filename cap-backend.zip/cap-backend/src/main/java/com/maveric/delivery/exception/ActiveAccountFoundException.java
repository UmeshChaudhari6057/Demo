package com.maveric.delivery.exception;


/**
 * @author ankushk
 */
public class ActiveAccountFoundException extends RuntimeException {
    public ActiveAccountFoundException(String message) {
        super(message);
    }
}
