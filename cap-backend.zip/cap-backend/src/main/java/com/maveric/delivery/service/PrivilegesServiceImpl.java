package com.maveric.delivery.service;

import com.maveric.delivery.mapper.PrivilegesMapper;
import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.mysqlrepository.PrivilegesmysqlRepository;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrivilegesServiceImpl implements PrivilegesService {

    private final PrivilegesmysqlRepository privilegesRepository;

    @Override
    public List<PrivilegesDetailsDto> getPrivileges() {
        log.debug("PrivilegesServiceImpl.getPrivileges: start");
        List<Privileges> privileges = privilegesRepository.findAll();
        log.debug("PrivilegesServiceImpl.getPrivileges: end ");
        return PrivilegesMapper.MAPPER.toDtoList(privileges);
    }

}
