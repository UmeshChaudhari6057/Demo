package com.maveric.delivery.requestdto;


import com.maveric.delivery.model.embedded.OtherInformation;
import com.maveric.delivery.model.embedded.ProjectClientInfo;
import com.maveric.delivery.model.embedded.ProjectStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectRequestDto {
    @NotNull(message = "Account Id is required")
    private Long accountId;
    @NotBlank(message = "Project name is required")
    @Size(min = 3, max = 50, message = "Project name must be between 3 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()+\\- ]+$", message = "Project name can only contain alphabets, numbers, comma, dot, &, (), + and hyphen")
    private String projectName;
    @Size(min = 3, max = 50, message = "CustomerLOB must be between 3 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "CustomerLOB can only contain alphabets, numbers, comma, dot, &, () and hyphen")
    private String customerLOB;
    @NotBlank(message = "Engagement Type is required")
    private String engagementType;
    @Size(max = 10, message = "Maximum of 10 tags are allowed")
    @SuppressWarnings("unchecked")
    private List<String> tags;
    @NotNull(message = "Business SubVertical is required")
    private String businessSubVertical;
    @NotNull(message = "Start Date is required")
    private Long startDate;
    @NotNull(message = "Billable is required")
    private Boolean isBillable;
    @Size(min = 100, max = 500, message = "Description must be between 100 and 500 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- \\n!@#$%*?/:;'\"\\[\\]{}|=+_]+$", message = "Description can only contain alphabets, numbers and special characters like(!@#$%&*().,/?:;'\"[]{}|=+-_ )")
    private String description;
    @Valid
    @NotNull(message = "deliveryInfo is required")
    private DeliveryInformationDto deliveryInfo;
    @Valid
    private ProjectClientInfo clientInformation;
    @Valid
    private OtherInformation otherInformation;
    private ProjectStatus status;
    private Long endDate;
    public void setTags(List<String> tags) {
        if (!(tags == null || tags.isEmpty())) {
            for (String tag : tags) {
                if (tag == null || tag.length() < 3 || tag.length() > 25
                        || !tag.matches("^[a-zA-Z0-9-# ]+$")) {
                    throw new IllegalArgumentException("Invalid tag format");
                }
            }
        }
        this.tags = tags;
    }

}
