package com.maveric.delivery.exception;

public class SuperAdminRoleAlreadyAssignedException extends RuntimeException {
    public SuperAdminRoleAlreadyAssignedException(String message) {
        super(message);
    }
}