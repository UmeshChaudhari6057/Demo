package com.maveric.delivery.exception;

public class NoAccountForGivenUser extends RuntimeException {
    public NoAccountForGivenUser(String message) {
        super(message);
    }
}