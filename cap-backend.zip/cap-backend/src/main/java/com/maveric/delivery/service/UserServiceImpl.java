package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.ACCOUNTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.ACCOUNTS_VIEW_ASSOCIATED;
import static com.maveric.delivery.utils.Constants.ADM;
import static com.maveric.delivery.utils.Constants.ALL;
import static com.maveric.delivery.utils.Constants.AP;
import static com.maveric.delivery.utils.Constants.ASSESSMENTS_REVIEW;
import static com.maveric.delivery.utils.Constants.ASSESSMENTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.ASSESSMENTS_VIEW_ASSOCIATED;
import static com.maveric.delivery.utils.Constants.DASHBOARD_VIEW;
import static com.maveric.delivery.utils.Constants.DM;
import static com.maveric.delivery.utils.Constants.DP;
import static com.maveric.delivery.utils.Constants.EP;
import static com.maveric.delivery.utils.Constants.FULL_ACCESS;
import static com.maveric.delivery.utils.Constants.NO_ACCESS;
import static com.maveric.delivery.utils.Constants.PROJECTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.PROJECTS_VIEW_ASSOCIATED;
import static com.maveric.delivery.utils.Constants.SHOW_ACCOUNTS_TAB;
import static com.maveric.delivery.utils.Constants.SHOW_ALL_ASSESSMENTS_TAB;
import static com.maveric.delivery.utils.Constants.SHOW_ASSESSMENTS_TAB;
import static com.maveric.delivery.utils.Constants.SHOW_DASHBOARD_TAB;
import static com.maveric.delivery.utils.Constants.SHOW_MY_ASSESSMENTS_TAB;
import static com.maveric.delivery.utils.Constants.SHOW_PROJECTS_TAB;
import static com.maveric.delivery.utils.Constants.SHOW_REVIEW_ASSESSMENTS_TAB;
import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBER;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.DuplicateUserIdException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.exception.ValidationException;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.Roles;
import com.maveric.delivery.Entity.TeamMember;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.mysqlrepository.RolesmysqlRepository;
import com.maveric.delivery.requestdto.AccountRoles;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.requestdto.RolesDto;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.requestdto.UserPrivilegesDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.UtilMethods;
import com.microsoft.graph.models.User;
import com.microsoft.graph.models.UserCollectionResponse;
import com.microsoft.graph.serviceclient.GraphServiceClient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final DedRolesRepository dedRolesRepository;
    private final AzureUsermysqlRepository azureUserRepository;
    private final GraphServiceClient graphServiceClient;
   // private final ProjectRepository projectRepository;
    private final RolesmysqlRepository rolesRepository;
    private final RolePrivilegesService rolePrivilegesService;
    private final RolesService rolesService;
    private final UtilMethods utilMethods;

    @Override
    public String getHighestRole(UUID oid, Long accountId, Long projectId) {
        log.info("UserServiceImpl::getHighestRole:: call started");
        if (oid == null) {
            throw new CustomException("Invalid request,oid cannot be null", HttpStatus.BAD_REQUEST);
        }

        List<DedRolesmy> rolesList = dedRolesRepository.findByOid(oid);

        if (SUPER_ADMIN_.equalsIgnoreCase(getRole(rolesList))) {
            return getRole(rolesList);
        }
        if ( accountId != null && projectId != null){//projectlevel
            rolesList = dedRolesRepository.findByOidAndProject_IdAndAccount_Id(oid, projectId, accountId);
        }
        if (projectId == null && accountId!=null) {//accountlevel
            rolesList = dedRolesRepository.findByOidAndAccount_Id(oid, accountId);
            return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
        }
        if (accountId == null && projectId == null) {//applicationlevel
            return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
        }
        if(accountId==null){//projectid level when I don't have accountId in the request
        	
        }
     // Commented out MongoDB code
//            Optional<Project> project=projectRepository.findById(projectId);
//
//            if (project.isEmpty()) {
//                log.error("UserServiceImpl::getHighestRole:: Project id not found");
//                throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
//            }
//                accountId=project.get().getAccountId();
//                rolesList = dedRolesRepository.findByOidAndProject_IdAndAccount_Id(oid, projectId, accountId);
//                return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
//        }
//        log.info("UserServiceImpl::getHighestRole:: call ended");
//        return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
        return "Void";
    }


    @Override
    public DedRolesmy saveUser(DedRolesDto json) {
        DedRolesmy dedRoles = new DedRolesmy();
        BeanUtils.copyProperties(json, dedRoles);
        return dedRolesRepository.save(dedRoles);
    }

    public String getRole(List<DedRolesmy> rolesList) {
        log.info("getHighestRole:: getRole:: call started");
        List<String> userGroups = rolesList.stream().map(DedRolesmy::getRole).toList();
        List<RolesDto> roles = rolesService.findByGroups(userGroups);
        log.info("getHighestRole:: getRole:: call ended");
        return roles.stream().filter(Objects::nonNull).min(Comparator.comparingInt(RolesDto::getHierarchy)).map(RolesDto::getName).orElse(null);
    }

    public List<UserDto> getAllUsers() {
        log.info("UserServiceImpl::getAllUsers:: call started");
        List<AzureUsers> azureUsersList = azureUserRepository.findAll();
        log.info(" {} users fetched from azureUsers DB", azureUsersList.size());
        List<UserDto> userDtoList = azureUsersList.stream()
                .map(azureUser -> new UserDto(azureUser.getId(), azureUser.getDisplayName()))
                .toList();
        log.info("UserServiceImpl::getAllUsers:: call ended");
        return userDtoList;
    }

    public Integer refreshUsers() throws ReflectiveOperationException {

        log.info("UserServiceImpl::refreshUsers:: call started");
        AtomicInteger updatedCount = new AtomicInteger(0);
        UserCollectionResponse result = graphServiceClient.users().get(requestConfiguration -> {
            requestConfiguration.queryParameters.top = 999;
            requestConfiguration.queryParameters.count = true;
        });
        updateUser(result.getValue(),updatedCount);
        checkNextData(result,updatedCount);

        log.info("UserServiceImpl::refreshUsers:: call End");
        return updatedCount.get();
    }

    private void checkNextData(UserCollectionResponse userCollectionResponse, AtomicInteger updatedCount) {
        String nextLink = userCollectionResponse.getOdataNextLink();
        UserCollectionResponse result = graphServiceClient.users().withUrl(nextLink).get(requestConfiguration -> {
            requestConfiguration.queryParameters.count = true;
        });
        updateUser(result.getValue(), updatedCount);
        if (StringUtils.isNotBlank(result.getOdataNextLink())) {
            checkNextData(result, updatedCount);
        }

    }

    private void updateUser(List<User> result, AtomicInteger updatedCount) {
        List<AzureUsers> userList = new ArrayList<>();
        result.forEach(user -> {
                    AzureUsers user1 = new AzureUsers();
                    user1.setId(UUID.fromString(Objects.requireNonNull(user.getId())));
                    user1.setDisplayName(user.getDisplayName());
                    user1.setMail(user.getMail());
                    user1.setUserPrincipalName(user.getUserPrincipalName());
                    user1.setSurname(user.getSurname());
                    user1.setGivenName(user.getGivenName());
                    user1.setUserType(user.getUserType());
                    user1.setJobTitle(user.getJobTitle());
                    userList.add(user1);
                }
        );
        azureUserRepository.saveAll(userList);
        updatedCount.addAndGet(userList.size());

    }

    public <T> void saveRole(T dto) {
        if (dto instanceof AccountResponseDto accountResponseDto) {
            List<DedRolesmy> dedRolesList = new ArrayList<>();
            dedRolesList.add(new DedRolesmy(accountResponseDto.getDeliveryHead().getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(accountResponseDto.getDeliveryHead().getUserId()), "DH"));
            for (AccountRoles role : accountResponseDto.getAccountPartners()) {
                dedRolesList.add(new DedRolesmy(role.getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(role.getUserId()), AP));
            }
            for (AccountRoles role : accountResponseDto.getDeliveryPartners()) {
                dedRolesList.add(new DedRolesmy(role.getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(role.getUserId()), DP));
            }
            for (AccountRoles role : accountResponseDto.getEngagementPartners()) {
                dedRolesList.add(new DedRolesmy(role.getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(role.getUserId()), EP));
            }
            dedRolesRepository.saveAll(dedRolesList);
        } else if (dto instanceof ProjectResponseDto projectResponseDto) {
            List<DedRolesmy> dedRolesList = new ArrayList<>();
            dedRolesList.add(new DedRolesmy(projectResponseDto.getDeliveryInfo().getDeliveryManager().getUserId(), projectResponseDto.getAccountId(),
                    projectResponseDto.getProjectId(),
                    getDisplayName(projectResponseDto.getDeliveryInfo().getDeliveryManager().getUserId()),
                    DM));

            if(Objects.nonNull(projectResponseDto.getDeliveryInfo().getActingDeliveryManager()))
                dedRolesList.add(new DedRolesmy(projectResponseDto.getDeliveryInfo().getActingDeliveryManager().getUserId(), projectResponseDto.getAccountId(),
                    projectResponseDto.getProjectId(),
                    getDisplayName(projectResponseDto.getDeliveryInfo().getActingDeliveryManager().getUserId()),
                    ADM));

            dedRolesList.add(new DedRolesmy(projectResponseDto.getDeliveryInfo().getAccountPartner().getUserId(), projectResponseDto.getAccountId(), projectResponseDto.getProjectId(), getDisplayName(projectResponseDto.getDeliveryInfo().getAccountPartner().getUserId()), AP));
            dedRolesList.add(new DedRolesmy(projectResponseDto.getDeliveryInfo().getDeliveryPartner().getUserId(), projectResponseDto.getAccountId(), projectResponseDto.getProjectId(), getDisplayName(projectResponseDto.getDeliveryInfo().getDeliveryPartner().getUserId()), DP));
            dedRolesList.add(new DedRolesmy(projectResponseDto.getDeliveryInfo().getEngagementPartner().getUserId(), projectResponseDto.getAccountId(), projectResponseDto.getProjectId(), getDisplayName(projectResponseDto.getDeliveryInfo().getEngagementPartner().getUserId()), EP));
            dedRolesRepository.saveAll(dedRolesList);
        } else if(dto instanceof TeamMember teamMember){
        	DedRolesmy dedRoles = new DedRolesmy();
            Long projectId=teamMember.getProjectId();
            dedRoles.setRole(TEAM_MEMBER);
            dedRoles.setProjectId(projectId);
            dedRoles.setOid(teamMember.getUserId());
            //// Commented out MongoDB code
        //    dedRoles.setAccountId(projectRepository.findById(projectId).get().getAccountId());
            dedRoles.setName(teamMember.getName());
            dedRolesRepository.save(dedRoles);
        }
    }

    @Override
    public UserPrivilegesDto getPrivileges(UUID userId) {

        List<RolePrivilegesDto> rolePrivileges = getRolePrivileges(userId);
        UserPrivilegesDto userPrivilegesDto = new UserPrivilegesDto();
        List<String> rolesList = rolePrivileges.stream().filter(Objects::nonNull).map(RolePrivilegesDto::getRoleName).toList().stream().distinct().toList();
        userPrivilegesDto.setRoles(rolesList);
        userPrivilegesDto.setHighestRole(rolePrivileges.stream().filter(Objects::nonNull).min(Comparator.comparingLong(RolePrivilegesDto::getHierarchy)).map(RolePrivilegesDto::getRoleName).orElse(null));
        userPrivilegesDto.setSuperAdmin(rolesList.contains(SUPER_ADMIN_));
        userPrivilegesDto.setPrivileges(rolePrivileges);

        return userPrivilegesDto;
    }

    @Override
    public List<String> getRolesName(UUID userId) {
        List<RolePrivilegesDto> rolePrivileges = getRolePrivileges(userId);
        return rolePrivileges.stream().filter(Objects::nonNull).map(RolePrivilegesDto::getRoleName).toList().stream().distinct().toList();
    }

    private List<RolePrivilegesDto> getRolePrivileges(UUID userId) {
        List<DedRolesmy> dedRoles = dedRolesRepository.findByOid(userId);
        List<Roles> roles = dedRoles.stream().filter(Objects::nonNull).map(dedRoles1 ->
                rolesRepository.findByGroupContaining(dedRoles1.getRole())
        ).toList().stream().distinct().toList();

        return roles.stream().filter(Objects::nonNull).map(roles1 ->
                rolePrivilegesService.findByRoleId(roles1.getId())
        ).toList();
    }


    public String getDisplayName(UUID oid) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(oid);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }


    public List<String> getPrivilegesForNavBar(UUID oid) {
        List<String> navPrivilegesList = new ArrayList<>();
        String highestRole = getHighestRole(oid, null, null);
        if (highestRole.equalsIgnoreCase("")) {
            navPrivilegesList.add(NO_ACCESS);
            return navPrivilegesList;
        }
        if (highestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
            navPrivilegesList.add(FULL_ACCESS);
            return navPrivilegesList;
        }
        List<String> privileges = utilMethods.getPrivilegesString(highestRole, List.of(ALL));
        if (isPrivilegeMatch(privileges, ACCOUNTS_VIEW_ALL, ACCOUNTS_VIEW_ASSOCIATED)) {
            navPrivilegesList.add(SHOW_ACCOUNTS_TAB);
        }
        if (isPrivilegeMatch(privileges, PROJECTS_VIEW_ALL, PROJECTS_VIEW_ASSOCIATED)) {
            navPrivilegesList.add(SHOW_PROJECTS_TAB);
        }
        if (isPrivilegeMatch(privileges, ASSESSMENTS_VIEW_ALL, ASSESSMENTS_VIEW_ASSOCIATED)) {
            if(privileges.contains(ASSESSMENTS_VIEW_ALL)) {
                navPrivilegesList.add(SHOW_MY_ASSESSMENTS_TAB);
                navPrivilegesList.add(SHOW_ALL_ASSESSMENTS_TAB);
            }else if(privileges.contains(ASSESSMENTS_VIEW_ASSOCIATED)) {
                navPrivilegesList.add(SHOW_MY_ASSESSMENTS_TAB);
            }
            if(Boolean.TRUE.equals(dedRolesRepository.existsByOidAndRole(oid,DP)) &&
                    (privileges.contains(ASSESSMENTS_REVIEW))){
                navPrivilegesList.add(SHOW_REVIEW_ASSESSMENTS_TAB);
            }
            navPrivilegesList.add(SHOW_ASSESSMENTS_TAB);
        }
        if (isPrivilegeMatch(privileges, DASHBOARD_VIEW)) {
            navPrivilegesList.add(SHOW_DASHBOARD_TAB);
        }
        if (navPrivilegesList.isEmpty()) {
            navPrivilegesList.add(NO_ACCESS);
            return navPrivilegesList;
        }
        return navPrivilegesList;
    }


    public static boolean isPrivilegeMatch(List<String> privileges, String... values) {
        return Arrays.stream(values).anyMatch(value -> privileges.stream()
                .anyMatch(privilege -> privilege.equalsIgnoreCase(value)));
    }

    public Set<String> checkAndAddUserId(Set<String> existingUserIds, AccountRoles roleObj,String field) {
        if (StringUtils.isBlank(getDisplayName(roleObj.getUserId()))) {
            log.error("ProjectServiceImpl::User not found");
            throw new ValidationException(FailedMessage.VALIDATION_EXCEPTION.getMessage(),Collections.singletonList(new ErrorMessage(field,roleObj.getName()+" not available in the system")));

        }

        if (existingUserIds.contains(roleObj.getUserId())) {
            log.error("ProjectServiceImpl::existsByAccountName::error");
            throw new DuplicateUserIdException("Multiple roles found for " + roleObj.getName());
        } else {
            existingUserIds.add(String.valueOf(roleObj.getUserId()));
        }

        return existingUserIds;
    }


}
