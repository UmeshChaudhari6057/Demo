package com.maveric.delivery.repository;

import com.maveric.delivery.Entity.AssessmentSharePointDetails;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
//import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface AssessmentSharePointRepository {// extends MongoRepository<AssessmentSharePointDetails,Long> {

    Optional<AssessmentSharePointDetails> findByAssessmentIdAndQuestionNumberAndAssessmentCategoryType(
            Long assessmentId, int questionNumber, AssessmentCategoryType categoryType);

    Optional<AssessmentSharePointDetails> findFirstByAssessmentIdAndFolderDocumentIdIsNotNull(Long assessmentId);

    Optional<AssessmentSharePointDetails> findByAssessmentIdAndQuestionNumber(Long assessmentId, int questionNumber);
}
