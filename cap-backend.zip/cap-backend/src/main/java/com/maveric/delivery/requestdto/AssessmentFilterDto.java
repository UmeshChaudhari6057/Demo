package com.maveric.delivery.requestdto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AssessmentFilterDto {

    private Long accountId;
    private Long projectId;
    private DateRangeDto dateRange;
    private String dateRangeStr;
    private String status;
    @Min(value = 0)
    private Double scoreStart;
    @Max(value = 100)
    private Double scoreEnd;

    private String sortBy;
}
