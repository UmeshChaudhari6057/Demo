package com.maveric.delivery.utils;

import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.service.RolePrivilegesService;
import com.maveric.delivery.service.UserServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.maveric.delivery.utils.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class ValidateApiAccess {

    private final RolePrivilegesService rolePrivilegesService;
    private final UserServiceImpl userService;

    @Value("${role.enabled}")
    private boolean isRoleEnabled;

    public void isAccessible(DedRolesDto rolesDto, String module, String... privileges) {

        log.debug("Role Enabled :{}", isRoleEnabled);
        if (isRoleEnabled) {
            AtomicBoolean isAccessible = new AtomicBoolean(false);
            UUID userId = rolesDto.getOid();
            Long accountId = rolesDto.getAccountId();
            Long projectId = rolesDto.getProjectId();
            log.debug("ValidateApiAccess.isAccessible: user:{} Account :{}, Project:{} -> Module :{} privileges:{}", userId, accountId, projectId, module, privileges);
            String role = userService.getHighestRole(userId, accountId, projectId);
            if(SUPER_ADMIN_.equalsIgnoreCase(role)){
                isAccessible.set(true);
            }else {
                RolePrivilegesDto rolePrivilegesDto = rolePrivilegesService.findByValue(role);
                if (Objects.isNull(rolePrivilegesDto) || StringUtils.isEmpty(rolePrivilegesDto.getRoleName()))
                    throw new PermissionDeniedException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());

                List<PrivilegesDetailsDto> privilegesDetailsDtos = rolePrivilegesDto.getPrivileges();
                log.debug("ValidateApiAccess.isAccessible: user:{} Role :{} ", userId, role);
                if (CollectionUtils.isEmpty(privilegesDetailsDtos))
                    throw new PermissionDeniedException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Privileges"), FailedMessage.DATA_NOT_FOUND.getCode());

                isAccessible.set(validate(privilegesDetailsDtos, module, privileges));
            }
            if (!isAccessible.get())
                throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    private boolean validate(List<PrivilegesDetailsDto> privilegesDetailsDtos, String module, String... action) {
        return privilegesDetailsDtos.stream().filter(Objects::nonNull).filter(privilegesDto -> privilegesDto.getValue().equalsIgnoreCase(module)).findAny().map(privilegesDto -> {
            if (!CollectionUtils.isEmpty(privilegesDto.getPrivilegesList())) {

                return privilegesDto.getPrivilegesList().stream().anyMatch(s -> Arrays.stream(action).toList().contains(s));
            }
            return false;
        }).orElse(false);
    }

}

