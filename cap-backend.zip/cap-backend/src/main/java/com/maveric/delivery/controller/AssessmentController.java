package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.*;
import com.maveric.delivery.service.AssessmentService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Assessment Management", description = "Endpoints for managing Assessments")
public class AssessmentController {

    private final AssessmentService assessmentService;
    private final ObjectMapper objectMapper;

    @Operation(summary = "Save/Submit Assessment",description = "Api to Save/Submit Assessment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Assessment saved successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/assessments/{assessmentId}")
    public ResponseEntity<ResponseDto<AssessmentCategoryWiseRequestDto>> saveAssessment(HttpServletRequest servletRequest, @RequestBody @Valid AssessmentCategoryWiseRequestDto
            assessmentCategoryWiseRequestDto,
                                                                                        @PathVariable Long assessmentId, @RequestParam Long projectId) {
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentCategoryWiseRequestDto saveAssessment = assessmentService.saveAssessment(assessmentCategoryWiseRequestDto,
                assessmentId,projectId,userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS,
                SuccessMessage.SUBMIT_ASSESSMENT.getCode(), SuccessMessage.SUBMIT_ASSESSMENT.getMessage(),
                null,saveAssessment ));
    }

    @Operation(summary = "Save/Review Assessment",description = "Api to Save/Review Assessment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Assessment reviewed successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")

    })
    @PostMapping(path = "/assessments/{assessmentId}/review")
    public ResponseEntity<ResponseDto<String>> reviewAssessment(HttpServletRequest servletRequest,@RequestBody @Valid ReviewAssessmentRequestDto
            reviewAssessmentRequestDto, @PathVariable Long assessmentId){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
         assessmentService.reviewAssessment(userId,reviewAssessmentRequestDto,assessmentId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS,
                SuccessMessage.REVIEW_ASSESSMENT.getCode(), SuccessMessage.REVIEW_ASSESSMENT.getMessage(),
                null,null ));
    }

    @Operation(summary = "Fetch Assessment",description = "Api to Get Assessment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Fetch Assessment Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/assessments/{assessmentId}")
    public ResponseEntity<ResponseDto<AssessmentResponseDto>> fetchAssessment(HttpServletRequest servletRequest,@PathVariable Long assessmentId,
                                                       @RequestParam Long projectId,@RequestParam(defaultValue = "VIEW") String action){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentResponseDto assessmentResponseDto = assessmentService.fetchAssessment(assessmentId,projectId,action,userId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS,
                SuccessMessage.FETCH_ASSESSMENT.getCode(), SuccessMessage.FETCH_ASSESSMENT.getMessage(),
                null,assessmentResponseDto ));
    }

    @Operation(summary = "Fetch Assessment List",description = "Api to Get Assessment List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Get Assessment Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/assessments")
    public ResponseEntity<ResponseDto<List<AssessmentResponseDto>>> fetchAssessments(HttpServletRequest servletRequest, @RequestParam AssessmentRole assessmentRole){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        List<AssessmentResponseDto> assessmentResponseDto = assessmentService.fetchAssessments(userId, assessmentRole, AssessmentFilterDto.builder().build());
        log.info("AssessmentController::fetchAssessments:: call ended");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS,
                SuccessMessage.FETCH_ASSESSMENT_LIST.getCode(), SuccessMessage.FETCH_ASSESSMENT_LIST.getMessage(),
                null, assessmentResponseDto));

    }

    @Operation(summary = "Upload Assessment attachment",description = "Api to upload Assessment attachment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Assessment attachment uploaded successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/assessments/{assessmentId}/upload",consumes = {"multipart/form-data"})
    public ResponseEntity<ResponseDto<AssessmentSharePointResponse>> uploadAssessmentDetails(HttpServletRequest servletRequest,@PathVariable Long assessmentId,
                                        @RequestPart @Valid String request,@RequestPart(value = "file") MultipartFile file) throws JsonProcessingException {
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentSharePointRequest assessmentSharePointRequest = objectMapper.readValue(request,AssessmentSharePointRequest.class);
        AssessmentSharePointResponse sharePointResponse =assessmentService.uploadAssessmentAttachment(assessmentSharePointRequest,assessmentId,file);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS,
                SuccessMessage.UPLOAD_ASSESSMENT_SUCCESS.getCode(), SuccessMessage.UPLOAD_ASSESSMENT_SUCCESS.getMessage(),
                null,sharePointResponse ));
    }

    @Operation(summary = "Download Assessment",description = "Api to Download Assessment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Assessment downloaded successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/assessments/{assessmentId}/attachment-download")
    public ResponseEntity<Resource> download(HttpServletRequest servletRequest, @PathVariable("assessmentId") Long assessmentId,
                                             @RequestParam int questionNumber, @RequestParam AssessmentCategoryType categoryType) {
        log.info("Assessment Controller::Download Assessment");
        AttachmentDownloadDto downloadedArtifact = assessmentService.getAttachmentDetails(assessmentId,questionNumber,categoryType);
        log.info("Assessment download successfully");
        return ResponseEntity.ok().contentType(MediaType.valueOf(downloadedArtifact.getType())).header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + downloadedArtifact.getName() + "\"") .body((new InputStreamResource(downloadedArtifact.getDownloadedInputStream()) ));
    }

    @Operation(summary = "Delete Assessment Attachment",description = "Api to Delete Assessment Attachment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Assessment attachment deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @DeleteMapping(path = "/assessments/{assessmentId}/attachment-download")
    public ResponseEntity<ResponseDto<String>> deleteAttachment(HttpServletRequest servletRequest, @PathVariable("assessmentId") Long assessmentId,
                                                        @RequestParam int questionNumber, @RequestParam AssessmentCategoryType categoryType){
        log.info("Assessment Controller::Delete assessment attachment");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        assessmentService.deleteAttachment(assessmentId,questionNumber,categoryType,userId);
        log.info("Assessment attachment deleted successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.ASSESSMENT_ATTACHMENT_DELETED.getCode(), SuccessMessage.ASSESSMENT_ATTACHMENT_DELETED.getMessage(), null, null));
    }

    @Operation(summary = "The API is designed to retrieve Assessment Trends details.",description = "Api to Get Assessment Trends details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Get Assessment Trends details"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/assessments/trends")
    public ResponseEntity<ResponseDto<AssessmentTrendsDetailsDto>> fetchTrendsDetails(HttpServletRequest servletRequest,@Valid @RequestBody AssessmentFilterDto assessmentFilterDto,@RequestParam AssessmentRole assessmentRole) throws Exception {
        log.info("AssessmentController::fetchTrendsDetails Start");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentTrendsDetailsDto dashboardDetails = assessmentService.fetchTrendsDetails(userId,assessmentFilterDto,assessmentRole);
        log.info("AssessmentController::fetchTrendsDetails end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ASSESSMENT_TRENDS_DETAILS.getCode(), SuccessMessage.FETCH_ASSESSMENT_TRENDS_DETAILS.getMessage(), null, dashboardDetails));
    }

    @Operation(summary = "Fetch Assessment List by Filter",description = "Api to Get Assessments by Filter")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch Assessment List by Filter Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/assessments/filters")
    public ResponseEntity<ResponseDto<List<AssessmentResponseDto>>> fetchAssessmentFilter(HttpServletRequest servletRequest, @RequestParam AssessmentRole assessmentRole, @RequestBody AssessmentFilterDto assessmentFilterDto){
        log.info("AssessmentController::fetchMyAssessmentFilter:: call started");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        List<AssessmentResponseDto> assessmentResponseDto = assessmentService.fetchAssessments(userId, assessmentRole,assessmentFilterDto);
            log.info("AssessmentController::fetchMyAssessmentFilter:: call ended");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS,
                    SuccessMessage.FETCH_ASSESSMENT_LIST.getCode(), SuccessMessage.FETCH_ASSESSMENT_LIST.getMessage(),
                    null, assessmentResponseDto));
    }

    @Operation(summary = "Save Assessment Draft",description = "Api to Save Assessment Draft")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Assessment saved successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/assessments/{assessmentId}/draft")
    public ResponseEntity<ResponseDto<String>> saveAssessmentDraft(HttpServletRequest servletRequest, @RequestBody AssessmentDraftRequestDto
            assessmentDraftRequestDto, @PathVariable Long assessmentId, @RequestParam String action ) {
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        assessmentService.saveAssessmentDraft(assessmentDraftRequestDto,
                assessmentId,action,userId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS,
                SuccessMessage.SAVE_ASSESSMENT.getCode(), SuccessMessage.SAVE_ASSESSMENT.getMessage(),
                null,null ));
    }
}
