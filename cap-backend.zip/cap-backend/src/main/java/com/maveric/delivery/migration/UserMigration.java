package com.maveric.delivery.migration;

import com.maveric.delivery.service.UserService;
//import io.mongock.api.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

//@ChangeUnit(id = "Users", order = "002", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@AllArgsConstructor
public class UserMigration implements Migration{

    private  final UserService userService;
    //@BeforeExecution
    @Override
    public void before() {
        log.info("Users Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
   // @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("Users Migration RollbackBeforeExecution");
    }

  //  @Execution
    @Override
    public void migrationMethod() throws Exception {
        log.info("mongock migrationMethod");
           userService.refreshUsers();
    }

   // @RollbackExecution
    @Override
    public void rollback() {
        log.info("Users Migration RollbackBeforeExecution");
    }
}
