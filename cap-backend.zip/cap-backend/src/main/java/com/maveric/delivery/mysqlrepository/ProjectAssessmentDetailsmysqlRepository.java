package com.maveric.delivery.mysqlrepository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.maveric.delivery.Entity.ProjectAssessmentDetails;

public interface ProjectAssessmentDetailsmysqlRepository extends JpaRepository<ProjectAssessmentDetails, Long> {
    
    List<ProjectAssessmentDetails> findByNextAssessmentCreationDate(Instant date);
    
    ProjectAssessmentDetails findByAssessmentId(Long id);
    
    ProjectAssessmentDetails findByProjectId(Long id);

    // MySQL equivalent of MongoDB's @Query for finding by remainder dates
    @Query("SELECT p FROM ProjectAssessmentDetails p WHERE p.remainderDate1 = :date OR p.remainderDate2 = :date OR p.remainderDate3 = :date")
    List<ProjectAssessmentDetails> findByRemainderDates(@Param("date") Instant today);

    Optional<ProjectAssessmentDetails> findFirstByProjectIdOrderByNextAssessmentCreationDateDesc(Long projectId);
}
