package com.maveric.delivery.service;

import com.maveric.delivery.Entity.EmailDetails;
import com.maveric.delivery.Entity.SchedulerConfig;
import com.maveric.delivery.mysqlrepository.EmailDetailsmysqlRepository;
import com.maveric.delivery.mysqlrepository.SchedulerConfigmysqlRepository;
import com.maveric.delivery.requestdto.SendEmailDetailsDto;
import com.microsoft.graph.models.*;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import com.microsoft.graph.users.item.sendmail.SendMailPostRequestBody;
import freemarker.template.Configuration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

import static com.maveric.delivery.utils.Constants.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class EmailService {

    private final GraphServiceClient graphServiceClient;
    private final Configuration configuration;

    @Value("${Email.senderId}")
    private String senderId;

    private final SchedulerConfigmysqlRepository schedulerConfigRepository;
    private final EmailDetailsmysqlRepository emailDetailsRepository;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");


    public void send(SendEmailDetailsDto sendEmailDetailsDto) {
        EmailDetails emailDetails = new EmailDetails();
        try {
            SendMailPostRequestBody sendMailPostRequestBody = new SendMailPostRequestBody();
            Message message = prepareMessage(sendEmailDetailsDto);
            sendMailPostRequestBody.setMessage(message);
            emailDetails.setSentTime(System.currentTimeMillis());
            graphServiceClient.users().byUserId(senderId).sendMail().post(sendMailPostRequestBody);
            Map<String,String> map = new HashMap<>();
            if (Objects.nonNull(message.getSubject()))
                map.put("Subject", message.getSubject());
            if (Objects.nonNull(message.getToRecipients()))
                map.put("ToRecipients", message.getToRecipients().stream().map(recipient -> recipient.getEmailAddress().getAddress()).collect(Collectors.joining(",")));
            if (Objects.nonNull(message.getCcRecipients()))
                map.put("CcRecipients", message.getCcRecipients().stream().map(recipient -> recipient.getEmailAddress().getAddress()).collect(Collectors.joining(",")));
            if (Objects.nonNull(message.getBody()))
                map.put("Body", message.getBody().getContent());

            emailDetails.setMessage(map.toString());

            emailDetails.setStatus("Accepted");
            log.info("Email sent successfully to submitter {} and reviewer {}", sendEmailDetailsDto.getEmailId(), sendEmailDetailsDto.getReviewerEmail());
        } catch (Exception e) {
            log.error("Failed to send email: {}", e.getMessage(), e);
            emailDetails.setStatus("Failed");
            emailDetails.setErrorMessage(e.getMessage());
            throw new RuntimeException(e.getMessage());
        } finally {
            if (null != sendEmailDetailsDto.getEmailType()) {
                emailDetails.setType(sendEmailDetailsDto.getEmailType());
            }
            emailDetailsRepository.save(emailDetails);
        }

    }

    public Message prepareMessage(SendEmailDetailsDto sendEmailDetailsDto) {
        try {
            Message message = new Message();
            message.setSubject(sendEmailDetailsDto.getSubject());
            ItemBody body = new ItemBody();
            String content = prepareTemplateData(sendEmailDetailsDto);
            body.setContentType(BodyType.Html);
            body.setContent(content);
            message.setBody(body);
            LinkedList<Recipient> toRecipients = new LinkedList<Recipient>();
            SchedulerConfig schedulerConfig = schedulerConfigRepository.findByKey("enableExternalEmails");
            if (schedulerConfig != null && schedulerConfig.getValue().equalsIgnoreCase("true")) {
                if (sendEmailDetailsDto.getSubject().equalsIgnoreCase(FAILURE_JOB_NOTIFICATION_SUBJECT) || sendEmailDetailsDto.getSubject().equalsIgnoreCase(CREATE_ASSESSMENT_SUBJECT)) {
                    String failureJobRecipients = schedulerConfigRepository.findByKey("supportTeam").getValue();
                    List<String> failureJobRecipientsList = Arrays.asList(failureJobRecipients.split(","));
                    toRecipients = getRecipientsFromList(failureJobRecipientsList);
                } else if (sendEmailDetailsDto.getSubject().equalsIgnoreCase(REVIEW_ASSESSMENT_SUBJECT)
                        && null != sendEmailDetailsDto.getReviewerEmail()) {
                    Recipient recipient2 = new Recipient();
                    EmailAddress emailAddress2 = new EmailAddress();
                    emailAddress2.setAddress(sendEmailDetailsDto.getReviewerEmail());
                    recipient2.setEmailAddress(emailAddress2);
                    toRecipients.add(recipient2);
                } else {
                    /*Recipient recipient1 = new Recipient();
                    EmailAddress emailAddress1 = new EmailAddress();
                    emailAddress1.setAddress(sendEmailDetailsDto.getEmailId());
                    recipient1.setEmailAddress(emailAddress1);*/
                    toRecipients.addAll(getRecipientsFromList(sendEmailDetailsDto.getEmailId()));
                }
            } else {
                String internalTeamRecipients = schedulerConfigRepository.findByKey("internalEmails").getValue();
                List<String> internalTeamRecipientsList = Arrays.asList(internalTeamRecipients.split(","));
                toRecipients = getRecipientsFromList(internalTeamRecipientsList);
            }
            message.setToRecipients(toRecipients);
            return message;
        } catch (Exception e) {
            log.error("Failed to prepare email message: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

    public LinkedList<Recipient> getRecipientsFromList(List<String> emailsList) {
        LinkedList<Recipient> recipientLinkedList = new LinkedList<>();
        for (String email : emailsList) {
            Recipient recipient1 = new Recipient();
            EmailAddress emailAddress1 = new EmailAddress();
            emailAddress1.setAddress(email);
            recipient1.setEmailAddress(emailAddress1);
            recipientLinkedList.add(recipient1);
        }
        return recipientLinkedList;
    }

    public String prepareTemplateData(SendEmailDetailsDto sendEmailDetailsDto) {
        try {
            Map<String, Object> model = new HashMap<>();
            if (null != sendEmailDetailsDto.getUserName()) {
                model.put("user", sendEmailDetailsDto.getUserName());
            }
            if (null != sendEmailDetailsDto.getReviewedBy()) {
                model.put("reviewer", sendEmailDetailsDto.getReviewedBy());
            }
            if (null != sendEmailDetailsDto.getMessage()) {
                model.put("message", sendEmailDetailsDto.getMessage());
            }
            if (null != sendEmailDetailsDto.getProjectName()) {
                model.put("projectname", sendEmailDetailsDto.getProjectName());
            }
            if (null != sendEmailDetailsDto.getAccountName()) {
                model.put("accountname", sendEmailDetailsDto.getAccountName());
            }
            if (null != sendEmailDetailsDto.getProjectType()) {
                model.put("projecttype", sendEmailDetailsDto.getProjectType());
            }
            if (null != sendEmailDetailsDto.getSubmittedOn()) {
                model.put("submittedOn", sendEmailDetailsDto.getSubmittedOn());
            }
            if (null != sendEmailDetailsDto.getUserName()) {
                model.put("submittedBy", sendEmailDetailsDto.getUserName());
            }
            if (null != sendEmailDetailsDto.getReviewOn()) {
                model.put("reviewedOn", sendEmailDetailsDto.getReviewOn());
            }
            if (null != sendEmailDetailsDto.getReviewedBy()) {
                model.put("reviewedBy", sendEmailDetailsDto.getReviewedBy());
            }
            if (null != sendEmailDetailsDto.getDueDate()) {
                model.put("dueon", sendEmailDetailsDto.getDueDate());
            }
            if (sendEmailDetailsDto.getSubject().equalsIgnoreCase(REVIEWED_ASSESSMENT_SUBJECT)) {
                model.put("reviewedByLabel", "Reviewed By");
                model.put("reviewedOnLabel", "Reviewed On");
            }
            if (sendEmailDetailsDto.getSubject().equalsIgnoreCase(RETURNED_ASSESSMENT_SUBJECT)) {
                model.put("reviewedByLabel", "Returned By");
                model.put("reviewedOnLabel", "Returned On");
                model.put("reviewedOn", (Instant.ofEpochMilli(System.currentTimeMillis())
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate().format(dateFormatter)));
            }
            if (sendEmailDetailsDto.getSubject().equalsIgnoreCase(FAILURE_JOB_NOTIFICATION_SUBJECT)) {
                if (null != sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("success")) {
                    model.put("successProjectDetails", sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("success"));
                }
                if (null != sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("failed")) {
                    model.put("failedProjectDetails", sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("failed"));
                }
            }
            if (sendEmailDetailsDto.getSubject().equalsIgnoreCase(CREATE_ASSESSMENT_SUBJECT)) {
                model.put("successProjectDetails", sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("successList"));
                model.put("successCount", sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("successList").size());
                model.put("totalCount", sendEmailDetailsDto.getFailureJobNotificationDetailsMap().get("count").get(0).getCount());
            }
            model.put("deddashboardurl", "DELIVERY EXCELLENCE DASHBOARD");
            return FreeMarkerTemplateUtils.processTemplateIntoString(configuration.getTemplate(sendEmailDetailsDto.getTemplateName()), model);

        } catch (Exception e) {
            log.error("Failed to prepare email template data: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

}