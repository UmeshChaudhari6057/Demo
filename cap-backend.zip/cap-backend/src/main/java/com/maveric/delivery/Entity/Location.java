package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "location")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Location extends IdentifiedEntity {

    @Column(nullable = false, unique = true)
    private String name;
    
    public Location(Long id, String name) {
        super(id); // Assuming IdentifiedEntity has a field `id`
        this.name = name;
    }
}
