package com.maveric.delivery.controller;

import com.maveric.delivery.Entity.ProjectType;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ProjectTypeDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ProjectTypeService;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.maveric.delivery.utils.Constants.FAILED;
import static com.maveric.delivery.utils.Constants.SUCCESS;

@RestController
@Slf4j
@RequestMapping("/v1")
@RequiredArgsConstructor
@Tag(name = "Project Type Management", description = "Endpoints for managing Project Types")
public class ProjectTypeController {

    private final ProjectTypeService projectTypeService;

    @Operation(summary = "Fetch All ProjectType",description = "Api to Fetch All ProjectType")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch All ProjectType Successfully"),
            @ApiResponse(responseCode = "404", description = "ProjectTypes not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/projectTypes")
    public ResponseEntity<ResponseDto<List<BaseDto>>> fetchAllProjectType() {
        log.debug("ProjectTypeController::FetchAllProjectType() started");
        List<BaseDto> projectTypeList = projectTypeService.fetchAllProjectType();
        if (CollectionUtils.isEmpty(projectTypeList)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(FAILED, FailedMessage.FETCH_PROJECTTYPE_FAILED.getCode(), FailedMessage.FETCH_PROJECTTYPE_FAILED.getMessage(),null, projectTypeList));
        }
        log.debug("ProjectTypeController::FetchAllProjectType() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, FailedMessage.FETCH_PROJECTTYPE_FAILED.getCode(), SuccessMessage.FETCH_PROJECT_TYPE.getMessage(),null, projectTypeList));
    }
}
