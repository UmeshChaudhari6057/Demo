package com.maveric.delivery.exception;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.utils.FailedMessage;
import com.microsoft.kiota.ApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.*;

import static com.maveric.delivery.utils.Constants.FAILED;
import static com.maveric.delivery.utils.FailedMessage.*;


@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<ResponseDto> resourceNotFoundException(AccountNotFoundException ex) {
        ErrorMessage errorMessage = new ErrorMessage("Account", ex.getMessage());
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.ACCOUNT_NOT_FOUND.getCode(), FailedMessage.ACCOUNT_NOT_FOUND.getMessage(), Collections.singletonList(errorMessage), null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ProjectNotFoundException.class)
    public ResponseEntity<ResponseDto> projectNotFoundException(ProjectNotFoundException ex) {
        ErrorMessage errorMessage = new ErrorMessage("Project", ex.getMessage());
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.PROJECT_NOT_FOUND.getCode(), FailedMessage.PROJECT_NOT_FOUND.getMessage(), Collections.singletonList(errorMessage), null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(AssessmentException.class)
    public ResponseEntity<ResponseDto> assessmentException(AssessmentException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.BAD_REQUEST.getCode(),
                ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(CustomException.class)
    public ResponseEntity<ResponseDto> assessmentException(CustomException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed",FailedMessage.CUSTOM_EXCEPTION.getCode() ,
                ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        return new ResponseEntity<>(responseDto,  ex.getHttpStatus());
    }

    @ExceptionHandler(ProjectStatusException.class)
    public ResponseEntity<ResponseDto<Void>> projectStatusException(ProjectStatusException ex) {
        ErrorMessage errorMessage = new ErrorMessage("Status", ex.getMessage());

        ResponseDto<Void> responseDto = new ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.PROJECT_STATUS.getCode());
        responseDto.setMessage(FailedMessage.PROJECT_STATUS.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ActiveProjectsFoundException.class)
    public ResponseEntity<ResponseDto<Void>> activeProjectsFoundException(ActiveProjectsFoundException ex) {
        ErrorMessage errorMessage = new ErrorMessage("status",  ex.getMessage());

        ResponseDto<Void> responseDto = new ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.ACTIVE_PROJECT_FOUND.getCode());
        responseDto.setMessage(FailedMessage.ACTIVE_PROJECT_FOUND.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }




    @ExceptionHandler(DuplicateAccountException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<Void>> handleDuplicateAccountException(DuplicateAccountException ex) {
        ErrorMessage errorMessage = new ErrorMessage("Account Name", "Duplicate account name: " + ex.getMessage());

        com.maveric.delivery.responsedto.ResponseDto<Void> responseDto = new com.maveric.delivery.responsedto.ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.EXISTS_ACCOUNT.getCode());
        responseDto.setMessage(FailedMessage.EXISTS_ACCOUNT.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(DuplicateProjectsException.class)
    public ResponseEntity<ResponseDto<Void>> handleDuplicateProjectException(DuplicateProjectsException ex) {
        ErrorMessage errorMessage = new ErrorMessage("Project Name", "Duplicate project name: " + ex.getMessage());

        ResponseDto<Void> responseDto = new ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.EXISTS_PROJECTS.getCode());
        responseDto.setMessage(FailedMessage.EXISTS_PROJECTS.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(ProjectDateException.class)
    public ResponseEntity<ResponseDto<Void>> handleprojectDateException(ProjectDateException ex) {
        ErrorMessage errorMessage = new ErrorMessage("Start date", ex.getMessage());

        ResponseDto<Void> responseDto = new ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.DATE_PROJECTS.getCode());
        responseDto.setMessage(FailedMessage.DATE_PROJECTS.getMessage() +" "+ex.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(DuplicateUserIdException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<Void>> handleDuplicateUserIdException(DuplicateUserIdException ex) {
        ErrorMessage errorMessage = new ErrorMessage("user",  ex.getMessage());
        com.maveric.delivery.responsedto.ResponseDto<Void> responseDto = new com.maveric.delivery.responsedto.ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode("E-1004"); // Using HttpStatus.CONFLICT for duplicate account
        responseDto.setMessage("user already exists");
        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
    }
    @ExceptionHandler(ActiveAccountFoundException.class)
    public ResponseEntity<ResponseDto<Void>> activeAccountFoundException(ActiveAccountFoundException ex) {
        ErrorMessage errorMessage = new ErrorMessage("status",  ex.getMessage());
        ResponseDto<Void> responseDto = new ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.ACTIVE_ACCOUNT_FOUND.getCode());
        responseDto.setMessage(FailedMessage.ACTIVE_PROJECT_FOUND.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(UserRoleException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<Void>> handleUserRoleException(UserRoleException ex) {
        ErrorMessage errorMessage = new ErrorMessage("userRole", ex.getMessage());
        com.maveric.delivery.responsedto.ResponseDto<Void> responseDto = new com.maveric.delivery.responsedto.ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.USER_ROLE_EXCEPTION.getCode());
        responseDto.setMessage(FailedMessage.USER_ROLE_EXCEPTION.getMessage());

        responseDto.setErrorMessage(Collections.singletonList(errorMessage));
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<Void>> handleInternalServerError(Exception ex) {
        ErrorMessage errorMessage = new ErrorMessage("", FailedMessage.INTERNAL_SERVER_ERROR.getMessage() + ex.getMessage());
        log.error("Exception: ", ex);
        com.maveric.delivery.responsedto.ResponseDto<Void> responseDto = new com.maveric.delivery.responsedto.ResponseDto<>();
        responseDto.setStatus("Failed");
        responseDto.setCode(FailedMessage.INTERNAL_SERVER_ERROR.getCode());
        responseDto.setMessage(FailedMessage.INTERNAL_SERVER_ERROR.getMessage());
        responseDto.setErrorMessage(Collections.singletonList(errorMessage));

        return new ResponseEntity<>(responseDto, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<String>> handleNoResourceFoundException(NoResourceFoundException ex) {
        ErrorMessage errorMessage = new ErrorMessage("", FailedMessage.RESOURCE_NOT_FOUND.getMessage() + ex.getMessage());
        com.maveric.delivery.responsedto.ResponseDto<String> errorResponse = new com.maveric.delivery.responsedto.ResponseDto<>();
        errorResponse.setStatus("Failed");
        errorResponse.setCode(FailedMessage.RESOURCE_NOT_FOUND.getCode());
        errorResponse.setMessage(FailedMessage.RESOURCE_NOT_FOUND.getMessage());

        errorResponse.setErrorMessage(Collections.singletonList(errorMessage));

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }


    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ResponseDto> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {
        log.error("HttpMessageNotReadableException:",ex);
        ErrorMessage errorMessage = new ErrorMessage("", API_EXCEPTION.getMessage());
        ResponseDto errorResponse = new ResponseDto("Failed", FailedMessage.VALIDATION_ERROR.getCode(), FailedMessage.VALIDATION_ERROR.getMessage(), Collections.singletonList(errorMessage),null);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ResponseDto> handleIllegalArgumentException(IllegalArgumentException ex) {
        log.error("IllegalArgumentException",ex);
        ErrorMessage errorMessage = new ErrorMessage("", "The request could not be processed. Please check the input and try again.");
        ResponseDto<?> errorResponse = new ResponseDto<>("Failed", FailedMessage.BAD_REQUEST.getCode(), FailedMessage.BAD_REQUEST.getMessage(), Collections.singletonList(errorMessage),null);
        return ResponseEntity.badRequest().body(errorResponse);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseDto> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<ErrorMessage> errorMessages = new ArrayList<>();

        for (FieldError error : bindingResult.getFieldErrors()) {
            String fieldName = error.getField();
            String errorMessage = error.getDefaultMessage();
            ErrorMessage errorMessageObj = new ErrorMessage(fieldName, errorMessage);
            errorMessages.add(errorMessageObj);
        }
       ResponseDto errorResponse = new ResponseDto("Failed", FailedMessage.VALIDATION_ERROR.getCode(), FailedMessage.VALIDATION_ERROR.getMessage(), errorMessages, null);

        return ResponseEntity.badRequest().body(errorResponse);
    }

    @ExceptionHandler(InvalidFormatException.class)
    public ResponseEntity<ResponseDto> handleValidationException(MethodArgumentNotValidException ex) {
        List<ErrorMessage> errors = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> errors.add( new ErrorMessage(error.getField(),error.getDefaultMessage())));

        ResponseDto<String> errorResponse = new ResponseDto<>();
        errorResponse.setStatus(FAILED);
        errorResponse.setCode(VALIDATION_EXCEPTION.getCode());
        errorResponse.setMessage(VALIDATION_EXCEPTION.getMessage());
        errorResponse.setErrorMessage(errors);
        log.error("InvalidFormatException : ", ex);
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(BaseTypeNotFoundException.class)
    public ResponseEntity<ResponseDto> basedTypeNotFoundException(BaseTypeNotFoundException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.TYPE_NOT_FOUND.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())), null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ResponseDto> basedTypeNotFoundException(UserNotFoundException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.USER_NOT_FOUND.getCode(),ex.getMessage(),Collections.singletonList(new ErrorMessage("",ex.getMessage())) ,null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }


    @ExceptionHandler(DataNotFoundException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<String>> handleDataNotFoundException(DataNotFoundException ex) {
        com.maveric.delivery.responsedto.ResponseDto<String> errorResponse = new com.maveric.delivery.responsedto.ResponseDto<>();
        errorResponse.setStatus(FAILED);
        errorResponse.setCode(ex.getCode());
        errorResponse.setMessage(ex.getMessage());
        errorResponse.setErrorMessage(Collections.singletonList(new ErrorMessage("", ex.getMessage())));
        log.error("DataNotFoundException : ", ex);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }

    @ExceptionHandler(PermissionDeniedException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<String>> handlePermissionDeniedException(PermissionDeniedException ex) {
        com.maveric.delivery.responsedto.ResponseDto<String> errorResponse = new com.maveric.delivery.responsedto.ResponseDto<>();
        errorResponse.setStatus(FAILED);
        errorResponse.setCode(PERMISSION_DENIED.getCode());
        errorResponse.setMessage(PERMISSION_DENIED.getMessage());
        log.error("PermissionDeniedException : ", ex);
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(errorResponse);
    }

    @ExceptionHandler(DuplicateKeyException.class)
    public ResponseEntity<com.maveric.delivery.responsedto.ResponseDto<String>> handlePermissionDeniedException(DuplicateKeyException ex) {
        com.maveric.delivery.responsedto.ResponseDto<String> errorResponse = new com.maveric.delivery.responsedto.ResponseDto<>();
        errorResponse.setStatus(FAILED);
        errorResponse.setCode(DUPLICATE_KEY_EXCEPTION.getCode());
        errorResponse.setMessage(DUPLICATE_KEY_EXCEPTION.getMessage());
        errorResponse.setErrorMessage(Collections.singletonList(new ErrorMessage("TeamMember", ex.getMessage())));
        log.error("DuplicateKeyException : ", ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    @ExceptionHandler(TeamMemberNotFoundException.class)
    public ResponseEntity<ResponseDto> teamMemberNotFoundException(TeamMemberNotFoundException ex) {
        ErrorMessage errorMessage = new ErrorMessage("TeamMember", ex.getMessage());
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.MEMBER_NOT_FOUND.getCode(), FailedMessage.MEMBER_NOT_FOUND.getMessage(), Collections.singletonList(errorMessage), null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }



    @ExceptionHandler(MultipleSuperAdminsException.class)
    public ResponseEntity<ResponseDto> basedTypeNotFoundException(MultipleSuperAdminsException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.MULTIPLE_SUPER_ADMINS_EXCEPTION.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(NoOtherUserMappedWithSuperAdminException.class)
    public ResponseEntity<ResponseDto> basedTypeNotFoundException(NoOtherUserMappedWithSuperAdminException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.NO_OTHER_USER_MAPPED_WITH_SUPER_ADMIN_EXCEPTION.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ResponseDto> missingServletRequestParameterException(MissingServletRequestParameterException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.MISSING_SERVLET_REQUEST_PARAMETER_EXCEPTION.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        log.error("MissingServletRequestParameterException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ResponseDto> methodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.METHOD_ARGUMENT_TYPE_MISMATCH_EXCEPTION.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        log.error("MethodArgumentTypeMismatchException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ResponseDto> httpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.HTTP_REQUEST_METHOD_NOT_SUPPORTED_EXCEPTION.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        log.error("HttpRequestMethodNotSupportedException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.METHOD_NOT_ALLOWED);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ResponseDto> missingServletRequestParameterException(MissingRequestHeaderException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.MISSING_REQUEST_HEADER_EXCEPTION.getCode(), ex.getMessage(), Collections.singletonList(new ErrorMessage("",ex.getMessage())),null);
        log.error("MissingRequestHeaderException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ResponseDto> handleValidationException(ValidationException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed",FailedMessage.VALIDATION_EXCEPTION.getCode() ,
                ex.getMessage(), ex.getErrorMessages(),null);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ResponseDto> handleMaxSizeException(MaxUploadSizeExceededException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.MAX_UPLOAD_SIZE_EXCEEDED_EXCEPTION.getCode(), FailedMessage.MAX_UPLOAD_SIZE_EXCEEDED_EXCEPTION.getMessage(), Collections.singletonList(new ErrorMessage("",MAX_UPLOAD_SIZE_EXCEEDED_EXCEPTION.getMessage())),null);
        log.error("MaxUploadSizeExceededException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ResponseDto> handleApiException(ApiException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.API_EXCEPTION.getCode(), FailedMessage.API_EXCEPTION.getMessage(), Collections.singletonList(new ErrorMessage("",API_EXCEPTION.getMessage())),null);
        log.error("ApiException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpClientErrorException.class)
    public ResponseEntity<ResponseDto> handleHttpClientErrorException(HttpClientErrorException ex) {
        ResponseDto<?> responseDto = new ResponseDto<>("Failed", FailedMessage.HTTP_CLIENT_ERROR_EXCEPTION.getCode(), FailedMessage.HTTP_CLIENT_ERROR_EXCEPTION.getMessage(), Collections.singletonList(new ErrorMessage("",HTTP_CLIENT_ERROR_EXCEPTION.getMessage())),null);
        log.error("HttpClientErrorException : ", ex);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }




}