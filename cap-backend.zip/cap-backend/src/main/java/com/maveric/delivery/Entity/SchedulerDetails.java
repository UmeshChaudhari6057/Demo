package com.maveric.delivery.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "scheduler_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SchedulerDetails extends IdentifiedEntity {

    private String name;
    private String traceId;
    private String initiatedType;
    private String initiatedBy;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    private String message;
}


