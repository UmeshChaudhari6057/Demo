package com.maveric.delivery.requestdto;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReviewComments{
    private int questionNumber;
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- \n]+$", message = "Review comment can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    @Size(min = 3,max = 200, message = "Review comment must be between 3 and 200 characters")
    private String reviewComment;
}
