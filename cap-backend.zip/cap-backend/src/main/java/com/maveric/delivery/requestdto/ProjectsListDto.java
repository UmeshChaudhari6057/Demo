package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectsListDto {
    private List<ProjectListResponseDto> projectListResponseDtos;
    @JsonIgnore
    private Set<Long> projectsList;
    private List<String> privileges;
}
