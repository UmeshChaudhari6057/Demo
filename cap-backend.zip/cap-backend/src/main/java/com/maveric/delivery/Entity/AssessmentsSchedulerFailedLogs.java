package com.maveric.delivery.Entity;

import java.time.Instant;

import com.maveric.delivery.model.embedded.ProjectStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "assessments_scheduler_failed_logs")
public class AssessmentsSchedulerFailedLogs extends IdentifiedEntity {
	
    private Long projectId;

    private Instant failedAt;

    private String message;

    @Enumerated(EnumType.STRING)
    private ProjectStatus status;

    @OneToOne(cascade = CascadeType.ALL) // Adjust mapping as needed
    @JoinColumn(name = "project_assessment_details_id", referencedColumnName = "id")
    private ProjectAssessmentDetails projectAssessmentDetails;

    private Boolean isProcessed = false;
}
