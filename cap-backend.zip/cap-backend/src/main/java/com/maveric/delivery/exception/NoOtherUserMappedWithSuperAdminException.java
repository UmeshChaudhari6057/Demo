package com.maveric.delivery.exception;

public class NoOtherUserMappedWithSuperAdminException extends RuntimeException {
    public NoOtherUserMappedWithSuperAdminException(String message) {
        super(message);
    }
}