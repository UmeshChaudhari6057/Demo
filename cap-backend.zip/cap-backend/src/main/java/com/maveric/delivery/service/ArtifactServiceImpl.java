package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.ACCOUNT_ADMIN_;
import static com.maveric.delivery.utils.Constants.ARTIFACTS;
import static com.maveric.delivery.utils.Constants.ARTIFACTS_DELETE;
import static com.maveric.delivery.utils.Constants.ARTIFACTS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.ARTIFACTS_VIEW_ASSOCIATED;
import static com.maveric.delivery.utils.Constants.CREATED_AT;
import static com.maveric.delivery.utils.Constants.DH;
import static com.maveric.delivery.utils.Constants.PROJECT_ID;
import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;
import static com.maveric.delivery.utils.Constants.TYPE;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Criteria;
//import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.exception.ArtifactNotFoundException;
import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.exception.ValidationException;
import com.maveric.delivery.Entity.Artifact;
import com.maveric.delivery.Entity.ArtifactType;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.mysqlrepository.ArtifactmysqlRepository;
import com.maveric.delivery.mysqlrepository.ArtifactTypemysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.requestdto.ArtifactFilterDto;
import com.maveric.delivery.requestdto.ArtifactRequestDto;
import com.maveric.delivery.requestdto.AttachmentDto;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.responsedto.ArtifactListDto;
import com.maveric.delivery.responsedto.AttachmentDownloadDto;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SharepointUtils;
import com.maveric.delivery.utils.UtilMethods;
import com.microsoft.graph.models.DriveItem;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ArtifactServiceImpl implements ArtifactService {

    private final ArtifactmysqlRepository artifactRepository;
    private final ArtifactTypemysqlRepository artifactTypeRepository;
    private final AzureUsermysqlRepository azureUserRepository;
    private final UserServiceImpl userService;
    private final SharepointUtils sharepointUtils;
 //   private final ProjectRepository projectRepository;
    private final UtilMethods utilMethods;
    private final DedRolesRepository dedRolesRepository;
  //  private final MongoTemplate mongoTemplate;
    @Autowired
    private Validator validator;

    @Value("${maveric.de-dashboard.sharepoint.driver.itemId}")
    private String driverItemId;

    @Value("${maveric.de-dashboard.sharepoint.allowedFileFormat}")
    List<String> allowedFileFormat;


    @Override
    public ArtifactListDto saveArtifact(ArtifactRequestDto artifactRequestDto, UUID oid, Long projectId, MultipartFile file) throws IOException {
        log.info("ArtifactServiceImpl::saveArtifact:: call started");
        isValidInput(artifactRequestDto,file);
        checkUserAuthenticity(oid);
        if (StringUtils.isNotBlank(artifactRequestDto.getLink())) {
            log.info("ArtifactServiceImpl::saveArtifact:: call ended");
            return setPropertiesForLink(artifactRequestDto, oid, projectId);
        }
        return uploadArtifactAttachment(artifactRequestDto, projectId, oid,file);
    }

    void isValidInput(ArtifactRequestDto artifactDto, MultipartFile file) {

        Errors errors = new BeanPropertyBindingResult(artifactDto, ArtifactRequestDto.class.getName());
        ValidationUtils.invokeValidator(validator, artifactDto, errors);
        List<ErrorMessage> errorMessages = new ArrayList<>();
        if (errors.hasFieldErrors()) {
            errors.getFieldErrors().forEach(fieldError -> errorMessages.add(new ErrorMessage(fieldError.getField(), fieldError.getDefaultMessage())));

            throw new ValidationException(FailedMessage.VALIDATION_EXCEPTION.getMessage(), errorMessages);

        }
        if (StringUtils.isBlank(artifactDto.getLink()) && file == null) {
            throw new IllegalArgumentException("Either attachment or link should be available in the request ");
        }
        if (StringUtils.isNotBlank(artifactDto.getLink()) && file != null) {
            throw new IllegalArgumentException("Either attachment or link should be available in the request ");
        }
    }


    String getUserName(UUID oid) {
        log.info("ArtifactServiceImpl::getUserName:: call started");
        String username = null;
        List<UserDto> userDtoList = userService.getAllUsers();
        for (UserDto user : userDtoList) {
            if (user.getOid().equals(oid)) {
                username = user.getName();
                break;
            }
        }
        if (username == null) {
            throw new IllegalArgumentException("No data for given UserId");
        }
        return username;
    }

    @Override
    public List<ArtifactListDto> getAllArtifacts(UUID userId, Long projectId, ArtifactFilterDto filter) {
//        log.info("ArtifactServiceImpl::getAllArtifacts:: call started");
//        checkUserAuthenticity(userId);
//        List<ArtifactListDto> artifactListDto = new ArrayList<>();
//        Optional<Project> project = projectRepository.findById(projectId);
//        Criteria criteria = new Criteria();
//        List<Criteria> criteriaList=new ArrayList<>();
//
//        if (project.isEmpty()) {
//            log.error("ArtifactServiceImpl::getAllArtifacts :: Project id not found");
//            throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
//        }
//        String highestRole = userService.getHighestRole(userId, null, null);
//        List<String> privileges = utilMethods.getPrivilegesString(highestRole, List.of(ARTIFACTS));
//        if (highestRole.equalsIgnoreCase(SUPER_ADMIN_) || privileges.contains(ARTIFACTS_VIEW_ALL)) {
//            criteria.and(PROJECT_ID).is(projectId);
//        }else {
//            String projectLevelHighestRole = userService.getHighestRole(userId, project.get().getAccountId(), projectId);
//            if (!projectLevelHighestRole.isBlank()) {
//                List<String> privilegesProjectLevel = utilMethods.getPrivilegesString(projectLevelHighestRole, List.of(ARTIFACTS));
//                if (privilegesProjectLevel.contains(ARTIFACTS_VIEW_ASSOCIATED)) {
//                    List<DedRolesmy> dedRoles = dedRolesRepository.findByOidAndProject_Id(userId, projectId);//checking if I'm associated to that project or not.
//                    if (!dedRoles.isEmpty()) {
//                        criteria.and(PROJECT_ID).is(projectId);
//                    }else {
//                        return artifactListDto;
//                    }
//                }
//            }else {
//                return artifactListDto;
//            }
//        }
//
//        if (filter.getType() != null && !filter.getType().isEmpty()) {
//            criteriaList.add( Criteria.where(TYPE).in(filter.getType()));
//
//        }
//        if(filter.getStartDate()!=0 && filter.getEndDate()!=0 ){
//            criteriaList.add(Criteria.where(CREATED_AT).gte(filter.getStartDate()).lte(filter.getEndDate()));
//        } else  if(filter.getStartDate()!=0 ){
//            criteriaList.add(Criteria.where(CREATED_AT).gte(filter.getStartDate()));
//        }else if( filter.getEndDate()!=0 ){
//            criteriaList.add(Criteria.where(CREATED_AT).lte(filter.getEndDate()));
//        }
//
//
//        if(!criteriaList.isEmpty())
//        {
//            criteria.orOperator(criteriaList);
//        }
//        Query query = new Query(criteria);
//        if(StringUtils.isNotBlank(filter.getSortBy())){
//            utilMethods.isValidField(Artifact.class,filter.getSortBy());
//            query.with(Sort.by(Sort.Direction.DESC, filter.getSortBy()));
//        }else {
//            query.with(Sort.by(Sort.Direction.DESC, CREATED_AT));
//        }
//
//        List<Artifact> artifactList = mongoTemplate.find(query, Artifact.class);
//
//        if (artifactList.isEmpty()) {
//            return artifactListDto;
//        }
//        log.info("ArtifactServiceImpl::getAllArtifacts:: call ended");
//        artifactListDto = toArtifactListDtosList(artifactList, userId,project.get());
//        return artifactListDto;
    	return new ArrayList<ArtifactListDto>();

    }

    public String getDisplayName(UUID oid) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(oid);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }

    void checkUserAuthenticity(UUID userId) {
        String userName = getDisplayName(userId);
        if (null == userName
                || userName.isEmpty()) {
            log.error("ArtifactServiceImpl::User not found");
            throw new UserNotFoundException(":User not found " + userId);
        }
    }


    @Override
    public AttachmentDownloadDto getAttachmentDetails(Long artifactId, UUID oid) {
        Optional<Artifact> artifacts = artifactRepository.findById(artifactId);
        userService.getHighestRole(oid, null, artifacts.get().getProjectId());
        if (artifacts.isEmpty()) {
            log.error("ArtifactServiceImpl::validateProjectName:: artifacts not found");
            throw new ArtifactNotFoundException("Account ID " + artifacts + " not found");
        }
        Artifact artifact = artifacts.get();
        
       // if(artifact.getAttachment()==null) // previous mongo code
        //MySql Migration
        	if((artifact.getAttachmentSharepointId() == null || artifact.getAttachmentName() == null))
        {
            throw new IllegalArgumentException("No file uploaded in sharepoint for this artifact");
        }
        AttachmentDownloadDto attachmentDownloadDto = new AttachmentDownloadDto();
        //previous mongo code
     //   attachmentDownloadDto.setName(artifact.getAttachment().getName());
     //   attachmentDownloadDto.setType(artifact.getAttachment().getType());
        //MySql Migration code
        attachmentDownloadDto.setName(artifact.getAttachmentName());
        attachmentDownloadDto.setType(artifact.getAttachmentType());
       //Mongo code
        //attachmentDownloadDto.setDownloadedInputStream(sharepointUtils.downloadFile(artifact.getAttachment().getSharepointId()));
      
        //mysql
        attachmentDownloadDto.setDownloadedInputStream(sharepointUtils.downloadFile(artifact.getAttachmentSharepointId()));
        
        return attachmentDownloadDto;

    }

    @Override
    public void checkAndDeleteAttachment(UUID userId, Long artifactId) {
///      Mongo db code commented
//        Optional<Artifact> artifacts = artifactRepository.findById(artifactId);
//        if (artifacts.isEmpty()) {
//            log.error("ArtifactServiceImpl::validateProjectName:: artifacts not found");
//            throw new ArtifactNotFoundException("Account ID " + artifacts + " not found");
//        }
//  //      Optional<Project> project = projectRepository.findById(artifacts.get().getProjectId());
////        if (project.isEmpty()) {
////            log.error("ArtifactServiceImpl::validateProjectName:: artifacts not found");
////            throw new ProjectNotFoundException("project ID " + project + " not found");
////        }
//       if(Boolean.TRUE.equals(checkToDeletePrivilege(userId,project.get(),artifacts.get()))){
//            if(artifacts.isEmpty()){
//                log.error("ArtifactServiceImpl::validateProjectName:: artifacts not found");
//                throw new ArtifactNotFoundException("Account ID "+artifacts+" not found");
//            }
//            Artifact artifact = artifacts.get();
//            
//            //mongo
////            if(artifact.getAttachment()!=null){
////                sharepointUtils.deleteFile(artifacts.get().getAttachment().getSharepointId());
////                artifactRepository.deleteById(artifactId);
////
////            }
//            if(artifact.getAttachmentSharepointId() == null || artifact.getAttachmentName() == null){
//               sharepointUtils.deleteFile(artifacts.get().getAttachmentSharepointId());
//               artifactRepository.deleteById(artifactId);
//
//          }
//            else{
//                artifactRepository.deleteById(artifactId);
//
//            }
//
//        } else {
//            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
//        }
    }

    public Boolean checkToDeletePrivilege(UUID userId,Project project,Artifact artifact ) {
        String highestRole = userService.getHighestRole(userId, project.getAccountId(), artifact.getProjectId());
        List<String> privileges = utilMethods.getPrivilegesString(highestRole, List.of(ARTIFACTS));
        if (highestRole.equalsIgnoreCase(SUPER_ADMIN_)
                ||(dedRolesRepository.existsByOidAndAccount_IdAndRole(userId, project.getAccountId(), DH)
                && utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(ARTIFACTS)).contains(ARTIFACTS_DELETE))||privileges.contains(ARTIFACTS_DELETE)) {
            return true;
        }
        else return false;
    }

    private boolean userHasDeleteAccess(UUID userId) {
        return true;
    }

    private List<ArtifactListDto> toArtifactListDtosList(List<Artifact> artifacts, UUID userId,Project project) {
        return artifacts.stream()
                .map(artifact -> toArtifactListDto(artifact, userId,project))
                .toList();
    }

    ArtifactListDto toArtifactListDto(Artifact artifact, UUID userId,Project project) {
        ArtifactListDto dto = new ArtifactListDto();
        AttachmentDto attachmentDto = new AttachmentDto();
        if (artifact.getAttachmentSharepointId() == null || artifact.getAttachmentName() == null)
            attachmentDto.setName(artifact.getName());
        dto.setId(artifact.getId());
        dto.setName(artifact.getName());
        dto.setType(artifact.getType());
        dto.setAttachment(attachmentDto);
        dto.setLink(artifact.getLink());
        dto.setComments(artifact.getComments());
        dto.setCreatedAt(artifact.getCreatedAt());
        dto.setCreatedBy(artifact.getCreatedBy());
        dto.setCreatorName(artifact.getCreatorName());
        if (Boolean.TRUE.equals(checkToDeletePrivilege(userId,project,artifact))) {
            dto.setIsDelete(true);
        } else {
            dto.setIsDelete(false);
        }
        return dto;
    }


    public ArtifactListDto setResponse(Artifact artifactResponse, ArtifactListDto responseDto) {
        AttachmentDto attachmentDto = new AttachmentDto();
        attachmentDto.setName(artifactResponse.getName());

        attachmentDto.setType(artifactResponse.getAttachmentType());
        responseDto.setAttachment(attachmentDto);
        responseDto.setComments(artifactResponse.getComments());
        responseDto.setName(artifactResponse.getName());
        responseDto.setType(artifactResponse.getType());
        responseDto.setId(artifactResponse.getId());
        responseDto.setCreatedBy(artifactResponse.getCreatedBy());
        responseDto.setCreatorName(artifactResponse.getCreatorName());
        responseDto.setCreatedAt(artifactResponse.getCreatedAt());
        return responseDto;

    }

    public ArtifactListDto setPropertiesForLink(ArtifactRequestDto artifactRequestDto, UUID oid, Long projectId) {
        Artifact artifact = new Artifact();
        BeanUtils.copyProperties(artifactRequestDto, artifact);
        checkTypeExists(artifactRequestDto.getType());
        artifact.setCreatedAt(System.currentTimeMillis());
        artifact.setCreatorName(getUserName(oid));
        artifact.setCreatedBy(oid);
        artifact.setProjectId(projectId);
        Artifact artifactResponse;
        ArtifactListDto responseDto = new ArtifactListDto();
        artifactResponse = artifactRepository.save(artifact);
        BeanUtils.copyProperties(artifactResponse, responseDto);
        return responseDto;
    }
    public void checkTypeExists(String type){
          if(!artifactTypeRepository.existsByName(type)){
              ArtifactType artifactType=new ArtifactType();
              artifactType.setName(type);
              artifactTypeRepository.save(artifactType);
          }
    }

    public ArtifactListDto uploadArtifactAttachment(ArtifactRequestDto request, Long projectId, UUID oid, MultipartFile file) throws IOException {
    // Mongo commented code
    	
    	//        Optional<Project> projectOptional = projectRepository.findById(projectId);
//        if (projectOptional.isPresent()) {
//            Project project = projectOptional.get();
//            if (StringUtils.isBlank(project.getProjectDriverId())) {
//                DriveItem driveItem = sharepointUtils.createFolder(String.valueOf(projectId), driverItemId);
//                project.setProjectDriverId(driveItem.getId());
//                driveItem = getArtifactDriveItem(driveItem, project);
//                return validateAndUploadArtifactAttachment(request, driveItem, projectId, oid,file);
//            } else {
//                DriveItem driveItem = new DriveItem();
//                if (StringUtils.isBlank(project.getArtifactDriverId())) {
//                    driveItem = getArtifactDriveItem(driveItem, project);
//                    return validateAndUploadArtifactAttachment(request, driveItem, projectId, oid,file);
//                } else {
//                    driveItem.setId(project.getArtifactDriverId());
//                    return validateAndUploadArtifactAttachment(request, driveItem, projectId, oid,file);
//                }
//            }
//        } else {
//            log.info("Project not found for " + projectId);
//            throw new ProjectNotFoundException("Project not found");
//        }

    	
    	return new ArtifactListDto();
    }

    private ArtifactListDto validateAndUploadArtifactAttachment(ArtifactRequestDto artifactRequestDto, DriveItem driveItem, Long projectId, UUID oid, MultipartFile file) throws IOException {
        int index= Objects.requireNonNull(file.getOriginalFilename()).lastIndexOf('.');
        if(index==-1 || index==0)
            throw new IllegalArgumentException("No extension found or file name starts with a dot");
        String attachmentName= Objects.requireNonNull(file.getOriginalFilename()).substring(index);
        checkAllowedFileFormat(attachmentName);
        String fileName=artifactRequestDto.getName()+"_"+file.getOriginalFilename().replace(attachmentName,"")+"_"+System.currentTimeMillis()+attachmentName;
        ResponseEntity<DriveItem> response =sharepointUtils.uploadFile(file.getContentType(),fileName,file.getBytes(),driveItem.getId());
        if(response.getStatusCode().is2xxSuccessful()){
            Artifact artifact = new Artifact();
       //     Attachment attachment=new Attachment();
//            attachment.setName(file.getOriginalFilename());
//            attachment.setType(file.getContentType());
//            attachment.setSharepointId(Objects.requireNonNull(response.getBody()).getId());
            
         // ✅ Set attachment fields directly
            artifact.setAttachmentName(file.getOriginalFilename());
            artifact.setAttachmentType(file.getContentType());
            artifact.setAttachmentSharepointId(Objects.requireNonNull(response.getBody()).getId());
         //   artifact.setAttachmentLink(sharepointUtils.generateDownloadLink(response.getBody().getId()));
            artifact.setCreatedAt(System.currentTimeMillis());
            artifact.setCreatorName(getUserName(oid));
            artifact.setCreatedBy(oid);
            artifact.setName(artifactRequestDto.getName());
            artifact.setType(artifactRequestDto.getType());
           // artifact.setAttachment(attachment);
            artifact.setProjectId(projectId);
            artifact.setComments(artifactRequestDto.getComments());
            Artifact artifactResponse;
            checkTypeExists(artifactRequestDto.getType());
            ArtifactListDto responseDto=new ArtifactListDto();
            artifactResponse=artifactRepository.save(artifact);
            responseDto= setResponse(artifactResponse,responseDto);
            log.info("ArtifactServiceImpl::saveArtifact:: call ended");
            return responseDto;
        }
        else throw new FileNotFoundException("File not saved");



    }

    private void checkAllowedFileFormat(String fileExtension){
        if(!allowedFileFormat.contains(fileExtension.toLowerCase()))
            throw new CustomException("Invalid file format.",HttpStatus.BAD_REQUEST);
    }

    private DriveItem getArtifactDriveItem(DriveItem driveItem, Project project) {
//        driveItem.setId(project.getProjectDriverId());
//        driveItem = sharepointUtils.createFolder("Artifacts", driveItem.getId());
//        project.setArtifactDriverId(driveItem.getId());
//        projectRepository.save(project);
//        return driveItem;
    	return new DriveItem();
    }

}


