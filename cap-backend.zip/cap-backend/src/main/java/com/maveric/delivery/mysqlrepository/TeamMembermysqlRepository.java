package com.maveric.delivery.mysqlrepository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.TeamMember;

public interface TeamMembermysqlRepository extends JpaRepository<TeamMember, Long> {

    List<TeamMember> findByProjectId(Long projectId);

    List<TeamMember> findByProjectIdIn(List<Long> projectId);

    Boolean existsByUserIdAndProjectId(UUID userId, Long projectId);
}
