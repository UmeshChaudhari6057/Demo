package com.maveric.delivery.Entity;

import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.maveric.delivery.Entity.IdentifiedEntity;

import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "audit")
@Entity
public class Audit extends IdentifiedEntity {
    private String username;
    private String methodName;
    private String status;
    private UUID oid;
    private String traceId;
    private String action;
    private String auditEntity;
    private String requestUrl;
    private String errorMessage;
    private LocalDateTime timestamp;
}