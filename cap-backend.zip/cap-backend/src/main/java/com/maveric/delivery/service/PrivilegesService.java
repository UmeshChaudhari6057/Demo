package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.PrivilegesDetailsDto;

import java.util.List;

public interface PrivilegesService {

    List<PrivilegesDetailsDto> getPrivileges();
}
