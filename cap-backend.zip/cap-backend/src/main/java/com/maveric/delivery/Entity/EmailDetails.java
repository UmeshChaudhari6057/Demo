package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "email_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailDetails extends IdentifiedEntity {

    @Column(nullable = false)
    private String type;

    @Column(columnDefinition = "TEXT")
    private String message;

    @Column(nullable = false)
    private String status;

    private Long sentTime;

    private String errorMessage;
}
