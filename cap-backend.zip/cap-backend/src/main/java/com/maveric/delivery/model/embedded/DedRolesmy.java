package com.maveric.delivery.model.embedded;

import java.util.UUID;

import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.IdentifiedEntity;
import com.maveric.delivery.Entity.Project;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;


@Entity
@Table(name = "ded_roles", indexes = {
        @Index(name = "idx_oid", columnList = "oid", unique = true),
        @Index(name = "idx_account_id", columnList = "account_id"),
        @Index(name = "idx_project_id", columnList = "project_id")
})
@Data
@NoArgsConstructor 
public class DedRolesmy extends IdentifiedEntity {


    @Column(nullable = false, unique = true)
    private UUID oid;

    @ManyToOne
    @JoinColumn(name = "account_id", referencedColumnName = "id")
    private Account account;

    @ManyToOne
    @JoinColumn(name = "project_id", referencedColumnName = "id")
    private Project project;

    private String name;

    @Column(nullable = false)
    private String role;
    
    
    public Long getAccountId() {
        return account != null ? account.getId() : null;
    }

    
    public Long getProjectId() {
        return project != null ? project.getId() : null;
    }
   

    public void setProjectId(Long projectId) {
        if (this.project == null) {
            this.project = new Project(); // Create a new Project if null
        }
        this.project.setId(projectId);
    }
    
    public void setAccountId(Long accountId) {
        if (this.account == null) {
            this.account = new Account(); // Create a new Project if null
        }
        this.account.setId(accountId);
    }

    public DedRolesmy(UUID oid, Long accountId, Long projectId, String name, String role) {
        this.oid = oid;
        this.account = (accountId != null) ? new Account(accountId) : null;
        this.project = (projectId != null) ? new Project(projectId) : null;
        this.name = name;
        this.role = role;
    }


	

}