package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.TemplateStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssessmentTemplateResponseDto {
    private String assessmentType;
    private String templateName;
    private Long templateId;
    private String projectType;
    private TemplateStatus status;
    private String description;
    private Long createdOn;
    private Long editedOn;
    private int utilizedProjects;
}
