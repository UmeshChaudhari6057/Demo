package com.maveric.delivery.Entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "roles")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Roles extends IdentifiedEntity {

    private String name;
    private String description;

    @ElementCollection
    @Column(name = "group_name")
    private List<String> group;

    private int hierarchy;
}
