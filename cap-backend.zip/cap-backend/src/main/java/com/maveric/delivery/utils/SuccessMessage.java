package com.maveric.delivery.utils;

public enum SuccessMessage {

    ACCOUNT_CREATED("S-1000", "Account created successfully"),
    FETCH_ACCOUNTS("S-1001", "Accounts Fetched successfully"),
    FETCH_ACCOUNTS_COUNT("S-1002", "Accounts count fetched successfully"),
    FETCH_ACCOUNT("S-1003", "Account Fetched successfully"),
    UPDATE_ACCOUNT_DETAILS("S-1004", "Account details updated successfully"),
    AVAILABLE_ACCOUNT("S-1005", "Account name available : "),
    FETCH_COUNTRIES("S-1006", "Countries Fetched successfully"),

    PROJECT_TYPE_CREATED("S-1007", "ProjectType created successfully"),
    FETCH_PROJECT_TYPE("S-1008", "ProjectType Fetched successfully"),
    UPDATE_PROJECT_DETAILS("S-1004", "Project details updated successfully"),

    FETCH_PROJECT("S-1011", "Project Fetched successfully"),
    PROJECT_NAME_EXIST("S-1012", "Project Name is available"),
    DUPLICATE_PROJECT_NAME("S-1013", "Project Name is already exist"),
    FETCH_PROJECT_MEMBERS("S-1014","Project Members list Fetch successfully for filter"),
    FETCH_PROJECT_NAMES("S-1015","Project Names fetched successfully"),
    FETCH_TYPE("S-1101"," Type Fetched successfully"),
    FETCH_ACCOUNT_MEMBERS("S-1102","Account Members fetched successfully"),
    FETCHED_PROJECT_STATUS("S-1103","Project Status fetched successfully"),
    FETCHED_ASSESSMENT_TEMPLATES("S-1104","Assessment Templates fetched successfully"),
    FETCHED_ASSESSMENT_TEMPLATE("S-1105","Template fetched successfully"),

    PROJECT_CREATED("S-1009", "Project created successfully"),
    PROJECT_LIST_FETCHED("S-1010", "Project List fetched successfully"),
    SAVE_PROJECT_ROLE("S-1010", "ProjectRole saved successfully"),
    SAVE_ARTIFACT_TYPE("S-1011", "Artifact type saved successfully"),
    SAVE_LOCATION("S-1012", "Location saved successfully"),

    ARTIFACT_CREATED("S-1105", "Artifact created successfully"),
    FETCHED_ACCOUNT_STATUS("S-1106", "Account Status fetched successfully"),

    ARTIFACT_LIST_FETCHED("S-1011", "Artifact list fetched successfully"),

    ARTIFACT_DELETED("S-1012", "Artifact deleted successfully"),

    FETCH_ASSESSMENT("S-2001", "Assessment fetched successfully"),
    SAVE_ASSESSMENT("S-2002", "Assessment saved successfully"),
    FETCH_ASSESSMENT_LIST("S-2003", "Assessment list fetched successfully"),
    UPLOAD_ASSESSMENT_SUCCESS("S-2004", "Attachment upload successfully"),
    ASSESSMENT_ATTACHMENT_DELETED("S-2005","Assessment attachment deleted successfully"),
    SUBMIT_ASSESSMENT("S-2006", "Assessment saved/submit successfully"),
    REVIEW_ASSESSMENT("S-2007", "Assessment saved/reviewed successfully"),

    ROLE_PRIVILEGES_SAVE("S-1020", "Privileges saved successfully"),
    ROLE_PRIVILEGES_FETCHED("S-1021", "Privileges fetched successfully"),

    ROLES_FETCHED("S-1022", "Roles fetched successfully"),

    TEAM_MEMBERS_SKILLS("S-1029","Team Members Skill set fetched successfully."),
    TEAM_MEMBER_CREATED("S-1030", "TeamMember created successfully"),
    TEAM_MEMBER_LIST_FETCHED("S-1031", "Team Member list fetched successfully"),
    FETCH_TEAM_MEMBER("S-1032", "Team Member Fetched successfully"),
    UPDATE_TEAM_MEMBER_DETAILS("S-1033", "Team Member details updated successfully"),

    ACCOUNT_FILTER_MEMBERS_FETCHED("S-1034", "Account filter members fetched successfully"),
    ACCOUNT_LIST_FETCHED("S-1035", "Account List fetched successfully"),

    FETCH_DASHBOARD_DETAILS("S-1030", "Dashboard Details Fetched successfully"),
    FETCH_DASHBOARD_TRENDS_DETAILS("S-1031", "Dashboard Trends Details Fetched successfully"),
    FETCH_TOP_ASSESSMENT_DETAILS("S-1032", "Top Assessment Details Fetched successfully"),
    FETCH_ACTIVE_ACCOUNTS_DETAILS("S-1033", "Active Accounts Details Fetched successfully"),
    FETCH_ACTIVE_PROJECTS_DETAILS("S-1034", "Active Projects Details Fetched successfully"),
    CREATE_TEMPLATE("S-2102", "Template created successfully"),
    EDIT_TEMPLATE("S-2103", "Template edited successfully"),
    FETCH_ASSESSMENT_TRENDS_DETAILS("S-1035", "Assessment Trends Details Fetched successfully"),

    DUPLICATE_TEMPLATE_NAME("S-2104","Template name already exist : "),
    TEMPLATE_NAME_AVAILABLE("S-2105","Template name available : "),
    SAVE_PROJECT_TYPE("S-2106","Project type saved successfully"),
    ROLES_ASSIGN_SUCCESSFULLY("S-4001","Roles Assigned Successfully"),
    ROLES_ASSIGN_PARTIALLY("PS-4003","Roles assign partially successfully"),
    FETCH_USER_ROLES("S-4004","User role fetched successfully"),
    UPDATE_USER_ROLES("S-4005","User role updated successfully"),
    DELETE_USER_ROLES("S-4006","User role deleted successfully"),
    CREATE_ASSESSMENTS_JOB_SUCCESSFUL("S-6000","Create assessments and status change job is processed successfully"),
    FAILED_PROJECTS_JOB_SUCCESSFUL("S-6001","Failed projects job processed successfully"),
    SEND_REMAINDER_MAILS_SUCCESSFUL("S-6002","Remainder mails job processed successfully"),
    META_DATA_SUCCESSFUL("S-6003","Configuration updated successfully"),
    UPDATE_PROJECT_STATUS_SUCCESSFUL("S-6003","Projects with enddate as today,moved to inactive"),
    SAVE_DELIVERY_IMPACT("S-7001","Delivery impact saved successfully"),
    FETCH_DELIVERY_IMPACT("S-7002","Delivery impact fetch successfully"),
    REFRESH_USERS_JOB_SUCCESSFUL("S-6004","Refresh users job processed successfully"),


    ;
    private final String code;
    private final String message;

    SuccessMessage(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static SuccessMessage fromCode(String code) {
        for (SuccessMessage successMessage : SuccessMessage.values()) {
            if (successMessage.code == code) {
                return successMessage;
            }
        }
        throw new IllegalArgumentException("Invalid error code");
    }

    @Override
    public String toString() {
        return "SuccessMessage{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}
