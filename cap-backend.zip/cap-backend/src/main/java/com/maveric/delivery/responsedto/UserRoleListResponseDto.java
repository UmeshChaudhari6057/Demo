package com.maveric.delivery.responsedto;

import lombok.Data;

import java.util.List;

/**
 * @author ankushk
 */
@Data
public class UserRoleListResponseDto {

    Long id;
    String user;
    String role;
    List<AdditionalRoleDto> additionalRoles;
}