package com.maveric.delivery.Entity;

import java.util.List;
import java.util.Set;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.Entity.Question;
import com.maveric.delivery.model.embedded.TemplateStatus;


import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "assessment_templates")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssessmentTemplate extends IdentifiedEntity {

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AssessmentCategoryType assessmentType;

    @Column(nullable = false, unique = true)
    private String templateName;

    private String projectType;

    @Enumerated(EnumType.STRING)
    private TemplateStatus status;

    @Column(columnDefinition = "TEXT")
    private String description;

    @OneToMany(mappedBy = "assessmentTemplate", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Question> questions;  // ✅ `mappedBy` matches the variable in `MyQuestion`

    private Long createdOn;
    private Long editedOn;

    @ElementCollection
    @CollectionTable(name = "assessment_template_utilized_projects", 
                     joinColumns = @JoinColumn(name = "assessment_template_id"))
    @Column(name = "project_id")
    private Set<Long> utilizedProjects;
}
