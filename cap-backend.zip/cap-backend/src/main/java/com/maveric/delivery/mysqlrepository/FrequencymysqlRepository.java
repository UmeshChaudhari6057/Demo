package com.maveric.delivery.mysqlrepository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.Frequency;

public interface FrequencymysqlRepository extends JpaRepository<Frequency,Long> {
    Frequency findByName(String name);
}