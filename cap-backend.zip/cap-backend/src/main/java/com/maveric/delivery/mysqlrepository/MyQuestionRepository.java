package com.maveric.delivery.mysqlrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.Question;
import com.maveric.delivery.model.embedded.TemplateCategory;

public interface MyQuestionRepository extends JpaRepository<Question, Long> {
   
}                     
