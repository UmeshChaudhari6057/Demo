package com.maveric.delivery.migration;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.delivery.Entity.Roles;
import com.maveric.delivery.mysqlrepository.RolePrivilegesmysqlRepository;
import com.maveric.delivery.mysqlrepository.RolesmysqlRepository;
import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.RolePrivileges;
import com.maveric.delivery.utils.JsonFileReader;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

//@ChangeUnit(id = "Roles-v.0.1", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@Service
@AllArgsConstructor
public class RolesMigration implements Migration {

	// private final MongoTemplate mongoTemplate;

	private final RolesmysqlRepository rolesmysqlRepository;

	private final JsonFileReader jsonFileReader;

	private final String filePath = "/migration/data/roles.json";

	@Override
	public void before() {
		log.info("Roles Migration BeforeExecution");
	}

	// Note this method / annotation is Optional

	@Override
	public void rollbackBefore() {
		log.info("Roles Migration RollbackBeforeExecution");
	}

	@Transactional
	@Override
	public void migrationMethod() throws IOException {
		log.info("mongock migrationMethod");
//        mongoTemplate.remove(new Query(), Roles.class);
//        List<Roles> roles= jsonFileReader.readJsonFileToList(filePath, Roles.class);
//            mongoTemplate.insertAll(roles);

		try {
			List<Roles> roles = jsonFileReader.readJsonFileToList(filePath, Roles.class);

			if (!roles.isEmpty()) {
				rolesmysqlRepository.saveAll(roles);
				log.info("Migration completed: {} records inserted", roles.size());
			} else {
				log.info("No data found to migrate.");
			}
		} catch (IOException e) {
			log.error("Error reading JSON file for migration", e);
			throw new RuntimeException("Migration failed! Rolling back...");
		}

	}

	@Override
	public void rollback() {
		log.info("Roles Migration RollbackBeforeExecution");
		rolesmysqlRepository.deleteAll();
	}
}
