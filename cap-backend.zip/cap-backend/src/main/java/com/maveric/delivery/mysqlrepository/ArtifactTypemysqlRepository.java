package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.ArtifactType;

public interface ArtifactTypemysqlRepository extends JpaRepository<ArtifactType,Long>{
	boolean existsByName(String Type);
}
