package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.ProjectStatus;
import com.maveric.delivery.mysqlrepository.ProjectStatusmysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "ProjectStatus", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@Service
@AllArgsConstructor
public class ProjectStatusMigration implements Migration {

	private final ProjectStatusmysqlRepository projectStatusmysqlRepository;

	private final JsonFileReader jsonFileReader;

	private final String filePath = "/migration/data/project-status.json";

	@Override
	public void before() {
		log.info("ProjectStatus Migration BeforeExecution");
	}

	// Note this method / annotation is Optional

	@Override
	public void rollbackBefore() {
		log.info("ProjectStatus Migration RollbackBeforeExecution");
	}

	@Transactional
	@Override
	public void migrationMethod() throws IOException {
		log.info("ProjectStatus migrationMethod");
//        List<ProjectStatus> projectStatuses= jsonFileReader.readJsonFileToList(filePath, ProjectStatus.class);
//        mongoTemplate.insertAll(projectStatuses);

		try {
			List<ProjectStatus> projectStatuses = jsonFileReader.readJsonFileToList(filePath, ProjectStatus.class);

			if (!projectStatuses.isEmpty()) {
				projectStatusmysqlRepository.saveAll(projectStatuses);
				log.info("Migration completed: {} records inserted", projectStatuses.size());
			} else {
				log.info("No data found to migrate.");
			}
		} catch (IOException e) {
			log.error("Error reading JSON file for migration", e);
			throw new RuntimeException("Migration failed! Rolling back...");
		}

	}

	@Override
	public void rollback() {
		log.info("ProjectStatus Migration RollbackBeforeExecution");
		projectStatusmysqlRepository.deleteAll();
	}
}
