package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.Location;

public interface LocationmysqlRepository extends JpaRepository<Location, Long> {
    boolean existsByNameIgnoreCase(String location);
}
