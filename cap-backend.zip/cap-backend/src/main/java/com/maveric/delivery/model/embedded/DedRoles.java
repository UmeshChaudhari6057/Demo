package com.maveric.delivery.model.embedded;

import com.maveric.delivery.Entity.IdentifiedEntity;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
//@Document(collection = "dedRoles")
public class DedRoles extends IdentifiedEntity {

    @NotNull
  //  @Indexed
    private UUID oid;
  //  @Indexed
    private Long accountId;
   // @Indexed
    private Long projectId;
    private String name;
    @NotNull
    private String role;
}
