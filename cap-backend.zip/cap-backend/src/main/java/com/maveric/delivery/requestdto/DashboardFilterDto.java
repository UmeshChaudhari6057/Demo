package com.maveric.delivery.requestdto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DashboardFilterDto {

    private Long accountId;
    private Long projectId;
    @Builder.Default
    private String dateRange ="ALL";
}
