package com.maveric.delivery.Entity;

import java.util.List;


import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "role_privileges")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RolePrivileges extends IdentifiedEntity {

    @Column(nullable = false)
    private Long roleId;

    @ElementCollection
    @CollectionTable(name = "role_privileges_mapping", joinColumns = @JoinColumn(name = "role_privileges_id"))
    private List<Privileges> privileges;
}

