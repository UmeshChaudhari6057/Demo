package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.maveric.delivery.responsedto.BaseDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RolesDto extends BaseDto {

    private String description;
    @JsonIgnore
    private List<String> group;

    @JsonIgnore
    private int hierarchy;
}
