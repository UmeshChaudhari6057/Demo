package com.maveric.delivery.controller;

import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.requestdto.UserPrivilegesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.UserService;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;
import static com.maveric.delivery.utils.Constants.VIEW_ALL;
import static com.maveric.delivery.utils.SuccessMessage.ROLE_PRIVILEGES_FETCHED;

@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/v1")
@Tag(name = "User Management", description = "Endpoints for managing Users")
public class UserController {
    private final UserService userService;
    private final ValidateApiAccess validateApiAccess;

    @Operation(summary = "Fetch User Highest role",description = "Api to Fetch User Highest role")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping("/user/get-highest-role/{userId}")
    public ResponseEntity<String> getHighestRole(@PathVariable UUID userId,
                                                 @RequestParam(name = "accountId", required = false) Long accountId,
                                                 @RequestParam(name = "projectId", required = false) Long projectId) {
        log.info("UserController :: getHighestRole :: call started");
        String highestRole = userService.getHighestRole(userId, accountId, projectId);
        log.info("UserController :: getHighestRole :: call ended");
        return ResponseEntity.ok(highestRole);
    }

    @Operation(summary = "Save user",description = "Api to save user")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping("/user/save")
    public DedRolesmy saveUser(@RequestBody DedRolesDto json) {
        return userService.saveUser(json);
    }

    @Operation(summary = "Fetch user",description = "Api to fetch users")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping("/users")
    public ResponseEntity<List<UserDto>> getAllUsers() {
        log.info("UserController :: getAllUsers :: call started");
        List<UserDto> userDtoList = userService.getAllUsers();
        if (userDtoList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(Collections.emptyList());
        }
        log.info("UserController :: getAllUsers :: call ended");
        return ResponseEntity.ok(userDtoList);
    }

    @Operation(summary = "This API is designed to retrieve the privileges associated with user roles.",description = "Api to Get the privileges associated with user roles")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/users/privileges")
    public ResponseEntity<ResponseDto<UserPrivilegesDto>> userPrivileges(HttpServletRequest servletRequest) {
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, VIEW_ALL);
        log.info("UserController::userPrivileges started");
        UserPrivilegesDto response = userService.getPrivileges(rolesDto.getOid());
        log.info("UserController::userPrivileges end");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, ROLE_PRIVILEGES_FETCHED.getCode(), ROLE_PRIVILEGES_FETCHED.getMessage(), null, response));
    }

    @Operation(summary = "Fetch user nav-bar details",description = "Api to Fetch user nav-bar details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/user/nav-Privileges")
    public ResponseEntity<ResponseDto<List<String>>> getPrivilegesForNavBar(HttpServletRequest servletRequest) {
        log.info("UserController::getPrivilegesForNavBar started");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        List<String> privilegesForNavBar = userService.getPrivilegesForNavBar(userId);
        log.info("UserController::getPrivilegesForNavBar end");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS,ROLE_PRIVILEGES_FETCHED.getCode(),ROLE_PRIVILEGES_FETCHED.getMessage(),null,privilegesForNavBar));
    }
}
