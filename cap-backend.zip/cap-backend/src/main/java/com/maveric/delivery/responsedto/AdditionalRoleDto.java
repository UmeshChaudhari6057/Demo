package com.maveric.delivery.responsedto;

import lombok.Data;

/**
 * @author ankushk
 */

@Data
public class AdditionalRoleDto {

    private String account;
    private String project;
    private String group;
    private String role;
}