package com.maveric.delivery.service;


import static com.maveric.delivery.utils.Constants.*;
import static com.maveric.delivery.utils.Constants.DM;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Assessment;
import com.maveric.delivery.Entity.AssessmentHistory;
import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.Entity.Frequency;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.ProjectAssessmentDetails;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.BaseInfo;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.Option;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.Entity.Question;
import com.maveric.delivery.model.embedded.MyTemplateCategory;
import com.maveric.delivery.model.embedded.TemplateStatus;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.mysqlrepository.AssessmentHistorymysqlRepository;
import com.maveric.delivery.mysqlrepository.AssessmentmysqlRepository;
import com.maveric.delivery.mysqlrepository.AssessmentTemplatemysqlRepository;
import com.maveric.delivery.mysqlrepository.EmailDetailsmysqlRepository;
import com.maveric.delivery.mysqlrepository.FrequencymysqlRepository;
import com.maveric.delivery.mysqlrepository.ProjectAssessmentDetailsmysqlRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.requestdto.SendEmailDetailsDto;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.responsedto.JobNotificationDetails;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class AssessmentCreationAndNotification {
    private final AssessmentTemplatemysqlRepository assessmentTemplateRepository;
    private final FrequencymysqlRepository frequencyRepository;
  //  private final ProjectRepository projectRepository;
    private final AssessmentmysqlRepository assessmentRepository;
  //  private final AccountRepository accountRepository;
    private final ProjectAssessmentDetailsmysqlRepository projectAssessmentDetailsRepository;
    private final AssessmentHistorymysqlRepository assessmentHistoryRepository;
    private final UserServiceImpl userService;
    private final AzureUsermysqlRepository azureUserRepository;
    private final EmailService emailService;
    private final EmailDetailsmysqlRepository emailDetailsRepository;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");


    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void createAssessmentForProject(Project project) {
//Mogo code commeted
    	//        log.info("AssessmentCreationAndNotification::createAssessmentForProject method started");
//        createAssessment(project, null);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void createNextAssessmentForProject(ProjectAssessmentDetails projectAssessmentDetails) {
// Mongo code commeted
    	//        log.info("AssessmentCreationAndNotification::createNextAssessmentForProject method started");
//        Optional<Project> project = projectRepository.findById(projectAssessmentDetails.getProjectId());
//        if (project.isEmpty()) {
//            log.error("Project not found for the ID: {}", projectAssessmentDetails.getProjectId());
//            throw new ProjectNotFoundException("Project not found for the id " + projectAssessmentDetails.getProjectId());
//        }
//        List<SendEmailDetailsDto> sendEmailDetailsDtoList = assessmentStatusChange(project.get());
//
//        log.info("Assessments status changed for Project ID: {}", project.get().getId());
//        Optional<Assessment> prevAssessment = assessmentRepository.findById(projectAssessmentDetails.getAssessmentId());
//        if (prevAssessment.isEmpty()) {
//            log.error("Assessment not found with the ID: {}", projectAssessmentDetails.getAssessmentId());
//            throw new CustomException("Assessment not found with the id " + projectAssessmentDetails.getAssessmentId(), HttpStatus.NOT_FOUND);
//        }
//        createAssessment(project.get(), prevAssessment.get());
//        if(!CollectionUtils.isEmpty(sendEmailDetailsDtoList)) {
//            for (SendEmailDetailsDto sendEmailDetailsDto1 : sendEmailDetailsDtoList) {
//                emailService.send(sendEmailDetailsDto1);
//            }
//        }
//        log.info("Next assessment created successfully for Project ID: {}", project.get().getId());
    }


    List<MyTemplateCategory> setAnswers(Assessment assessment, Assessment prevAssessment) {
        try {
            log.info("setAnswers() method execution started for Assessment ID: {}", assessment.getId());
            List<MyTemplateCategory> prevTemplateCategoryList = prevAssessment.getTemplateCategories();
            List<MyTemplateCategory> currentTemplateCategoryList = assessment.getTemplateCategories();
            List<MyTemplateCategory> finalTemplateCategoryList = new ArrayList<>();

            MyTemplateCategory prevProjectMaturity = getTemplateCategory(prevTemplateCategoryList, AssessmentCategoryType.PROJECT_MATURITY);
            MyTemplateCategory currentProjectMaturity = getTemplateCategory(currentTemplateCategoryList, AssessmentCategoryType.PROJECT_MATURITY);
            if (null != prevProjectMaturity && null != currentProjectMaturity) {
                for (Question newQuestion : currentProjectMaturity.getQuestions()) {
                    for (Question question : prevProjectMaturity.getQuestions()) {
                        if (newQuestion.getQuestionText().equalsIgnoreCase(question.getQuestionText())) {
                            copyAnswers(question, newQuestion);
                        }
                    }
                }
                finalTemplateCategoryList.add(currentProjectMaturity);
                log.info("Answers copied for PROJECT_MATURITY category");
            }

            MyTemplateCategory prevExecutionMaturity = getTemplateCategory(prevTemplateCategoryList, AssessmentCategoryType.EXECUTION_MATURITY);
            MyTemplateCategory currentExecutionMaturity = getTemplateCategory(currentTemplateCategoryList, AssessmentCategoryType.EXECUTION_MATURITY);
            if (null != prevExecutionMaturity && null != currentExecutionMaturity) {
                for (Question newQuestion : currentExecutionMaturity.getQuestions()) {
                    prevExecutionMaturity.getQuestions().stream()
                            .filter(question1 -> question1.getQuestionText().equalsIgnoreCase(newQuestion.getQuestionText()))
                            .map(question -> copyAnswers(question, newQuestion))
                            .collect(Collectors.toList());
                }
                finalTemplateCategoryList.add(currentExecutionMaturity);
                log.info("Answers copied for EXECUTION_MATURITY category");
            }
            finalTemplateCategoryList.add(getTemplateCategory(currentTemplateCategoryList, AssessmentCategoryType.DELIVERY_MATURITY));
            log.info("Added DELIVERY_MATURITY category");
            return finalTemplateCategoryList;
        } catch (Exception e) {
            log.error("An error occurred while setting answers: {}", e.getMessage(), e);
            throw new RuntimeException("An error occurred while setting answers", e);
        }
    }


    public Question copyAnswers(Question prevQuestion, Question newQuestion) {
        if (null!=prevQuestion.getCommentText()) {
            newQuestion.setCommentText(prevQuestion.getCommentText());
        }
        if(!prevQuestion.isNotApplicableUserResponse())  {
            return switch (newQuestion.getType().toString()) {
                case "CHECK_BOX" -> copyCheckBoxAnswers(prevQuestion, newQuestion);
                case "RADIO_BUTTON" -> copyRadioButtonsAnswer(prevQuestion, newQuestion);
                case "NUMERICAL" -> copyNumericalAnswer(prevQuestion, newQuestion);
                case "SLIDER" -> copySliderAnswer(prevQuestion, newQuestion);
                default -> null;
            };
        }
        if(newQuestion.isNotApplicable() && prevQuestion.isNotApplicable()) {
            newQuestion.setNotApplicableUserResponse(prevQuestion.isNotApplicableUserResponse());
            return newQuestion;
        }
        return newQuestion;
    }


    public Question copyCheckBoxAnswers(Question prevQuestion, Question newQuestion) {
        List<Integer> indexList = prevQuestion.getCheckBoxOptions().getOptions().stream().filter(Option::isSelected).map(Option::getIndex).collect(Collectors.toList());
        for (Option option : newQuestion.getCheckBoxOptions().getOptions()) {
            if (indexList.contains(option.getIndex())) {
                option.setSelected(Boolean.TRUE);
            }
        }
        return newQuestion;
    }

    public Question copyRadioButtonsAnswer(Question prevQuestion, Question newQuestion) {
        Integer index = prevQuestion.getRadioOptions().getOptions().stream().filter(Option::isSelected).map(Option::getIndex).findAny().orElse(null);
        Option optionTemp = newQuestion.getRadioOptions().getOptions().stream().filter(option -> Objects.equals(option.getIndex(), index)).findAny().orElse(null);
        if (null != optionTemp) {
            optionTemp.setSelected(Boolean.TRUE);
        }
        return newQuestion;
    }

    public Question copyNumericalAnswer(Question prevQuestion, Question newQuestion) {
        newQuestion.getNumerical().setValue(prevQuestion.getNumerical().getValue());
        return newQuestion;
    }

    public Question copySliderAnswer(Question prevQuestion, Question newQuestion) {
        newQuestion.getSlider().setValue(prevQuestion.getSlider().getValue());
        return newQuestion;
    }

    MyTemplateCategory getTemplateCategory(List<MyTemplateCategory> templateCategoryList, AssessmentCategoryType
            type) {
        return templateCategoryList.stream()
                .filter(templateCategory -> templateCategory.getName().equals(type))
                .findAny().orElse(null);
    }


    public List<SendEmailDetailsDto> assessmentStatusChange(Project project) {
        log.info("assessmentStatusChange() method execution started for Project ID: {}", project.getId());
        try {
            List<SendEmailDetailsDto> sendEmailDetailsDtoList =new ArrayList<>();
            List<Assessment> assessmentList = assessmentRepository.findByProjectId(project.getId());
            for (Assessment assessment : assessmentList) {
                SendEmailDetailsDto sendEmailDetailsDto = changeStatus(assessment, project);
                if(Objects.nonNull(sendEmailDetailsDto)) {
                    sendEmailDetailsDtoList.add(sendEmailDetailsDto);
                }
            }
            log.info("assessmentStatusChange() method execution completed for Project ID: {}", project.getId());
            return sendEmailDetailsDtoList;
        } catch (Exception e) {
            log.error("An error occurred while changing assessment statuses for Project ID: {}", project.getId(), e);
            throw new RuntimeException("An error occurred while changing assessment statuses", e);
        }
    }

    public SendEmailDetailsDto changeStatus(Assessment assessment, Project project) {
    	//Mongo code commeted
//        log.info("changeStatus() method execution started for Assessment ID: {}", assessment.getId());
//        try {
//            SendEmailDetailsDto sendEmailDetailsDto = null;
//            AssessmentHistory assessmentHistory = new AssessmentHistory();
//            if (assessment.getStatus().equals(AssessmentStatus.PENDING)) {
//                assessmentHistory.setPreviousStatus(assessment.getStatus());
//                assessment.setStatus(AssessmentStatus.OVERDUE);
//      //          String projectName = projectRepository.findById(assessment.getProjectId()).orElse(new Project()).getProjectName();
//               // sendEmailDetailsDto = sendEmailDetails(assessment, project, ASSESSMENT_OVERDUE_SUBJECT.concat(projectName), ASSESSMENT_SUBMISSION_REMAINDER_TEMPLATE
//            //            , ASSESSMENT_OVERDUE.concat(String.valueOf(Instant.ofEpochMilli(assessment.getDueOn())
//           //                     .atZone(ZoneId.systemDefault())
//           //                     .toLocalDate().format(dateFormatter))).concat(".").concat("</p>"), null,"ASSESSMENT_STATUS_CHANGE");
//                //emailDetailsRepository.save(sendEmailDetailsDto);
//                assessmentHistory.setCurrentStatus(assessment.getStatus());
//                saveAssessmentHistory(assessment, assessmentHistory);
//                Frequency frequency = frequencyRepository.findByName(project.getDeliveryInfo().getFrequency());
//                if (null == frequency) {
//                    throw new CustomException("frequency not found in the db", HttpStatus.NOT_FOUND);
//                }
//                updateProjectAssessmentDetails(null,assessment, frequency.getDays());
//            } else if (assessment.getStatus().equals(AssessmentStatus.IN_PROGRESS)) {
//                assessmentHistory.setPreviousStatus(assessment.getStatus());
//                assessment.setStatus(AssessmentStatus.OVERDUE_IN_PROGRESS);
//                sendEmailDetailsDto = sendEmailDetails(assessment, project, ASSESSMENT_OVERDUE_INPROGRESS_SUBJECT, ASSESSMENT_SUBMISSION_REMAINDER_TEMPLATE, ASSESSMENT_OVERDUE_INPROGRESS, null,"ASSESSMENT_STATUS_CHANGE");
//                //emailDetailsRepository.save(sendEmailDetailsDto);
//                assessmentHistory.setCurrentStatus(assessment.getStatus());
//                saveAssessmentHistory(assessment, assessmentHistory);
//            } else if (assessment.getStatus().equals(AssessmentStatus.OVERDUE) || assessment.getStatus().equals(AssessmentStatus.OVERDUE_IN_PROGRESS)) {
//                assessmentHistory.setPreviousStatus(assessment.getStatus());
//                assessment.setStatus(AssessmentStatus.EXPIRED);
//                sendEmailDetailsDto = sendEmailDetails(assessment, project, ASSESSMENT_EXPIRED_SUBJECT, ASSESSMENT_SUBMISSION_REMAINDER_TEMPLATE, ASSESSMENT_EXPIRED, null,"ASSESSMENT_STATUS_CHANGE");
//                //emailDetailsRepository.save(sendEmailDetailsDto);
//                assessmentHistory.setCurrentStatus(assessment.getStatus());
//                saveAssessmentHistory(assessment, assessmentHistory);
//            }
//            assessmentRepository.save(assessment);
//            log.info("Status changed to {} for Assessment ID: {}", assessment.getStatus(), assessment.getId());
//            return sendEmailDetailsDto;
//        } catch (Exception e) {
//            log.error("An error occurred while changing the status of Assessment ID: {}", assessment.getId(), e);
//            throw new RuntimeException("An error occurred while changing the assessment status", e);
//        }
    	return new SendEmailDetailsDto();
    }

    void updateProjectAssessmentDetails(ProjectAssessmentDetails projectAssessmentDetails,Assessment assessment, int days) {
        if(projectAssessmentDetails==null) {
            ProjectAssessmentDetails projectAssessmentDetailsForStatusChange = projectAssessmentDetailsRepository.findByAssessmentId(assessment.getId());
            ProjectAssessmentDetails updatedProjectAssessmentDetails=setRemainderDatesForOverdue(projectAssessmentDetailsForStatusChange,days);
            projectAssessmentDetailsRepository.save(updatedProjectAssessmentDetails);
            log.info("updating projectAssessmentDetails is successful");
        }else{
            if (assessment.getStatus().equals(AssessmentStatus.PENDING)) {
                setRemainderDatesForPending(projectAssessmentDetails,days);
            } else if (assessment.getStatus().equals(AssessmentStatus.OVERDUE)) {
                setRemainderDatesForOverdue(projectAssessmentDetails,days);
            }
            projectAssessmentDetails.setNextAssessmentCreationDate(
                    projectAssessmentDetails.getAssessmentCreatedDate()
                            .atZone(ZoneOffset.UTC)
                            .toLocalDate()
                            .plusDays(days)
                            .atStartOfDay(ZoneOffset.UTC)
                            .toInstant()
            );
            projectAssessmentDetailsRepository.save(projectAssessmentDetails);

        }
    }

    public ProjectAssessmentDetails setRemainderDatesForOverdue(ProjectAssessmentDetails projectAssessmentDetails,int days){
        projectAssessmentDetails.setRemainderDate1(projectAssessmentDetails.getAssessmentCreatedDate().plus(Duration.ofDays(calculateRemainderMailsForOverdue(days, 4))));
        projectAssessmentDetails.setRemainderDate2(projectAssessmentDetails.getAssessmentCreatedDate().plus(Duration.ofDays(calculateRemainderMailsForOverdue(days, 8))));
        projectAssessmentDetails.setRemainderDate3(projectAssessmentDetails.getAssessmentCreatedDate().plus(Duration.ofDays(calculateRemainderMailsForOverdue(days, 16))));
        return projectAssessmentDetails;
    }

    public ProjectAssessmentDetails setRemainderDatesForPending(ProjectAssessmentDetails projectAssessmentDetails,int days) {

        projectAssessmentDetails.setRemainderDate1(projectAssessmentDetails.getAssessmentCreatedDate().plus(Duration.ofDays(calculateRemainderMailsForPending(days, 2))));
        projectAssessmentDetails.setRemainderDate2(projectAssessmentDetails.getAssessmentCreatedDate().plus(Duration.ofDays(calculateRemainderMailsForPending(days, 4))));
        projectAssessmentDetails.setRemainderDate3(projectAssessmentDetails.getAssessmentCreatedDate().plus(Duration.ofDays(calculateRemainderMailsForPending(days, 8))));
        return projectAssessmentDetails;
    }

    public Assessment createAssessment(Project project, Assessment prevAssessment) {
    	// Mongo code commeted
//        log.info("createAssessment() method execution started");
//        try {
//            log.info("Initialized new assessment for project ID: {}", project.getId());
//            Assessment assessment = new Assessment();
//            assessment.setProjectId(project.getId());
//            assessment.setStatus(AssessmentStatus.PENDING);
//            List<MyTemplateCategory> templateCategoryList = getTemplateList(project);
//            assessment.setTemplateCategories(templateCategoryList);
//            log.info("Template categories set for the assessment");
//            if (null != prevAssessment) {
//                log.info("Previous assessment exists for project ID: {}", project.getId());
//                if (prevAssessment.getStatus().equals(AssessmentStatus.REVIEWED)) {
//                    assessment.setTemplateCategories(setAnswers(assessment, prevAssessment));
//                } else {
//                    log.info("Previous assessment is not reviewed, fetching the latest reviewed assessment");
//                    //Change function name for mysql database migration
//                    Assessment previousAssessment = assessmentRepository.findFirstReviewedAssessmentByProjectId(project.getId());
//                    if (null != previousAssessment) {
//                        log.info("Setting answers from previous assessment {}", previousAssessment.getId());
//                        assessment.setTemplateCategories(setAnswers(assessment, previousAssessment));
//                    }
//                }
//            }
//
//            Frequency frequency = frequencyRepository.findByName(project.getDeliveryInfo().getFrequency());
//            log.error("Frequency not found in the database for name: {}", project.getDeliveryInfo().getFrequency());
//            if (frequency == null) {
//                throw new CustomException("Frequency not found in the db " + project.getDeliveryInfo().getFrequency(), HttpStatus.NOT_FOUND);
//            }
//            assessment.setDueOn(calculateDueDate(System.currentTimeMillis(), frequency.getDays() - 1));
//            assessment.setAccountId(project.getAccountId());
//            UserDto submitter = getSubmitter(project.getDedRoles());
//            assessment.setUserId(submitter.getOid());
//            assessment.setUserName(submitter.getName());
//            assessment.setInitiatedOn(System.currentTimeMillis());
//            assessment.setDeliveryHead(getDeliveryHead(project.getAccountId()).getName());
//            assessment.setDeliveryHeadId(getDeliveryHead(project.getAccountId()).getOid());
//            assessmentRepository.save(assessment);
//            log.info("Assessment saved successfully with ID: {}", assessment.getId());
//            saveAssessmentHistory(assessment, null);
//            log.info("Assessment history saved");
//            saveProjectAssessmentDetails(assessment, project);
//            log.info("Project assessment details saved");
//            String projectName = projectRepository.findById(assessment.getProjectId()).orElse(new Project()).getProjectName();
//
//            sendEmailDetails(assessment, project, NEW_ASSESSMENT_SUBJECT.concat(StringUtils.defaultIfBlank(projectName,"")), ASSESSMENT_SUBMISSION_REMAINDER_TEMPLATE,
//                    NEW_ASSESSMENT.concat(String.valueOf(Instant.ofEpochMilli(assessment.getDueOn())
//                            .atZone(ZoneId.systemDefault())
//                            .toLocalDate().format(dateFormatter))).concat(".").concat("</p>"), null,"CREATE_ASSESSMENT_EMAIL");
//            log.info("Email sent for the pending assessment");
//            log.info("createAssessment() method execution completed successfully");
//            return assessment;
//        } catch (Exception e) {
//            log.error("An unexpected error occurred while creating the assessment: {}", e.getMessage(), e);
//            throw new RuntimeException(e.getMessage());
//            
//        }
    	
    	return new Assessment();

    }

    public SendEmailDetailsDto sendEmailDetails(Assessment assessment, Project project, String subject, String
            templateName, String message, Map<String, List<JobNotificationDetails>> failedProjectsJobMap,String type) {
//        try {
//            //log.info("sendEmailDetails() method execution started for Assessment ID: {}", assessment.getId());
//            SendEmailDetailsDto sendEmailDetailsDto = new SendEmailDetailsDto();
//            if (null == failedProjectsJobMap) {
//                AzureUsers user =getUserDetails(assessment.getUserId());
//                List<String> emailIds=new ArrayList<>();
//                Predicate<DedRolesmy> predicate = dedRole -> (ADM.equalsIgnoreCase(dedRole.getRole()) && user.getId().equals(dedRole.getOid()));
//                if(project.getDedRoles().stream().anyMatch(predicate)){
//                    emailIds.add(getUserDetails(project.getDedRoles().stream().filter(dedRole ->DM.equalsIgnoreCase(dedRole.getRole()))
//                            .findAny().orElse(new DedRolesmy())
//                            .getOid()).getMail());
//                }
//                emailIds.add(user.getMail());
//                sendEmailDetailsDto.setEmailId(emailIds);
//                String accountName= accountRepository.findById(project.getAccountId()).orElse(new Account()).getAccountName();
//                sendEmailDetailsDto.setAccountName(accountName);
//                sendEmailDetailsDto.setProjectType(project.getDeliveryInfo().getProjectType());
//                sendEmailDetailsDto.setProjectName(project.getProjectName());
//                sendEmailDetailsDto.setUserName(assessment.getUserName());
//                sendEmailDetailsDto.setDueDate(String.valueOf(Instant.ofEpochMilli(assessment.getDueOn())
//                        .atZone(ZoneId.systemDefault())
//                        .toLocalDate().format(dateFormatter)));
//
//                if (null != assessment.getReviewedOn()) {
//                    sendEmailDetailsDto.setReviewOn(String.valueOf(Instant.ofEpochMilli(assessment.getReviewedOn())
//                            .atZone(ZoneId.systemDefault())
//                            .toLocalDate().format(dateFormatter)));
//                }
//                if (null != assessment.getReviewerName()) {
//                    sendEmailDetailsDto.setReviewedBy(assessment.getReviewerName());
//                }
//                if (null != assessment.getSubmittedOn()) {
//                    sendEmailDetailsDto.setSubmittedOn(String.valueOf(Instant.ofEpochMilli(assessment.getSubmittedOn())
//                            .atZone(ZoneId.systemDefault())
//                            .toLocalDate().format(dateFormatter)));
//                }
//                if (null != assessment.getReviewerId()) {
//                    Optional<AzureUsers> azureUserReviewer = azureUserRepository.findById(assessment.getReviewerId());
//                    if (azureUserReviewer.isEmpty()) {
//                        throw new CustomException("reviewer is not found with id " + assessment.getReviewerId(), HttpStatus.NOT_FOUND);
//                    }
//                    sendEmailDetailsDto.setReviewerEmail(azureUserReviewer.get().getMail());
//                }
//            } else {
//                sendEmailDetailsDto.setFailureJobNotificationDetailsMap(failedProjectsJobMap);
//            }
//            sendEmailDetailsDto.setSubject(subject);
//            sendEmailDetailsDto.setMessage(message);
//            sendEmailDetailsDto.setTemplateName(templateName);
//            sendEmailDetailsDto.setEmailType(type);
//            if (sendEmailDetailsDto.getSubject().startsWith(ASSESSMENT_OVERDUE_SUBJECT)
//                    || sendEmailDetailsDto.getSubject().equalsIgnoreCase(ASSESSMENT_EXPIRED_SUBJECT)
//                    || sendEmailDetailsDto.getSubject().equalsIgnoreCase(ASSESSMENT_OVERDUE_INPROGRESS_SUBJECT)) {
//                return sendEmailDetailsDto;
//            } else {
//                emailService.send(sendEmailDetailsDto);
//            }
//            //log.info("Email sent successfully for Assessment ID: {}", assessment.getId());
//            return sendEmailDetailsDto;
//        } catch (Exception e) {
//            /*log.error("An error occurred while sending email for Assessment ID: {}", assessment.getId(), e)*/
//
//            throw new RuntimeException(e.getMessage());
//        }
    	
    	return new SendEmailDetailsDto();
    }

    private AzureUsers getUserDetails(UUID id){
        if(Objects.nonNull(id)){
            Optional<AzureUsers> azureUser = azureUserRepository.findById(id);
            if (azureUser.isEmpty()) {
                log.error("User not found :{}",id);
                throw new CustomException("User not found", HttpStatus.NOT_FOUND);
            }
            return azureUser.get();
        }
        log.error("User not found");
        throw new CustomException("User not found", HttpStatus.NOT_FOUND);
    }

    public void saveProjectAssessmentDetails(Assessment assessment, Project project) {
        log.info("saveProjectAssessmentDetails() method execution started for Assessment ID: {}", assessment.getId());
        try {
            ProjectAssessmentDetails projectAssessmentDetails = new ProjectAssessmentDetails();
            projectAssessmentDetails.setAssessmentId(assessment.getId());
            projectAssessmentDetails.setProjectId(assessment.getProjectId());
            Frequency frequency = frequencyRepository.findByName(project.getDeliveryInfo().getFrequency());
            log.error("Frequency not found in the database for name: {}", project.getDeliveryInfo().getFrequency());
            if (frequency == null) {
                throw new CustomException("frequency not found in the db", HttpStatus.NOT_FOUND);
            }
            projectAssessmentDetails.setNextAssessmentCreationDate(LocalDate.now().plusDays(frequency.getDays()).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
            projectAssessmentDetails.setAssessmentCreatedDate(LocalDate.now().atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
            setRemainderDatesForPending(projectAssessmentDetails,frequency.getDays());
            projectAssessmentDetailsRepository.save(projectAssessmentDetails);
            log.info("ProjectAssessmentDetails saved successfully for Assessment ID: {}", assessment.getId());

        } catch (Exception e) {
            log.error("Error occurred while saving ProjectAssessmentDetails for Assessment ID: {}", assessment.getId(), e);
            throw new RuntimeException(e.getMessage());
        }
    }


    public Long calculateDueDate(Long date, int days) {

        LocalDate date1 = Instant.ofEpochMilli(date)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        LocalDate newDate = date1.plusDays(days);
        return newDate.atStartOfDay(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli();
    }

    void saveAssessmentHistory(Assessment assessment, AssessmentHistory assessmentHistoryTemp) {
        log.info("saveAssessmentHistory() method execution started for Assessment ID: {}", assessment.getId());

        try {
            AssessmentHistory assessmentHistory = new AssessmentHistory();
            assessmentHistory.setAssessmentId(assessment.getId());
            assessmentHistory.setProjectId(assessment.getProjectId());
            assessmentHistory.setAccountId(assessment.getAccountId());
            assessmentHistory.setCreatedBy("SYSTEM");
            assessmentHistory.setAssessmentStartDate(assessment.getInitiatedOn());
            assessmentHistory.setCurrentStatus(assessment.getStatus());
            assessmentHistory.setPreviousStatus(null);
            if (null != assessmentHistoryTemp) {
                assessmentHistory.setCurrentStatus(assessmentHistoryTemp.getCurrentStatus());
                assessmentHistory.setPreviousStatus(assessmentHistoryTemp.getPreviousStatus());
            }
            assessmentHistory.setCreateDate(System.currentTimeMillis());
            assessmentHistoryRepository.save(assessmentHistory);
            log.info("AssessmentHistory saved successfully for Assessment ID: {}", assessment.getId());

        } catch (Exception e) {
            log.error("An unexpected error occurred while saving AssessmentHistory for Assessment ID: {}", assessment.getId(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

    UserDto getDeliveryHead(Long accountId) {
//        Optional<Account> account = accountRepository.findById(accountId);
//        if (account.isEmpty()) {
//            throw new CustomException("Account is not found with the id " + accountId, HttpStatus.NOT_FOUND);
//        }
//        
//        //5:55
//        Optional<UserDto> deliveryHead = account.get().getDedRoles().stream()
//                .filter(DedRolesmy -> DH.equalsIgnoreCase(DedRolesmy.getRole()))
//                .map(DedRolesmy -> new UserDto(DedRolesmy.getOid(), DedRolesmy.getName()))
//                .findAny();
//        return deliveryHead.get();
    	return new UserDto();

    }

    public List<MyTemplateCategory> getTemplateList(Project project) {
        log.info("getTemplateList() method execution started for Project ID: {}", project.getId());
        try {
            List<MyTemplateCategory> finalTemplateCategoryList = new ArrayList<>();
            List<BaseInfo> assessmentTemplate = project.getDeliveryInfo().getAssessmentTemplates();
            List<AssessmentTemplate> assessmentTemplateList = new ArrayList<>();
            List<Question> mergedQuestions = new ArrayList<>();
            //delivery template
            for (BaseInfo baseInfo : assessmentTemplate) {
                Optional<AssessmentTemplate> deliveryTemplate = assessmentTemplateRepository.findById(baseInfo.getId());
                if (deliveryTemplate.isEmpty()) {
                    log.error("Template not found with ID: " + baseInfo.getId());
                    throw new CustomException("template not found with id " + baseInfo.getId(), HttpStatus.NOT_FOUND);
                }
                if (deliveryTemplate.get().getUtilizedProjects() == null) {
                    deliveryTemplate.get().setUtilizedProjects(Set.of(project.getId()));
                } else {
                    deliveryTemplate.get().getUtilizedProjects().add(project.getId());
                }
                assessmentTemplateRepository.save(deliveryTemplate.get());
                assessmentTemplateList.add(deliveryTemplate.get());
            }
            // Merge questions and assign numbers
            int index = 0;
            for (AssessmentTemplate assessmentTemplate1 : assessmentTemplateList) {
                for (Question question : assessmentTemplate1.getQuestions()) {
                    index = index + 1;
                    question.setNumber(index);
                    mergedQuestions.add(question);
                }

            }
            // Process Project Maturity Template
            AssessmentTemplate projectMaturityTemplate = assessmentTemplateRepository.findByAssessmentTypeAndStatus(AssessmentCategoryType.PROJECT_MATURITY.toString(), TemplateStatus.Active);
            if (null==projectMaturityTemplate) {
                log.error("No active templates found for the template type " + AssessmentCategoryType.PROJECT_MATURITY);
                throw new CustomException("No active templates found for the template type " + AssessmentCategoryType.PROJECT_MATURITY, HttpStatus.NOT_FOUND);
            }

            if (projectMaturityTemplate.getUtilizedProjects() == null) {
                projectMaturityTemplate.setUtilizedProjects(Set.of(project.getId()));
            } else {
                projectMaturityTemplate.getUtilizedProjects().add(project.getId());
            }//adding projectId in the template
            assessmentTemplateRepository.save(projectMaturityTemplate);
            finalTemplateCategoryList.add(getTemplateCategory(AssessmentCategoryType.PROJECT_MATURITY, projectMaturityTemplate.getQuestions()));//adding the questions to the list

            String projectType = project.getDeliveryInfo().getProjectType();
            AssessmentTemplate executionMaturityTemplate = assessmentTemplateRepository.findByProjectTypeAndStatus(projectType, TemplateStatus.Active);
            if (null==executionMaturityTemplate) {
                log.error("No active execution maturity templates found for the project type " + projectType);
                throw new CustomException("No active execution maturity templates found for the project type " + projectType, HttpStatus.NOT_FOUND);
            }
            if (executionMaturityTemplate.getUtilizedProjects() == null) {
                executionMaturityTemplate.setUtilizedProjects(Set.of(project.getId()));
            } else {
                executionMaturityTemplate.getUtilizedProjects().add(project.getId());
            }
            assessmentTemplateRepository.save(executionMaturityTemplate);
            finalTemplateCategoryList.add(getTemplateCategory(AssessmentCategoryType.EXECUTION_MATURITY, executionMaturityTemplate.getQuestions()));

            finalTemplateCategoryList.add(getTemplateCategory(AssessmentCategoryType.DELIVERY_MATURITY, mergedQuestions));
            log.info("Added All the templates into the final list");
            return finalTemplateCategoryList;
        } catch (Exception e) {
            log.error("An error occurred while getting template list for Project ID: {}", project.getId(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

    public UserDto getSubmitter(List<DedRolesmy> DedRolesmy) {
       return DedRolesmy.stream().filter(dedRole ->ADM.equalsIgnoreCase(dedRole.getRole()))
               .findAny().map(dedRole -> new UserDto(dedRole.getOid(),dedRole.getName()))
               .orElse(DedRolesmy.stream().filter(dedRole ->DM.equalsIgnoreCase(dedRole.getRole()))
                       .findAny().map(dedRole -> new UserDto(dedRole.getOid(),dedRole.getName())).orElse(null));
    }

    public MyTemplateCategory getTemplateCategory(AssessmentCategoryType category, List<Question> mergedQuestions) {

        MyTemplateCategory templateCategory = new MyTemplateCategory();
        //templateCategory.setName(project.getDeliveryInfo().getAssessmentTemplates().get(0).getName());
        templateCategory.setName(category);
        templateCategory.setQuestions(mergedQuestions);
        return templateCategory;
    }


    public int calculateRemainderMailsForOverdue(int days, int divisor) {
        log.info("calculateRemainderMailsForOverdue() method execution started with days: {} and divisor: {}", days, divisor);
        try {
            return (days * 2) - ((days * 2) / divisor);
        } catch (ArithmeticException e) {
            log.error("ArithmeticException occurred during calculation: {}", e.getMessage(), e);
            throw new RuntimeException("Arithmetic error occurred while calculating remainder mails for overdue", e);
        } catch (Exception e) {
            log.error("An unexpected error occurred during calculation: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

    public int calculateRemainderMailsForPending(int days, int divisor) {
        log.info("calculateRemainderMailsForPending() method execution started with days: {} and divisor: {}", days, divisor);
        try {
            return days - (days / divisor);
        } catch (ArithmeticException e) {
            log.error("ArithmeticException occurred during calculation: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            log.error("An unexpected error occurred during calculation: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }


    public Integer sendRemainderEmails() {
//        log.info("sendRemainderEmails() method execution started");
        Integer executedCount = 0;
//        List<ProjectAssessmentDetails> projectAssessmentDetailsList = projectAssessmentDetailsRepository.findByRemainderDates(LocalDate.now().atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
//        for (ProjectAssessmentDetails projectAssessmentDetails : projectAssessmentDetailsList) {
//            Optional<Project> project = projectRepository.findById(projectAssessmentDetails.getProjectId());
//            if(project.isEmpty()){
//                throw new CustomException("Project Not found with the id " + projectAssessmentDetails.getProjectId(), HttpStatus.NOT_FOUND);
//            }
//            if(project.get().getStatus().equals(ProjectStatus.Active)) {
//                Optional<Assessment> assessment = assessmentRepository.findById(projectAssessmentDetails.getAssessmentId());
//                if (assessment.isEmpty()) {
//                    throw new CustomException("Assessment NOt found with the id " + projectAssessmentDetails.getAssessmentId(), HttpStatus.NOT_FOUND);
//                }
//                if (!(assessment.get().getStatus().equals(AssessmentStatus.SUBMITTED) || assessment.get().getStatus().equals(AssessmentStatus.REVIEWED))) {
//                    Long days = calculateDaysBetween(assessment.get().getDueOn(), System.currentTimeMillis());
//                    sendEmailDetails(assessment.get(), project.get(), ASSESSMENT_REMAINDER_SUBJECT, "AssessmentSubmissionRemainder.ftl", ASSESSMENT_REMAINDER.concat(String.valueOf(days)).concat(" days."), null,"REMAINDER_EMAIL");
//                    log.info("Remainder email sent for Assessment ID: {} and Project ID: {}", assessment.get().getId(), project.get().getId());
//                    executedCount++;
//                }
//            }
//        }
//        log.info("sendRemainderEmails() method execution ended");
        return executedCount;
    	
    }

    public long calculateDaysBetween(long dueDate, long todayDate) {

        LocalDate date1 = Instant.ofEpochMilli(dueDate)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        LocalDate date2 = Instant.ofEpochMilli(todayDate)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        return ChronoUnit.DAYS.between(date2, date1);
    }


}



