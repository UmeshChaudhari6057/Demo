package com.maveric.delivery.mapper;

import com.maveric.delivery.exception.AssessmentException;
import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.requestdto.QuestionDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.BeanUtils;

import java.util.*;
import java.util.stream.Collectors;


@Mapper
public interface QuestionMapper {

    QuestionMapper MAPPER = Mappers.getMapper(QuestionMapper.class);

    default List<Question> questionDtoListToQuestionList(List<QuestionDto> questionDtos, List<Question> questions){

        questions.forEach(question ->
            questionDtos.stream().filter(questionDto -> (question.getNumber() == questionDto.getNumber())).forEach(questionDto ->
                questionDtoToQuestion(questionDto,question)
            )
        );
        return questions;
    }


    default void questionDtoToQuestion(QuestionDto questionDto,Question question) {
        BeanUtils.copyProperties(questionDto, question);
        if (questionDto.getType().equals(QuestionType.CHECK_BOX)) {

            List<Option> options = questionDto.getCheckBoxOption();
            //Fetched from DB
            List<Option> optionsList = question.getCheckBoxOptions().getOptions();

            Map<Integer, Option> list2Map = options.stream()
                    .collect(Collectors.toMap(Option::getIndex, option -> option));

            // Replace the values in list1 with the values from list2 where index matches
            optionsList.forEach(option -> {
                option.setSelected(list2Map.containsKey(option.getIndex()));
            });
            question.getCheckBoxOptions().setOptions(optionsList);
        } else if (questionDto.getType().equals(QuestionType.RADIO_BUTTON)) {

            Option option = questionDto.getRadioOption();
            List<Option> optionsList = question.getRadioOptions().getOptions();
            List<Option> newOptionList = new ArrayList<>();
            for (Option option1 : optionsList) {
                if ( Objects.nonNull(option) &&(option1.getIndex() == option.getIndex())) {
                    option.setScore(option1.getScore());
                    newOptionList.add(option);
                } else {
                    option1.setSelected(false);
                    newOptionList.add(option1);
                }
            }
            question.getRadioOptions().setOptions(newOptionList);

        } else if (questionDto.getType().equals(QuestionType.NUMERICAL)) {
            Numerical value = question.getNumerical();
            value.setValue(questionDto.getValue());
            question.setNumerical(value);
        } else {
            Slider value = question.getSlider();
            value.setValue(questionDto.getValue());
            question.setSlider(value);
        }
        question.setNotApplicableUserResponse(questionDto.isNotApplicableUserResponse());
        question.setCommentText(questionDto.getCommentText());
    }
}
