package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import jakarta.validation.Valid;

import java.util.List;

public interface RolePrivilegesService {

    List<RolePrivilegesDto> save(@Valid List<RolePrivilegesDto> rolePrivilegesDto);

    List<RolePrivilegesDto> findAll();

    RolePrivilegesDto findByRoleId(Long roleId);

    List<PrivilegesDetailsDto> findByGroup(List<String> type, String userGroup);

    RolePrivilegesDto findByValue(String name);

    List<PrivilegesDetailsDto> findByValue(List<String> type, String name);

}
