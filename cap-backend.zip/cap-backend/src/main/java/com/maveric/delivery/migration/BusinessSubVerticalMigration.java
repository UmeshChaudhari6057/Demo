package com.maveric.delivery.migration;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.mysqlrepository.BusinessSubverticalmysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;


import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

//@ChangeUnit(id = "BusinessSubVertical", order = "001", author = "delivery-excellence", systemVersion = "1")
@Service
@Slf4j
@AllArgsConstructor
public class BusinessSubVerticalMigration implements Migration{
 //   private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/business-subvertical.json";
    
    private final BusinessSubverticalmysqlRepository businessSubverticalmysqlRepository;


  
    @Override
    public void before() {
        log.info("BusinessSubVertical Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
  //  @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("BusinessSubVertical Migration RollbackBeforeExecution");
    }

    //@Execution
    @Transactional
    @Override
    public void migrationMethod() throws IOException {
    	log.info("Starting MySQL Migration for BusinessSubVertical...");

        try {
            List<BusinessSubvertical> businessSubverticals = jsonFileReader.readJsonFileToList(filePath, BusinessSubvertical.class);

            if (!businessSubverticals.isEmpty()) {
            	businessSubverticalmysqlRepository.saveAll(businessSubverticals);
                log.info("Migration completed: {} records inserted", businessSubverticals.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
        
    }

    
    @Override
    public void rollback() {
        log.info("BusinessSubVertical Migration RollbackBeforeExecution");
    
        
        businessSubverticalmysqlRepository.deleteAll(); 
    }

}
