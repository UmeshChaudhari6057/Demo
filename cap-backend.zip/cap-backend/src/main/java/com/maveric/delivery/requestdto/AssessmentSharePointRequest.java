package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssessmentSharePointRequest {
    @NotNull(message = "ProjectId is required")
    private Long projectId;
    private int questionNumber;
    @NotNull(message = "Category type is required")
    private AssessmentCategoryType assessmentCategoryType;

}
