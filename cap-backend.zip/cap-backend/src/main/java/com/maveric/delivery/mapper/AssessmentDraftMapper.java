package com.maveric.delivery.mapper;

import com.maveric.delivery.Entity.Assessment;
import com.maveric.delivery.Entity.AssessmentDraft;
import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.requestdto.QuestionDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.BeanUtils;

import java.util.Collections;
import java.util.List;


@Mapper
public interface AssessmentDraftMapper {

    AssessmentDraftMapper MAPPER = Mappers.getMapper(AssessmentDraftMapper.class);


    AssessmentDraft fromAssessment(Assessment assessment);
}
