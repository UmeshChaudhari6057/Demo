package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.Frequency;
import com.maveric.delivery.utils.JsonFileReader;
//import io.mongock.api.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
//import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.IOException;
import java.util.List;

//@ChangeUnit(id = "Frequency", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@AllArgsConstructor
public class FrequencyMigration implements Migration{
   // private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/frequency.json";


    
    @Override
    public void before() {
        log.info("Frequency Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("Frequency Migration RollbackBeforeExecution");
    }

   
    @Override
    public void migrationMethod() throws IOException {
        log.info("Frequency migrationMethod");
        List<Frequency> frequencies= jsonFileReader.readJsonFileToList(filePath, Frequency.class);
       // mongoTemplate.insertAll(frequencies);
    }

   
    @Override
    public void rollback() {
        log.info("Frequency Migration RollbackBeforeExecution");
    }
}
