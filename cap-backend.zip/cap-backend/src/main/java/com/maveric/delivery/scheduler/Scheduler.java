package com.maveric.delivery.scheduler;

import com.maveric.delivery.Entity.SchedulerConfig;
import com.maveric.delivery.Entity.SchedulerDetails;
import com.maveric.delivery.mysqlrepository.SchedulerConfigmysqlRepository;
import com.maveric.delivery.mysqlrepository.SchedulerDetailsmysqlRepository;
import com.maveric.delivery.service.AssessmentCreationAndNotification;
import com.maveric.delivery.service.AssessmentService;
import com.maveric.delivery.service.UserService;
import com.maveric.delivery.utils.UtilMethods;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RequiredArgsConstructor
@Slf4j
@Configuration
public class Scheduler {
    private final UserService userService;
    private final AssessmentCreationAndNotification assessmentCreationAndNotification;
    private final AssessmentService assessmentService;
    private final SchedulerConfigmysqlRepository schedulerConfigRepository;
    private final SchedulerDetailsmysqlRepository schedulerDetailsRepository;
    private final UtilMethods utilMethods;

    @Scheduled(cron = "${update.users.cron}")
    public void refreshUsersJob() {
        refreshUsers(null, CRON_JOB);
    }

    @Scheduled(cron = "${createAssessments.cron}")
    public void createAssessmentJob() {
        createAssessment(null, CRON_JOB);
    }

    @Scheduled(cron = "${remainder.mails.cron}")
    public void sendRemainderMailsJob() {
        sendRemainderMails(null, CRON_JOB);
    }

    @Scheduled(cron = "${failedAssessments.cron}")
    public void processFailedProjectsJob() {
        processFailedProjects(null, CRON_JOB);
    }

    @Scheduled(cron = "${project.endDateCheck.cron}")
    public void changeProjectEndDateJob() {
        changeProjectEndDate(null, CRON_JOB);
    }


    public void createAssessment(String uuid, String type) {
    	// MongoDB-related code has been commented out

//        utilMethods.updateSchedulerTraceId();
//        SchedulerDetails schedulerDetails = new SchedulerDetails();
//        schedulerDetails.setStartTime(LocalDateTime.now());
//        schedulerDetails.setTraceId(MDC.get(CRON_TRACE_ID));
//        schedulerDetails.setName(CREATE_ASSESSMENTS_JOB);
//        schedulerDetails.setInitiatedType(type);
//        String initiatedBy = StringUtils.isBlank(uuid) ? SYSTEM : utilMethods.getDisplayName(UUID.fromString(uuid));
//        schedulerDetails.setInitiatedBy(initiatedBy);
//        schedulerDetails.setStatus(IN_PROGRESS);
//        schedulerDetails = saveSchedulerDetails(schedulerDetails);
//        SchedulerConfig schedulerConfig = schedulerConfigRepository.findByKey("enableCreateAssessmentsJob");
//        try {
//            if ((schedulerConfig != null && schedulerConfig.getValue().equalsIgnoreCase("true")) || (API.equalsIgnoreCase(type))) {
//                log.info("createAssessment job started");
//          //      Map<String, String> executedCount = assessmentService.createAssessment();
//                schedulerDetails.setStatus(COMPLETED);
//                schedulerDetails.setMessage("Executed Count: " + executedCount.toString());
//            } else {
//                log.info("enableCreateAssessmentsJob flag is missing or turnedOff");
//                schedulerDetails.setStatus(ABORTED);
//                schedulerDetails.setMessage("CREATE_ASSESSMENTS_JOB config was missing/turned-Off");
//            }
//        } catch (Exception ex) {
//            schedulerDetails.setStatus(FAILED_CAP);
//            schedulerDetails.setMessage(ex.getMessage());
//            log.error("Exception in createAssessment job", ex);
//        } finally {
//            schedulerDetails.setEndTime(LocalDateTime.now());
//            saveSchedulerDetails(schedulerDetails);
//            log.info("createAssessment job ended");
//            // Clear the trace ID from the MDC after the request is processed
//            MDC.remove(CRON_TRACE_ID);
//        }
    }

    public void sendRemainderMails(String uuid, String type) {
        utilMethods.updateSchedulerTraceId();
        SchedulerDetails schedulerDetails = new SchedulerDetails();
        schedulerDetails.setStartTime(LocalDateTime.now());
        schedulerDetails.setTraceId(MDC.get(CRON_TRACE_ID));
        schedulerDetails.setName(REMAINDER_MAILS_JOB);
        schedulerDetails.setInitiatedType(type);
        String initiatedBy = StringUtils.isBlank(uuid) ? SYSTEM : utilMethods.getDisplayName(UUID.fromString(uuid));
        schedulerDetails.setInitiatedBy(initiatedBy);
        schedulerDetails.setStatus(IN_PROGRESS);
        schedulerDetails = saveSchedulerDetails(schedulerDetails);
        SchedulerConfig schedulerConfig = schedulerConfigRepository.findByKey("enableRemainderMailsJob");
        try {

            if ((schedulerConfig != null && schedulerConfig.getValue().equalsIgnoreCase("true")) || (API.equalsIgnoreCase(type))) {
                log.info("remaindermails job started");
                Integer executedCount = assessmentCreationAndNotification.sendRemainderEmails();
                schedulerDetails.setStatus(COMPLETED);
                schedulerDetails.setMessage("Executed Count: " + executedCount.toString());
            } else {
                log.info("enableRemainderMailsJob flag is missing or turnedOff");
                schedulerDetails.setStatus(ABORTED);
                schedulerDetails.setMessage("REMAINDER_MAILS_JOB config was missing/turned-Off");
            }
        } catch (Exception ex) {
            schedulerDetails.setStatus(FAILED_CAP);
            schedulerDetails.setMessage(ex.getMessage());
            log.error("Exception in remaindermails job", ex);
        } finally {
            schedulerDetails.setEndTime(LocalDateTime.now());
            saveSchedulerDetails(schedulerDetails);
            log.info("remaindermails job ended");
            // Clear the trace ID from the MDC after the request is processed
            MDC.remove(CRON_TRACE_ID);
        }
    }

    public void processFailedProjects(String uuid, String type) {
        utilMethods.updateSchedulerTraceId();
        SchedulerDetails schedulerDetails = new SchedulerDetails();
        schedulerDetails.setStartTime(LocalDateTime.now());
        schedulerDetails.setTraceId(MDC.get(CRON_TRACE_ID));
        schedulerDetails.setName(FAILED_ASSESSMENTS_JOB);
        schedulerDetails.setInitiatedType(type);
        String initiatedBy = StringUtils.isBlank(uuid) ? SYSTEM : utilMethods.getDisplayName(UUID.fromString(uuid));
        schedulerDetails.setInitiatedBy(initiatedBy);
        schedulerDetails.setStatus(IN_PROGRESS);
        schedulerDetails = saveSchedulerDetails(schedulerDetails);
        SchedulerConfig schedulerConfig = schedulerConfigRepository.findByKey("enableFailedProjectsJob");
//// MongoDB-related code has been commented out

        //        try {
//
//            if ((schedulerConfig != null && schedulerConfig.getValue().equalsIgnoreCase("true")) || (API.equalsIgnoreCase(type))) {
//                log.info("processFailedProjects job started");
//                Map<String, Integer> executedCount = assessmentService.processFailedProjects();
//                schedulerDetails.setStatus(COMPLETED);
//                schedulerDetails.setMessage("Executed Count: " + executedCount.toString());
//            } else {
//                log.info("enableFailedProjectsJob flag is missing or turnedOff");
//                schedulerDetails.setStatus(ABORTED);
//                schedulerDetails.setMessage("FAILED_ASSESSMENTS_JOB config was missing/turned-Off");
//            }
//        } catch (Exception ex) {
//            schedulerDetails.setStatus(FAILED_CAP);
//            schedulerDetails.setMessage(ex.getMessage());
//            log.error("Exception in processFailedProjects job", ex);
//        } finally {
//            schedulerDetails.setEndTime(LocalDateTime.now());
//            saveSchedulerDetails(schedulerDetails);
//            log.info("processFailedProjects job ended");
//            // Clear the trace ID from the MDC after the request is processed
//            MDC.remove(CRON_TRACE_ID);
//        }
    }

    public void changeProjectEndDate(String uuid, String type) {
        utilMethods.updateSchedulerTraceId();
        SchedulerDetails schedulerDetails = new SchedulerDetails();
        schedulerDetails.setStartTime(LocalDateTime.now());
        schedulerDetails.setTraceId(MDC.get(CRON_TRACE_ID));
        schedulerDetails.setName(PROJECT_END_DATE_CHECK_JOB);
        schedulerDetails.setInitiatedType(type);
        String initiatedBy = StringUtils.isBlank(uuid) ? SYSTEM : utilMethods.getDisplayName(UUID.fromString(uuid));
        schedulerDetails.setInitiatedBy(initiatedBy);
        schedulerDetails.setStatus(IN_PROGRESS);
        schedulerDetails = saveSchedulerDetails(schedulerDetails);
        log.info("changeProjectEndDate job started");
        try {
            Integer updatedCount = assessmentService.checkProjectStatus();
            schedulerDetails.setStatus(COMPLETED);
            schedulerDetails.setMessage("Executed Count: " + updatedCount);
        } catch (Exception ex) {
            schedulerDetails.setStatus(FAILED_CAP);
            schedulerDetails.setMessage(ex.getMessage());
            log.error("Exception in changeProjectEndDate job", ex);
        } finally {
            schedulerDetails.setEndTime(LocalDateTime.now());
            saveSchedulerDetails(schedulerDetails);
            log.info("changeProjectEndDate job ended");
            // Clear the trace ID from the MDC after the request is processed
            MDC.remove(CRON_TRACE_ID);
        }
    }

    public void refreshUsers(String uuid, String type) {
        utilMethods.updateSchedulerTraceId();
        SchedulerDetails schedulerDetails = new SchedulerDetails();
        schedulerDetails.setStartTime(LocalDateTime.now());
        schedulerDetails.setTraceId(MDC.get(CRON_TRACE_ID));
        schedulerDetails.setName(REFRESH_USERS_JOB);
        schedulerDetails.setInitiatedType(type);
        String initiatedBy = StringUtils.isBlank(uuid) ? SYSTEM : utilMethods.getDisplayName(UUID.fromString(uuid));
        schedulerDetails.setInitiatedBy(initiatedBy);
        schedulerDetails.setStatus(IN_PROGRESS);
        schedulerDetails = saveSchedulerDetails(schedulerDetails);
        log.info("update users job started");
        try {
            Integer updatedUserCount = userService.refreshUsers();
            schedulerDetails.setStatus(COMPLETED);
            schedulerDetails.setMessage("Executed Count: " + updatedUserCount);
        } catch (Exception ex) {
            schedulerDetails.setStatus(FAILED_CAP);
            schedulerDetails.setMessage(ex.getMessage());
            log.error("Exception in update users job", ex);
        } finally {
            schedulerDetails.setEndTime(LocalDateTime.now());
            saveSchedulerDetails(schedulerDetails);
            log.info("update users job ended");
            // Clear the trace ID from the MDC after the request is processed
            MDC.remove(CRON_TRACE_ID);
        }
    }

    private SchedulerDetails saveSchedulerDetails(SchedulerDetails details){
       return schedulerDetailsRepository.save(details);
    }
}
