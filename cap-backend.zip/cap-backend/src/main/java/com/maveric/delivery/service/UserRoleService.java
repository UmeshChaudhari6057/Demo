package com.maveric.delivery.service;

import com.maveric.delivery.model.embedded.UserRoleDto;
import com.maveric.delivery.responsedto.AssignUserRoleResponseDto;

public interface UserRoleService {
    AssignUserRoleResponseDto assignUserRole(UserRoleDto userRoleDtos);

    String updateUserRole(Long id, String role);
}
