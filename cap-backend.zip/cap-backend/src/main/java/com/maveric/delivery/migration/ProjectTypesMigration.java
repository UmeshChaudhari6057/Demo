package com.maveric.delivery.migration;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.ProjectType;
import com.maveric.delivery.mysqlrepository.ProjectTypemysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;


import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

//@ChangeUnit(id = "ProjectTypes", order = "001", author = "delivery-excellence", systemVersion = "1")

@Service
@Slf4j
@AllArgsConstructor
public class ProjectTypesMigration implements Migration{

   // private final MongoTemplate mongoTemplate;
	
	private ProjectTypemysqlRepository projectTypemysqlRepository;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/project-types.json";


    
    @Override
    public void before() {
        log.info("ProjectTypes Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("ProjectTypes Migration RollbackBeforeExecution");
    }

    @Transactional
    @Override
    public void migrationMethod() throws IOException {
//        log.info("ProjectTypes migrationMethod");
//        List<ProjectType> projectTypes= jsonFileReader.readJsonFileToList(filePath, ProjectType.class);
//        mongoTemplate.insertAll(projectTypes);
//        
        
        
        try {
            List<ProjectType> projectTypes = jsonFileReader.readJsonFileToList(filePath, ProjectType.class);

            if (!projectTypes.isEmpty()) {
            	projectTypemysqlRepository.saveAll(projectTypes);
                log.info("Migration completed: {} records inserted", projectTypes.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
    }

    
    @Override
    public void rollback() {
        log.info("ProjectTypes Migration RollbackBeforeExecution");
        projectTypemysqlRepository.deleteAll();
    }
}
