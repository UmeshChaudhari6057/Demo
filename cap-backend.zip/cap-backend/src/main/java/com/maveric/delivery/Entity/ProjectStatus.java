package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "project_status")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectStatus extends IdentifiedEntity{
	
	
	
	
	
 
    @Column(nullable = false)
    private String name;

    public ProjectStatus(long l, String name) {
        super();
    }
}
