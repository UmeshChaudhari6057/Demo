package com.maveric.delivery.model.embedded;

public enum TemplateStatus {

    Active,Inactive;
}
