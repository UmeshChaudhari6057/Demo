package com.maveric.delivery.service;


import com.maveric.delivery.requestdto.ArtifactFilterDto;
import com.maveric.delivery.requestdto.ArtifactRequestDto;
import com.maveric.delivery.responsedto.AttachmentDownloadDto;
import com.maveric.delivery.responsedto.ArtifactListDto;
import org.springframework.web.multipart.MultipartFile;

import javax.naming.directory.InvalidAttributesException;
import java.io.IOException;

import java.util.List;

import java.util.UUID;

public interface ArtifactService {
  ArtifactListDto saveArtifact(ArtifactRequestDto artifactRequestDto, UUID oid, Long projectId, MultipartFile file) throws InvalidAttributesException, IOException;
  List<ArtifactListDto> getAllArtifacts(UUID oid, Long projectId, ArtifactFilterDto filter);

  AttachmentDownloadDto getAttachmentDetails(Long artifactId,UUID oId);

  void checkAndDeleteAttachment(UUID userId,Long artifactId);

}
