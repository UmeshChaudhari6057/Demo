package com.maveric.delivery.Entity;

import java.util.List;
import java.util.UUID;

import com.maveric.delivery.model.embedded.TeamMemberStatus;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "team_member")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeamMember extends IdentifiedEntity {

    @Column(nullable = false)
    private Long projectId;

    private UUID userId;
    private String name;
    private String projectRole;
    private String location;

    @ElementCollection
    private List<String> skillSet;
    private TeamMemberStatus status;
    private Boolean isBillable;
    private Long startDate;
    private Long endDate;
    private Long allocation;
    private String createdBy;
    private Long createdAt;
    private String updatedBy;
    private Long updatedAt;
}
