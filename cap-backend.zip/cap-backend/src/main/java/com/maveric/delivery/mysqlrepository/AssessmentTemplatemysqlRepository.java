package com.maveric.delivery.mysqlrepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.TemplateStatus;

public interface AssessmentTemplatemysqlRepository extends JpaRepository<AssessmentTemplate, Long> {

    Optional<AssessmentTemplate> findByAssessmentTypeAndTemplateName(AssessmentCategoryType assessmentType, String templateName);

    List<AssessmentTemplate> findByAssessmentTypeAndStatus(AssessmentCategoryType assessmentType, TemplateStatus status);

    List<AssessmentTemplate> findByAssessmentTypeAndStatusAndProjectType(AssessmentCategoryType assessmentType,
                                                                         TemplateStatus status, String projectType);

    List<AssessmentTemplate> findByAssessmentType(AssessmentCategoryType assessmentType);

    AssessmentTemplate findByProjectTypeAndStatus(String projectType, TemplateStatus status);

    // Corrected method signature: assessmentType should be of type AssessmentCategoryType instead of String
    AssessmentTemplate findByAssessmentTypeAndStatus(String assessmentType, TemplateStatus status);
}
