package com.maveric.delivery.responsedto;

import lombok.Data;

@Data
public class AssessmentScoreDto {
    private String accountName;
    private String total;
}
