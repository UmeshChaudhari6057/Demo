package com.maveric.delivery.model.embedded;

public enum QuestionType {

    CHECK_BOX,RADIO_BUTTON,SLIDER,NUMERICAL;
}
