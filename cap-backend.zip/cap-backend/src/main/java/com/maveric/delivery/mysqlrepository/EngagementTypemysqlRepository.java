package com.maveric.delivery.mysqlrepository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.EngagementType;

public interface EngagementTypemysqlRepository extends JpaRepository<EngagementType,Long> {

}
