package com.maveric.delivery.Entity;

import java.util.UUID;

import com.maveric.delivery.model.embedded.AssessmentStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name = "assessment_history",
       indexes = {
           @Index(name = "idx_assessment_id", columnList = "assessmentId"),
           @Index(name = "idx_current_status", columnList = "currentStatus"),
           @Index(name = "idx_create_date", columnList = "createDate")
       }
)
public class AssessmentHistory extends IdentifiedEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-increment ID
    private Long id;

    @Column(nullable = false)
    private Long assessmentId;

    @Column(nullable = false)
    private Long projectId;

    @Column(nullable = false)
    private Long accountId;

    @Enumerated(EnumType.STRING)  // Store Enum as String
    @Column(nullable = false)
    private AssessmentStatus currentStatus;

    @Enumerated(EnumType.STRING)
    private AssessmentStatus previousStatus;

    @Column(nullable = false)
    private Long createDate;

    private Long assessmentStartDate;

    @Column(columnDefinition = "BINARY(16)", nullable = false)  // Store UUID efficiently
    private String createdBy;
}