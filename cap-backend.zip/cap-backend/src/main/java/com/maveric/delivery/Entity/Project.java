package com.maveric.delivery.Entity;

import java.util.List;

import jakarta.persistence.Index;

import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.DeliveryInformation;
import com.maveric.delivery.model.embedded.OtherInformation;
import com.maveric.delivery.model.embedded.ProjectClientInfo;

import com.maveric.delivery.model.embedded.ProjectStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "projects", indexes = {
        @Index(name = "idx_account_id", columnList = "account_id")
})
public class Project extends IdentifiedEntity {

    @ManyToOne
    @JoinColumn(name = "account_id", referencedColumnName = "id")
    private Account account;

    @Column(nullable = false)
    private String projectName;

    private String customerLOB;
    private String engagementType;

    @ElementCollection
    @CollectionTable(name = "project_tags", joinColumns = @JoinColumn(name = "project_id"))
    @Column(name = "tag")
    private List<String> tags;

    private String businessSubVertical;
    private Long startDate;
    private Long endDate;
    
    private ProjectStatus status;

    private Boolean isBillable;
    private String description;

    @Embedded
    private DeliveryInformation deliveryInfo;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "project", fetch = FetchType.LAZY)
    private List<DedRolesmy> dedRoles;

    @Embedded
    private ProjectClientInfo clientInformation;

    @Embedded
    private OtherInformation otherInformation;

    private String createdBy;
    private Long createdAt;
    private String updateBy;
    private Long updatedAt;

    private String projectDriverId;
    private String assessmentDriverId;
    private String artifactDriverId;
    
    public Project(Long id) {
        this.id = id;
    }

    public void setAccountId(Long accountId) {
        this.account = accountId != null ? new Account(accountId) : null;
    }

    public Long getAccountId() {
        return account != null ? account.getId() : null;
    }

}