package com.maveric.delivery.model.embedded;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Option {

	@Column(name = "option_index")
    private Integer index;
	@Column(name = "option_value")
    private String value;
    private boolean selected;
    private Double score;
}
