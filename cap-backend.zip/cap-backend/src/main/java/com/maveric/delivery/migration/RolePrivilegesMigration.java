package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.Entity.RolePrivileges;
import com.maveric.delivery.mysqlrepository.RolePrivilegesmysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "role-privileges-v.0.4", order = "001", author = "delivery-excellence", systemVersion = "1")
@Service
@Slf4j
@AllArgsConstructor
public class RolePrivilegesMigration implements Migration {

  //  private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/rolePrivileges.json";

   private final RolePrivilegesmysqlRepository rolePrivilegesmysqlRepository;
    
    @Override
    public void before() {
        log.info("RolePrivilegesMigration Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("RolePrivilegesMigration Migration RollbackBeforeExecution");
    }

    @Transactional
    @Override
    public void migrationMethod() throws IOException {
        log.info("RolePrivilegesMigration migrationMethod");
//        mongoTemplate.remove(new Query(),RolePrivileges.class);
//        List<RolePrivileges> roles= jsonFileReader.readJsonFileToList(filePath, RolePrivileges.class);
//            mongoTemplate.insertAll(roles);
            
            rolePrivilegesmysqlRepository.deleteAll();
            
            try {
                List<RolePrivileges> roles = jsonFileReader.readJsonFileToList(filePath, RolePrivileges.class);

                if (!roles.isEmpty()) {
                	rolePrivilegesmysqlRepository.saveAll(roles);
                    log.info("Migration completed: {} records inserted", roles.size());
                } else {
                    log.info("No data found to migrate.");
                }
            } catch (IOException e) {
                log.error("Error reading JSON file for migration", e);
                throw new RuntimeException("Migration failed! Rolling back...");
            }
    }

  
    @Override
    public void rollback() {
        log.info("RolePrivilegesMigration Migration RollbackBeforeExecution");
        rolePrivilegesmysqlRepository.deleteAll();
    }
}
