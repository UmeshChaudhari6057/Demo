package com.maveric.delivery.Entity;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
@Entity
@Table(name = "projectAssessmentDetails")
public class ProjectAssessmentDetails extends IdentifiedEntity{
	
   
	@Column(name = "project_id", nullable = false)
    private Long projectId;

    @Column(name = "assessment_id", nullable = false)
    private Long assessmentId;

    @Column(name = "remainder_date1")
    private Instant remainderDate1;

    @Column(name = "remainder_date2")
    private Instant remainderDate2;

    @Column(name = "remainder_date3")
    private Instant remainderDate3;

    @Column(name = "assessment_created_date")
    private Instant assessmentCreatedDate;

    @Column(name = "next_assessment_creation_date")
    private Instant nextAssessmentCreationDate;

}