package com.maveric.delivery.mapper;

import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.requestdto.PrivilegesDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;

@Mapper
public interface PrivilegesMapper {
    PrivilegesMapper MAPPER = Mappers.getMapper(PrivilegesMapper.class);

    default List<PrivilegesDetailsDto> toDtoList(List<Privileges> privileges){
        return CollectionUtils.isEmpty(privileges)? Collections.emptyList() : privileges.stream().map(this::toDto).toList();
    }

    default PrivilegesDetailsDto toDto(Privileges privileges){
        PrivilegesDetailsDto privilegesDetailsDto = new PrivilegesDetailsDto();

        privilegesDetailsDto.setName(privileges.getName());
        privilegesDetailsDto.setDescription(privileges.getDescription());
        privilegesDetailsDto.setValue(privileges.getValue());

        if (!CollectionUtils.isEmpty(privileges.getPrivileges())){

            privilegesDetailsDto.setPrivilegeDetails(toDtoPrivilegesList(privileges.getPrivileges()));
            List<String> privilegesList= privileges.getPrivileges().stream().map(Privileges::getValue).toList();
            privilegesDetailsDto.setPrivilegesList(privilegesList);
        }
        return privilegesDetailsDto;
    }

    default List<PrivilegesDto>  toDtoPrivilegesList(List<Privileges> privileges) {
        return CollectionUtils.isEmpty(privileges)? Collections.emptyList() : privileges.stream().map(this::toDtoPrivileges).toList();
    }

    default PrivilegesDto toDtoPrivileges(Privileges privileges) {
        PrivilegesDto privilegesDto = new PrivilegesDto();

        privilegesDto.setName(privileges.getName());
        privilegesDto.setDescription(privileges.getDescription());
        privilegesDto.setValue(privileges.getValue());
        if (!CollectionUtils.isEmpty(privileges.getPrivileges())){
            privilegesDto.setPrivileges(toDtoPrivilegesList(privileges.getPrivileges()));
        }
        return privilegesDto;
    }



}


