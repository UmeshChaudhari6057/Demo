package com.maveric.delivery.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.maveric.delivery.model.embedded.CheckBoxOptions;

import com.maveric.delivery.model.embedded.MyTemplateCategory;
import com.maveric.delivery.model.embedded.Numerical;
import com.maveric.delivery.model.embedded.QuestionType;
import com.maveric.delivery.model.embedded.RadioOptions;
import com.maveric.delivery.model.embedded.Slider;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "questions")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private int number;

	@NotBlank(message = "Question text is required")
	@Column(nullable = false)
	private String questionText;

	private String subHeading;
	private boolean attachmentRequired;
	private String fileName;
	private String documentId;
	private boolean comments;
	private String commentText;

	@Enumerated(EnumType.STRING)
	private QuestionType type;

	// Convert embedded objects into JSON strings or create separate tables
	@Embedded
	private CheckBoxOptions checkBoxOptions; // Store as JSON string or map separately

	@Embedded
	private RadioOptions radioOptions;

	@Embedded
	private Numerical numerical;

	@Embedded
	private Slider slider;

	private String reviewerComment;

	@JsonProperty("isNotApplicable")
	private boolean isNotApplicable;

	@JsonProperty("isNotApplicableUserResponse")
	private boolean isNotApplicableUserResponse;

	private Double questionLevelScore;
	private Integer weightage;

	@ManyToOne
	@JoinColumn(name = "assessment_template_id", nullable = false)
	private AssessmentTemplate assessmentTemplate;
	
	@ManyToOne
    @JoinColumn(name = "template_category_id", nullable = false)
    private MyTemplateCategory templateCategory;

}

