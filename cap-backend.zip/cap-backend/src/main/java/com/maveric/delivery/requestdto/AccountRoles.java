package com.maveric.delivery.requestdto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountRoles {
    @NotNull(message = "User ID is required")
    private UUID userId;
    @NotBlank(message = "Name is required")
    private String name;

    public AccountRoles(String uuid, String aachisRishidevIyappan) {
    }
}
