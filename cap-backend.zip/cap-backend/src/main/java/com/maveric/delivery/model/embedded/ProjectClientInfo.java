package com.maveric.delivery.model.embedded;


import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectClientInfo {
    @Size(min = 3, max = 500, message = "Client Notes must be between 3 and 500 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- \\n!@#$%*?/:;'\"\\[\\]{}|=+_]+$", message = "Client notes can only contain alphabets, numbers and special characters like(!@#$%&*().,/?:;'\"[]{}|=+-_ )")
    private String clientNotes;
    @Valid
    @Size(max = 5,message = "The number of client contacts cannot exceed 5")
    @ElementCollection
    private List<ClientContacts> clientContacts;

}
