package com.maveric.delivery.service;


import static com.maveric.delivery.utils.Constants.ACCOUNT_ID;
import static com.maveric.delivery.utils.Constants.ALL;
import static com.maveric.delivery.utils.Constants.CREATE_DATE;
import static com.maveric.delivery.utils.Constants.CURRENT_STATUS;
import static com.maveric.delivery.utils.Constants.DATE_ON_BOARDED;
import static com.maveric.delivery.utils.Constants.ID;
import static com.maveric.delivery.utils.Constants.PROJECT_ID;
import static com.maveric.delivery.utils.Constants.START_DATE;
import static com.maveric.delivery.utils.Constants.STATUS;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;

import org.springframework.stereotype.Service;

import com.maveric.delivery.Entity.AssessmentHistory;
import com.maveric.delivery.Entity.IdentifiedEntity;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.DeliveryInformation;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.requestdto.DashboardFilterDto;
import com.maveric.delivery.requestdto.DateRangeDto;
import com.maveric.delivery.responsedto.AssessmentDetailsDto;
import com.maveric.delivery.responsedto.AssessmentTrendsDetailsDto;
import com.maveric.delivery.responsedto.DashboardDetailsDto;
import com.maveric.delivery.utils.UtilMethods;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final UtilMethods utilMethods;
    private final DecimalFormat formatter = new DecimalFormat("##0.00");
  //  private final MongoTemplate mongoTemplate;

    @Override
    public DashboardDetailsDto fetchDashboardDetails(DashboardFilterDto dashboardFilterDto) {
        log.info("DashboardServiceImpl.fetchDashboardDetails >> Start");
        DashboardDetailsDto dashboardDetailsDto = new DashboardDetailsDto();
        getAccountSummary(dashboardDetailsDto, dashboardFilterDto);
        getAssessmentSummary(dashboardDetailsDto, dashboardFilterDto);
        log.info("DashboardServiceImpl.fetchDashboardDetails >> End");
        return dashboardDetailsDto;
    }

    @Override
    public AssessmentDetailsDto fetchTopAssessment() {
//        log.info("DashboardServiceImpl.fetchTopAssessment >> Start");
//        AssessmentDetailsDto topAssessmentDetailsDto = new AssessmentDetailsDto();
//        Criteria criteria = new Criteria();
//        criteria.and(STATUS).is(AccountStatus.Active.name());
//        Query query = new Query(criteria);
//        query.fields().include(ID);
//        List<Account> activeAccounts = mongoTemplate.find(query, Account.class);
//        List<Long> accountIds = activeAccounts.stream().filter(Objects::nonNull).map(IdentifiedEntity::getId).toList();
//        criteria = new Criteria();
//        if (!CollectionUtils.isEmpty(accountIds)){
//            criteria.and(ACCOUNT_ID).in(accountIds);
//        }
//        query = new Query(criteria);
//        List<Assessment> assessments = mongoTemplate.find(query,Assessment.class);
//        Map<Long, List<Assessment>> submissionMap = assessments.stream().collect(Collectors.groupingBy(Assessment::getAccountId));
//
//        List<AssessmentSubmissionDto> topAssessmentSubmission =  submissionMap.entrySet().stream().map(entry -> {
//            AssessmentSubmissionDto assessmentSubmissionDto = new AssessmentSubmissionDto();
//            double reviewedCount=   entry.getValue().stream().filter(assessment -> AssessmentStatus.REVIEWED.equals(assessment.getStatus())).count();
//            double totalCount= entry.getValue().size();
//            assessmentSubmissionDto.setAccountId(entry.getKey());
//            assessmentSubmissionDto.setReviewed((long) reviewedCount);
//            assessmentSubmissionDto.setTotal((long) totalCount);
//            assessmentSubmissionDto.setPercentage(Double.parseDouble( formatter.format((reviewedCount/ totalCount)* 100.00)));
//            return assessmentSubmissionDto;
//        }).toList();
//
//        topAssessmentSubmission = topAssessmentSubmission.stream().sorted(Comparator.comparingDouble(AssessmentSubmissionDto::getPercentage).reversed()).limit(3).toList();
//
//        topAssessmentSubmission.forEach(entry -> {
//            Account account = mongoTemplate.findById(entry.getAccountId(), Account.class);
//            if (Objects.nonNull(account))
//                entry.setAccountName(account.getAccountName());
//        });
//        topAssessmentDetailsDto.setSubmission(topAssessmentSubmission);
//        List<AssessmentScoreDto> topAssessmentScore = new ArrayList<>();
//        Map<Long, List<Assessment>> assessmentAccountGroup = assessments.stream().filter(assessment -> AssessmentStatus.REVIEWED.equals(assessment.getStatus())).collect(Collectors.groupingBy(Assessment::getAccountId));
//        Map<Long, Double> assessmentScore = new HashMap<>();
//        assessmentAccountGroup.forEach((key, value) -> {
//            double avg = value.stream().filter(Objects::nonNull).mapToDouble(assessment ->
//                    Objects.nonNull(assessment.getScore()) ? assessment.getScore() : 0.0
//            ).average().orElse(0.0);
//            assessmentScore.put(key, avg);
//        });
//        List<Map.Entry<Long, Double>> topScore = assessmentScore.entrySet().stream()
//                .sorted(Map.Entry.<Long, Double>comparingByValue().reversed())
//                .limit(3).toList();
//
//
//        topScore.forEach(entry -> {
//            AssessmentScoreDto assessmentScoreDto = new AssessmentScoreDto();
//            Account account = mongoTemplate.findById(entry.getKey(), Account.class);
//            if (Objects.nonNull(account))
//                assessmentScoreDto.setAccountName(account.getAccountName());
//            assessmentScoreDto.setTotal(formatter.format(entry.getValue()));
//            topAssessmentScore.add(assessmentScoreDto);
//        });
//        topAssessmentDetailsDto.setScore(topAssessmentScore);
//        log.info("DashboardServiceImpl.fetchTopAssessment >> End");
//        return topAssessmentDetailsDto;

    	return new  AssessmentDetailsDto();
    }

    @Override
    public AssessmentTrendsDetailsDto fetchDashboardTrendsDetails(DashboardFilterDto dashboardFilterDto) {
        AssessmentTrendsDetailsDto assessmentTrendsDetailsDto = new AssessmentTrendsDetailsDto();
        getAverageTrend(assessmentTrendsDetailsDto, dashboardFilterDto);
        getScoreTrend(assessmentTrendsDetailsDto, dashboardFilterDto);
        return assessmentTrendsDetailsDto;
    }

    private void getScoreTrend(AssessmentTrendsDetailsDto assessmentTrendsDetailsDto, DashboardFilterDto dashboardFilterDto) {

//        log.info("DashboardServiceImpl.getScoreTrend >> Start");
//        Criteria baseCriteria = new Criteria();
//        ChartDto chartDto = new ChartDto();
//        List<String> xAxisLabel = new ArrayList<>();
//
//        List<ChartXAxisDataDto> xAxisValues = new ArrayList<>();
//
//        if (Objects.nonNull(dashboardFilterDto.getAccountId()) && dashboardFilterDto.getAccountId() > 0) {
//            baseCriteria.and(ACCOUNT_ID).is(dashboardFilterDto.getAccountId());
//        }
//        if (Objects.nonNull(dashboardFilterDto.getProjectId()) && dashboardFilterDto.getProjectId() > 0) {
//            baseCriteria.and(PROJECT_ID).is(dashboardFilterDto.getProjectId());
//        }
//        if(!mongoTemplate.exists(new Query(baseCriteria),Assessment.class)) {
//            log.info("DashboardServiceImpl.getScoreTrend >> No Assessment");
//            return;
//        }
//        Query baseQuery;
//        List<Double> score = new ArrayList<>();
//        List<Long> totalAssByMonth = new ArrayList<>();
//
//
//        List<DateRangeDto> dateRangeDtos = utilMethods.getChatDateRange(dashboardFilterDto.getDateRange());
//        int index = 0;
//        AtomicReference<Double> totalScore = new AtomicReference<>(0.0);
//
//
//        long totalReviewdAssessment = 0;
//
//        for (DateRangeDto dateRangeDto : dateRangeDtos) {
//
//            if (LAST_3_MONTHS.equalsIgnoreCase(dashboardFilterDto.getDateRange())) {
//                xAxisLabel.add(WEEK + " " + ++index);
//            } else {
//                LocalDate date = Instant.ofEpochMilli(dateRangeDto.getStartDate())
//                        .atZone(ZoneId.systemDefault())
//                        .toLocalDate();
//                xAxisLabel.add(date.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()) + " " + date.getYear());
//            }
//
//
//            Criteria dateCriteria = new Criteria().and(STATUS).is(AssessmentStatus.REVIEWED.name()).and(REVIEWED_ON).gte(dateRangeDto.getStartDate()).lte(dateRangeDto.getEndDate());
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            List<Assessment> assessments = mongoTemplate.find(baseQuery, Assessment.class);
//            totalReviewdAssessment = totalReviewdAssessment+assessments.size();
//            double avg = assessments.stream().mapToDouble(assessment ->{
//
//                       Double val= Objects.nonNull(assessment.getScore()) ? assessment.getScore() : 0.0;
//                       totalScore.set(totalScore.get() + val);
//                return val;
//                    }
//            ).average().orElse(0.0);
//            score.add(Double.parseDouble(formatter.format(avg)));
//            totalAssByMonth.add((long) assessments.size());
//
//        }
//        Double avgScore = totalScore.get()/ totalReviewdAssessment;
//        xAxisValues.add(ChartXAxisDataDto.builder().name(SCORE).data(score).total(totalAssByMonth).build());
//        chartDto.setXAxisLabel(xAxisLabel);
//        chartDto.setXAxisValues(xAxisValues);
//        chartDto.setAverage(formatter.format(avgScore));
//        assessmentTrendsDetailsDto.setScoreTrend(chartDto);
//        log.info("DashboardServiceImpl.getScoreTrend >> End");
    }

    private void getAverageTrend(AssessmentTrendsDetailsDto assessmentTrendsDetailsDto, DashboardFilterDto dashboardFilterDto) {

//        log.info("DashboardServiceImpl.getAverageTrend >> Start");
//        Criteria baseCriteria = new Criteria();
//        ChartDto chartDto = new ChartDto();
//        List<String> xAxisLabel = new ArrayList<>();
//
//        List<ChartXAxisDataDto> xAxisValues = new ArrayList<>();
//
//        if (Objects.nonNull(dashboardFilterDto.getAccountId()) && dashboardFilterDto.getAccountId() > 0) {
//            baseCriteria.and(ACCOUNT_ID).is(dashboardFilterDto.getAccountId());
//        }
//        if (Objects.nonNull(dashboardFilterDto.getProjectId()) && dashboardFilterDto.getProjectId() > 0) {
//            baseCriteria.and(PROJECT_ID).is(dashboardFilterDto.getProjectId());
//        }
//        Query baseQuery;
//
//        List<Double> submitted = new ArrayList<>();
//        List<Double> overdue = new ArrayList<>();
//        List<Double> reviewed = new ArrayList<>();
//        if(!mongoTemplate.exists(new Query(baseCriteria),Assessment.class)) {
//            log.info("DashboardServiceImpl.getAverageTrend >> No Assessment");
//            return;
//        }
//
//        List<DateRangeDto> dateRangeDtos = utilMethods.getChatDateRange(dashboardFilterDto.getDateRange());
//        Collections.reverse(dateRangeDtos);
//        int index = dateRangeDtos.size();
//        List<AssessmentHistory> assessmentHistories;
//        Set<Long> countedSubIds = new HashSet<>();
//        Set<Long> countedReviewedIds = new HashSet<>();
//        Set<Long> countedOverDueIds = new HashSet<>();
//        for (DateRangeDto dateRangeDto : dateRangeDtos) {
//            Set<Long> ids ;
//            if (LAST_3_MONTHS.equalsIgnoreCase(dashboardFilterDto.getDateRange())) {
//                xAxisLabel.add(WEEK + " " + index--);
//            } else {
//                LocalDate date = Instant.ofEpochMilli(dateRangeDto.getStartDate())
//                        .atZone(ZoneId.systemDefault())
//                        .toLocalDate();
//                xAxisLabel.add(date.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()) + " " + date.getYear());
//            }
//
//            Criteria dateCriteria = new Criteria().and(CREATE_DATE).gte(dateRangeDto.getStartDate()).lte(dateRangeDto.getEndDate());
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            assessmentHistories = mongoTemplate.find(baseQuery.addCriteria(Criteria.where(CURRENT_STATUS).is(AssessmentStatus.SUBMITTED.name()).and(ASSESSMENT_ID).nin(countedSubIds)), AssessmentHistory.class);
//            ids =assessmentHistories.stream().map(AssessmentHistory::getAssessmentId).collect(Collectors.toSet());
//            submitted.add(UtilMethods.integerToDouble(ids.size()));
//            countedSubIds.addAll(ids);
//
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            assessmentHistories = mongoTemplate.find(baseQuery.addCriteria(Criteria.where(CURRENT_STATUS).is(AssessmentStatus.OVERDUE.name()).and(ASSESSMENT_ID).nin(countedOverDueIds)), AssessmentHistory.class);
//            ids =assessmentHistories.stream().map(AssessmentHistory::getAssessmentId).collect(Collectors.toSet());
//            overdue.add(UtilMethods.integerToDouble(ids.size()));
//            countedOverDueIds.addAll(ids);
//
//            baseQuery = new Query(baseCriteria).addCriteria(dateCriteria);
//            assessmentHistories = mongoTemplate.find(baseQuery.addCriteria(Criteria.where(CURRENT_STATUS).is(AssessmentStatus.REVIEWED.name()).and(ASSESSMENT_ID).nin(countedReviewedIds)), AssessmentHistory.class);
//            ids =assessmentHistories.stream().map(AssessmentHistory::getAssessmentId).collect(Collectors.toSet());
//            reviewed.add(UtilMethods.integerToDouble(ids.size()));
//            countedReviewedIds.addAll(ids);
//        }
//        Collections.reverse(submitted);
//                Collections.reverse(reviewed);
//                        Collections.reverse(overdue);
//        Collections.reverse(xAxisLabel);
//
//        xAxisValues.add(ChartXAxisDataDto.builder().name(SUBMITTED).data(submitted).build());
//        xAxisValues.add(ChartXAxisDataDto.builder().name(REVIEWED).data(reviewed).build());
//        xAxisValues.add(ChartXAxisDataDto.builder().name(OVERDUE).data(overdue).build());
//        chartDto.setXAxisLabel(xAxisLabel);
//        chartDto.setXAxisValues(xAxisValues);
//        assessmentTrendsDetailsDto.setAverageTrend(chartDto);
//        log.info("DashboardServiceImpl.getAverageTrend >> End");
    	
    }

    private void getAssessmentSummary(DashboardDetailsDto dashboardDetailsDto, DashboardFilterDto dashboardFilterDto) {
//        log.info("DashboardServiceImpl.getAssessmentSummary >> Start");
//        Criteria criteria = new Criteria();
//
//        if (Objects.nonNull(dashboardFilterDto.getAccountId()) && dashboardFilterDto.getAccountId() > 0) {
//            criteria.and(ACCOUNT_ID).is(dashboardFilterDto.getAccountId());
//        }
//        if (Objects.nonNull(dashboardFilterDto.getProjectId()) && dashboardFilterDto.getProjectId() > 0) {
//            criteria.and(PROJECT_ID).is(dashboardFilterDto.getProjectId());
//        }
//        if (StringUtils.isNotBlank(dashboardFilterDto.getDateRange()) && !ALL.equalsIgnoreCase(dashboardFilterDto.getDateRange())) {
//            DateRangeDto dateRangeDto = utilMethods.getDateRange(dashboardFilterDto.getDateRange());
//            criteria.and(INITIATED_ON).gte(dateRangeDto.getStartDate());
//        }
//        Query query = new Query(criteria);
//        long count;
//
//        count = mongoTemplate.count(query, Assessment.class);
//        dashboardDetailsDto.setTotalAssessment(count);
//
//        count = mongoTemplate.count(query.addCriteria(Criteria.where(STATUS).is(AssessmentStatus.SUBMITTED.name())), Assessment.class);
//        dashboardDetailsDto.setSubmitted(count);
//
//        query = new Query(criteria);
//        count = mongoTemplate.count(query.addCriteria(Criteria.where(STATUS).is(AssessmentStatus.OVERDUE.name())), Assessment.class);
//        dashboardDetailsDto.setOverdue(count);
//
//        query = new Query(criteria);
//        count = mongoTemplate.count(query.addCriteria(Criteria.where(STATUS).is(AssessmentStatus.REVIEWED.name())), Assessment.class);
//        dashboardDetailsDto.setReviewed(count);
//
//        query = new Query(criteria);
//        count = mongoTemplate.count(query.addCriteria(Criteria.where(STATUS).is(AssessmentStatus.PENDING.name())), Assessment.class);
//        dashboardDetailsDto.setPending(count);
//
//        query = new Query(criteria);
//        count = mongoTemplate.count(query.addCriteria(Criteria.where(STATUS).in(List.of(AssessmentStatus.IN_PROGRESS.name(), AssessmentStatus.OVERDUE_IN_PROGRESS.name()))), Assessment.class);
//        dashboardDetailsDto.setInProgress(count);
//
//        query = new Query(criteria);
//        count = mongoTemplate.count(query.addCriteria(Criteria.where(STATUS).is(AssessmentStatus.EXPIRED.name())), Assessment.class);
//        dashboardDetailsDto.setExpired(count);
//        countTotalSubmittedAndReviewed(dashboardDetailsDto,dashboardFilterDto);
//        log.info("DashboardServiceImpl.getAssessmentSummary >> End");
    }
   private  void countTotalSubmittedAndReviewed (DashboardDetailsDto dashboardDetailsDto, DashboardFilterDto dashboardFilterDto){
//       Criteria criteria = new Criteria();
//        if (Objects.nonNull(dashboardFilterDto.getAccountId()) && dashboardFilterDto.getAccountId() > 0) {
//           criteria.and(ACCOUNT_ID).is(dashboardFilterDto.getAccountId());
//       }
//       if (Objects.nonNull(dashboardFilterDto.getProjectId()) && dashboardFilterDto.getProjectId() > 0) {
//           criteria.and(PROJECT_ID).is(dashboardFilterDto.getProjectId());
//       }
//       if (StringUtils.isNotBlank(dashboardFilterDto.getDateRange()) && !ALL.equalsIgnoreCase(dashboardFilterDto.getDateRange())) {
//           DateRangeDto dateRangeDto = utilMethods.getDateRange(dashboardFilterDto.getDateRange());
//           criteria.and(CREATE_DATE).gte(dateRangeDto.getStartDate());
//       }
//       Query query = new Query(criteria);
//       query.with(Sort.by(Sort.Direction.DESC, CREATE_DATE));
//       List<AssessmentHistory> assessmentHistories = mongoTemplate.find(query.addCriteria(Criteria.where(CURRENT_STATUS).in(List.of(AssessmentStatus.SUBMITTED.name(),AssessmentStatus.REVIEWED.name()))), AssessmentHistory.class);
//
//       Map<AssessmentStatus, Integer> statusCounts = assessmentHistories.stream()
//               .collect(Collectors.groupingBy(AssessmentHistory::getCurrentStatus, Collectors.mapping(AssessmentHistory::getAssessmentId, Collectors.collectingAndThen(Collectors.toSet(), Set::size))));
//
//        dashboardDetailsDto.setTotalSubmitted(utilMethods.integerToLong(statusCounts.get(AssessmentStatus.SUBMITTED)));
//
//        dashboardDetailsDto.setTotalReviewed(utilMethods.integerToLong(statusCounts.get(AssessmentStatus.REVIEWED)));
    }

    private void getAccountSummary(DashboardDetailsDto dashboardDetailsDto, DashboardFilterDto dashboardFilterDto) {
//        log.info("DashboardServiceImpl.getAccountSummary >> Start");
//        // Account Section
//        Criteria criteria = new Criteria();
//        criteria.and(STATUS).is(AccountStatus.Active.name());
//        if (Objects.nonNull(dashboardFilterDto.getAccountId()) && dashboardFilterDto.getAccountId() > 0) {
//            criteria.and(ID).is(dashboardFilterDto.getAccountId());
//        }
//        if (StringUtils.isNotBlank(dashboardFilterDto.getDateRange()) && !ALL.equalsIgnoreCase(dashboardFilterDto.getDateRange())) {
//            DateRangeDto dateRangeDto = utilMethods.getDateRange(dashboardFilterDto.getDateRange());
//            criteria.and(DATE_ON_BOARDED).gte(dateRangeDto.getStartDate());
//        }
//        Query query = new Query(criteria);
//        List<Account> accounts = mongoTemplate.find(query, Account.class);
//        dashboardDetailsDto.setAccounts((long) accounts.size());
//        List<Long> accountIds = accounts.stream().filter(Objects::nonNull).map(IdentifiedEntity::getId).toList();
//        // Project Section
//        criteria = new Criteria();
//        criteria.and(STATUS).is(ProjectStatus.Active.name());
//        if (Objects.nonNull(dashboardFilterDto.getProjectId()) && dashboardFilterDto.getProjectId() > 0) {
//            criteria.and(ID).is(dashboardFilterDto.getProjectId());
//        } else {
//            criteria.and(ACCOUNT_ID).in(accountIds);
//        }
//        if (StringUtils.isNotBlank(dashboardFilterDto.getDateRange()) && !ALL.equalsIgnoreCase(dashboardFilterDto.getDateRange())) {
//            DateRangeDto dateRangeDto = utilMethods.getDateRange(dashboardFilterDto.getDateRange());
//            criteria.and(START_DATE).gte(dateRangeDto.getStartDate());
//        }
//        query = new Query(criteria);
//        List<Project> projects = mongoTemplate.find(query, Project.class);
//        dashboardDetailsDto.setProjects((long) projects.size());
//        Long projectTypes = projects.stream().map(Project::getDeliveryInfo).map(DeliveryInformation::getProjectType).distinct().count();
//        dashboardDetailsDto.setProjectTypes(projectTypes);
//        log.info("DashboardServiceImpl.getAccountSummary >> End");
    }


}
