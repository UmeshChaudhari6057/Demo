package com.maveric.delivery.requestdto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DedRolesDto {
    private UUID oid;
    private Long accountId;
    private Long projectId;
    private String name;
    private String role;
}