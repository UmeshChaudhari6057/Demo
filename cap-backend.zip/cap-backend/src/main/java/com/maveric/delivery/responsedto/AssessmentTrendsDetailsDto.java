package com.maveric.delivery.responsedto;

import lombok.Data;

@Data
public class AssessmentTrendsDetailsDto {

    private ChartDto averageTrend;
    private ChartDto scoreTrend;

}
