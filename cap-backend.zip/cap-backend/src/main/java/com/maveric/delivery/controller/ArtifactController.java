package com.maveric.delivery.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.Entity.Artifact;
import com.maveric.delivery.requestdto.ArtifactFilterDto;
import com.maveric.delivery.requestdto.ArtifactRequestDto;
import com.maveric.delivery.responsedto.AttachmentDownloadDto;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.responsedto.ArtifactListDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ArtifactService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.UtilMethods;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.naming.directory.InvalidAttributesException;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;
import static com.maveric.delivery.utils.Constants.CREATE;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Artifact Management", description = "Endpoints for managing Artifacts")
public class ArtifactController {
    private final ArtifactService artifactService;
    private final ValidateApiAccess validateApiAccess;
    private final UtilMethods utilMethods;
    private final ObjectMapper objectMapper;

    @Operation(summary = "Get All Artifacts",description = "Api to Get All Artifacts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch Artifacts Successfully"),
            @ApiResponse(responseCode = "404", description = "Artifacts not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/artifacts")
    public ResponseEntity<ResponseDto<List<ArtifactListDto>>> fetchAllArtifacts(HttpServletRequest servletRequest, @RequestParam("projectId") Long projectId) {
        log.info("ArtifactController::FetchAllArtifacts() started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ARTIFACTS,VIEW_ALL,VIEW_ASSOCIATED);
        List<ArtifactListDto> artifactListList=artifactService.getAllArtifacts(rolesDto.getOid(),projectId,new ArtifactFilterDto());
        log.info("ArtifactController::FetchAllArtifacts() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, SuccessMessage.ARTIFACT_LIST_FETCHED.getCode(), SuccessMessage.ARTIFACT_LIST_FETCHED.getMessage(),null, artifactListList));
    }

    @Operation(summary = "Save Artifact",description = "Api to Save Artifacts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Saved artifact successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/artifacts",consumes = {"multipart/form-data"})
    public ResponseEntity<ResponseDto<ArtifactListDto>> saveArtifact(HttpServletRequest servletRequest, @RequestPart @Valid String request, @RequestParam("projectId") Long projectId, @RequestPart(value = "file",required = false) MultipartFile file) throws InvalidAttributesException, IOException {
        log.info("ArtifactController::Saving artifacts: {}");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ARTIFACTS,VIEW_ALL,VIEW_ASSOCIATED);
        ArtifactRequestDto artifactRequestDto = objectMapper.readValue(request,ArtifactRequestDto.class);
        ArtifactListDto createdArtifact = artifactService.saveArtifact(artifactRequestDto,rolesDto.getOid(),projectId,file);
        log.info("Artifact saved successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.ARTIFACT_CREATED.getCode(), SuccessMessage.ARTIFACT_CREATED.getMessage(), null, createdArtifact));
    }
    @Operation(summary = "Download Artifact",description = "Api to download Artifact")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Artifact downloaded successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "artifacts/{artifactId}/attachment-download")
    public ResponseEntity<Resource> downloadArtifact(HttpServletRequest servletRequest, @PathVariable("artifactId") Long artifactId) throws InvalidAttributesException, IOException {
        log.info("ArtifactController::Download artifacts: {}");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ARTIFACTS,VIEW_ALL,VIEW_ASSOCIATED);
        AttachmentDownloadDto downloadedArtifact = artifactService.getAttachmentDetails(artifactId,rolesDto.getOid());
        log.info("Artifact download successfully");
        return ResponseEntity.ok().contentType(MediaType.valueOf(downloadedArtifact.getType())).header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + downloadedArtifact.getName() + "\"") .body((new InputStreamResource(downloadedArtifact.getDownloadedInputStream()) ));
    }


    @Operation(summary = "Delete Artifact",description = "Api to Delete Artifact")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Artifact deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @DeleteMapping(path = "artifacts/{artifactId}/attachment-delete")
    public ResponseEntity<ResponseDto> deleteArtifact(HttpServletRequest servletRequest, @PathVariable("artifactId") Long artifactId) throws InvalidAttributesException, IOException {
        log.info("ArtifactController::Download artifacts: {}");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ARTIFACTS,VIEW_ALL,VIEW_ASSOCIATED);
        artifactService.checkAndDeleteAttachment(rolesDto.getOid(),artifactId);
        log.info("Artifact download successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.ARTIFACT_DELETED.getCode(), SuccessMessage.ARTIFACT_DELETED.getMessage(), null, null));
    }

    @Operation(summary = "Get Filtered Artifacts",description = "Api to Get Filtered Artifacts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch Filtered Artifacts Successfully"),
            @ApiResponse(responseCode = "404", description = "Artifacts not Present in DB"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/artifacts/filters")
    public ResponseEntity<ResponseDto<List<ArtifactListDto>>> fetchFilteredArtifacts(HttpServletRequest servletRequest,@RequestParam("projectId") String projectId, @RequestBody ArtifactFilterDto filterRequestDto) {
        log.info("ArtifactController::FetchAllArtifacts() started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ARTIFACTS,VIEW_ALL,VIEW_ASSOCIATED);

       List<ArtifactListDto> artifacts=artifactService.getAllArtifacts( rolesDto.getOid(),utilMethods.stringToLong(projectId),filterRequestDto);
        log.info("ArtifactController::FetchAllArtifacts() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, SuccessMessage.ARTIFACT_LIST_FETCHED.getCode(), SuccessMessage.ARTIFACT_LIST_FETCHED.getMessage(),null, artifacts));
    }

}
