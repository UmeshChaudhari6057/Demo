package com.maveric.delivery.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "countries")
@Data
@NoArgsConstructor

public class Country extends IdentifiedEntity{
	    

	    @Column(nullable = false, unique = true)
	    private String name;

	    @Column(nullable = false, unique = true, length = 3)
	    private String code;
	    
	    public Country(String name, String code) {
	        this.name = name;
	        this.code = code;
	    }
}
