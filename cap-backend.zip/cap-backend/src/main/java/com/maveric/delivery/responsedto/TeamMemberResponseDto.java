package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.TeamMemberStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeamMemberResponseDto {

   private String name;
   private UUID userId;
    private String projectRole;
    private String location;
    private List<String> skillSet;
    private Boolean isBillable;
    private Long startDate;
    private Long endDate;
    private Long allocation;
    private TeamMemberStatus status;
    private String createdBy;
    private Long createdAt;
    private String updatedBy;
    private Long updatedAt;
}

