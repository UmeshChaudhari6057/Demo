package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

import com.maveric.delivery.Entity.Template;

public interface TemplatemysqlRepository extends JpaRepository<Template,Long> {
	Optional<Template> findByType(String type);
}
