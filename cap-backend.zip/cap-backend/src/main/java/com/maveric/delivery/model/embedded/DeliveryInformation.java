package com.maveric.delivery.model.embedded;

import com.maveric.delivery.requestdto.AccountRoles;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class DeliveryInformation {
    private String projectType;
    @ElementCollection
    private List<BaseInfo> assessmentTemplates;
    private String frequency;
    @Size(min = 3, max = 500, message = "Delivery Notes must be between 3 and 500 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,\\.\\&\\(\\)\\- ]+$", message = "Delivery Notes can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String deliveryNotes;
    private LocalDate assessmentStartDate;

}
