package com.maveric.delivery.requestdto;

import lombok.Data;

@Data
public class DateRangeDto {

    private Long startDate;
    private Long endDate;
}
