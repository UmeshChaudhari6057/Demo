package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.TeamMemberStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeamMemberDto {

    @NotBlank(message = "Team Member name is required")
    private String name;
    private UUID userId;
    private Long projectId;
    @NotBlank(message = "Project Role is required")
    private String projectRole;
    @NotBlank(message = "Location is required")
    private String location;
    @Size(max = 5, message = "A maximum of 5 skills are allowed")
    @Valid
    private List<@Pattern(regexp = "^[a-zA-Z0-9 +#&-]{3,25}$",
            message = "Skill must be between 3 and 25 characters long " +
                    "and can only contain alphabets, numbers, '&','#','+' and hyphen") String> skillSet;
    @NotNull(message = "Billable is required")
    private Boolean isBillable;
    @NotNull(message = "Start Date is required")
    private Long startDate;
    @NotNull(message = "End Date is required")
    private Long endDate;
    @NotNull(message = "Allocation is required")
    @Min(value = 0, message = "Allocation must be at least 0")
    @Max(value = 100, message = "Allocation must be at most 100")
    private Long allocation;
    private TeamMemberStatus status;
}
