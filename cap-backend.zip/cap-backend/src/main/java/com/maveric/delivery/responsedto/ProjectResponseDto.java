package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.OtherInformation;
import com.maveric.delivery.model.embedded.ProjectClientInfo;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.requestdto.DeliveryInformationDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectResponseDto {
    private Long accountId;
    private String accountName;
    private Long projectId;
    private String projectName;
    private String customerLOB;
    private String engagementType;
    private List<String> tags;
    private String businessSubVertical;
    private Long startDate;
    private Long endDate;
    private ProjectStatus status;
    private String isBillable;
    private String description;
    private DeliveryInformationDto deliveryInfo;
    private ProjectClientInfo clientInformation;
    private OtherInformation otherInformation;
    private List<String> privileges;
}
