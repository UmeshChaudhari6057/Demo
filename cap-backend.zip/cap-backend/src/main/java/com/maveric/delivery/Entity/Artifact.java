package com.maveric.delivery.Entity;

import java.util.UUID;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name="artifact")
public class Artifact extends IdentifiedEntity{
  private Long projectId;
  private String name;
  private String type;
  private String link;
  private String comments;
//Flattened Attachment fields
  private String attachmentSharepointId; // attachmentId from SharePoint
  private String attachmentName;         // File name
  private String attachmentLink;         // Download link
  private String attachmentType;
  private Long createdAt;
  private String creatorName;
  private UUID createdBy;


  
  
}
