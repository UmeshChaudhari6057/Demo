package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.maveric.delivery.model.embedded.Option;
import com.maveric.delivery.model.embedded.QuestionType;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class QuestionDto {

    private int number;
    @NotBlank(message = "Question text is required")
    private String questionText;
    private String commentText;
    private QuestionType type;
    private Option radioOption;
    private List<Option> checkBoxOption;
    private Double value;
    @JsonProperty("isNotApplicableUserResponse")
    private boolean isNotApplicableUserResponse;

    public void setCommentText(String commentText){
        if(StringUtils.isBlank(commentText)){
            this.commentText = null;
        }else {
            if(!commentText.matches("^[a-zA-Z0-9,.&()\\- \\n]+$")){
                throw new IllegalArgumentException("User comment can only contain alphabets, numbers, comma, dot, &, (), and hyphen");
            }
            this.commentText = commentText;
        }

    }
}
