package com.maveric.delivery.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.exception.ArtifactNotFoundException;
import com.maveric.delivery.exception.CustomException;
import com.microsoft.graph.models.DriveItem;
import com.microsoft.graph.models.DriveItemCollectionResponse;
import com.microsoft.graph.models.Folder;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import static com.maveric.delivery.utils.Constants.AUTHORIZATION;
import static com.maveric.delivery.utils.Constants.BEARER;

@Component
@RequiredArgsConstructor
@Slf4j
public class SharepointUtils {

    @Value("${maveric.de-dashboard.sharepoint.driverId}")
    private String driverId;

    @Value("${maveric.de-dashboard.clientId}")
    private String clientId;
    @Value("${maveric.de-dashboard.tenantId}")
    private String tenantId;
    @Value("${maveric.de-dashboard.secretValue}")
    private String clientSecret;
    @Value("${scope.graph}")
    private String graphScope;
    @Value("${maveric.de-dashboard.siteUrl}")
    private String siteUrl;

    @Value("${maveric.de-dashboard.tokenUrl}")
    private String tokenUrl;

    @Value("${maveric.de-dashboard.tokenGrantScopeAndType}")
    private String tokenGrantAndScope;

    @Autowired
    private RestTemplate restTemplate;

    private final GraphServiceClient graphServiceClient;


    public InputStream downloadFile(String sharepointId) {

        return graphServiceClient.drives().byDriveId(driverId).items().byDriveItemId(sharepointId).content().get();
    }

    public ResponseEntity<DriveItem> uploadFile(String fileType, String fileName, byte[] multipartFile,String driverItemId ) throws IOException {

        if(multipartFile == null || multipartFile.length==0){
            throw new CustomException("Invalid file.",HttpStatus.BAD_REQUEST);
        }

        String accessToken = BEARER + getAccessToken();
        HttpHeaders headers = new HttpHeaders();
        headers.set(AUTHORIZATION, accessToken);
        headers.set("Accept", "*/*");
        headers.set("Content-Type", fileType);

        ByteArrayResource resource = new ByteArrayResource(multipartFile);
        String url = siteUrl + driverItemId + ":/" + fileName + ":/content";
        log.info("URL: {}", url);
        HttpEntity<ByteArrayResource> requestEntity = new HttpEntity<>(resource, headers);
        ResponseEntity<DriveItem> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, DriveItem.class);
        log.info("response:{}", response);
        return  response;
    }
    public String getAccessToken() throws JsonProcessingException {
        String tokenEndpoint = String.format(tokenUrl, tenantId);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String requestBody = String.format(tokenGrantAndScope, clientId, graphScope, clientSecret);
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.postForEntity(tokenEndpoint, entity, String.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, String> tokenMap = objectMapper.readValue(response.getBody(), Map.class);

            log.info("Token: {}", tokenMap);
            return tokenMap.get("access_token");
        } else {
            return null;
        }
    }

    public DriveItem createFolder(String folderName,String parentDriverId) {
        DriveItem driveItem = new DriveItem();
        driveItem.setName(folderName);
        Folder folder = new Folder();
        driveItem.setFolder(folder);
        HashMap<String, Object> additionalData = new HashMap<String, Object>();
        driveItem.setAdditionalData(additionalData);
        DriveItem result = graphServiceClient.drives().byDriveId(driverId).items().byDriveItemId(parentDriverId).children().post(driveItem);
        log.info("response:{}" , result.getId());
        return result;
    }

    public void deleteFile(String sharepointId) {
        try {
           graphServiceClient.drives().byDriveId(driverId).items().byDriveItemId(sharepointId).delete();
        }catch (Exception e) {
            log.error("Error occurred while deleting attachment: {}", e.getMessage());
            throw new CustomException("Error occurred while deleting attachment", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}

