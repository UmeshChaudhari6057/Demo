package com.maveric.delivery.Entity;



import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AzureUsers {
	@Id  
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private String displayName;
    private String givenName;
    private String mail;
    private String surname;
    private String userPrincipalName;
    private String jobTitle;
    private String dedRole;
    private String userType;
}
