package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.utils.ValidEnumValue;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

/**
 * @author ankushk
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountRequestDto{
    @NotBlank(message = "Account name is required")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()+\\- ]+$", message = "Account name can only contain alphabets, numbers, comma, dot, &, (),+ and hyphen")
    @Size(min = 3, max = 50, message = "Account name must be between 3 and 50 characters")
    private String accountName;

    @NotNull(message = "Account type is required")
    @ValidEnumValue(enumClass = AccountType.class, message = "Invalid account type")
    private AccountType accountType;

    @Size(max = 10, message = "Maximum of 10 tags are allowed")
    private List<String> tags;

    @Size(max = 1,message = "Max 1 selection is allowed")
    @Valid
    @NotEmpty(message = "deliveryHead is required")
    private  List<AccountRoles> deliveryHead;

    @NotEmpty(message = "accountPartners list is required")
    @Valid
    @Size(max = 5,message = "Max 5 selection is allowed")
    private List<AccountRoles> accountPartners;

    @NotEmpty(message = "engagementPartners list is required")
    @Valid
    @Size(max = 5,message = "Max 5 selection is allowed")
    private List<AccountRoles> engagementPartners;

    @NotEmpty(message = "deliveryPartners list is required")
    @Valid
    @Size(max = 5,message = "Max 5 selection is allowed")
    private List<AccountRoles> deliveryPartners;

    @NotNull(message = "Account status is required")
    @ValidEnumValue(enumClass = AccountStatus.class, message = "Invalid account status")
    private AccountStatus status;

    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "External Id can only contain alphabets, numbers, comma, dot, &, () and hyphen")
    @Size(min = 2, max = 50, message = "External Id must be between 2 and 50 characters")
    private String externalId;

    @NotNull(message = "Date On boarded status is required")
    private Long dateOnboarded;

    @Valid
    private ClientInformation clientInfo;

    public void setTags(List<String> tags) {
        if (!(tags == null || tags.isEmpty())) {
            for (String tag : tags) {
                if (tag == null || tag.length() < 3 || tag.length() > 25
                        || !tag.matches("^[a-zA-Z0-9-# ]+$")) {
                    throw new IllegalArgumentException("Invalid tag format");
                }
            }
        }
        this.tags = tags;
    }


}
