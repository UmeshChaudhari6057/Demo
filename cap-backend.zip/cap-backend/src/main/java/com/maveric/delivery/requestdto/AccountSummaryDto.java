package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AccountType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@JsonPropertyOrder({"accountId","accountName", "deliveryHead", "deliveryPartners", "accountPartners", "engagementPartners", "dateOnboarded", "accountType", "activeProjects", "totalProjects", "status"})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountSummaryDto {
    private Long accountId;
    private String accountName;
    private String deliveryHead;
    private String deliveryPartners;
    private String accountPartners;
    private String engagementPartners;
    private Long dateOnboarded;
    private AccountType accountType;
    private Long activeProjects;
    private Long totalProjects;
    private AccountStatus status;

}
