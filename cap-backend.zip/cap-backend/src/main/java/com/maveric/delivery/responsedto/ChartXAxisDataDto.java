package com.maveric.delivery.responsedto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ChartXAxisDataDto {
    private String name;
    private List<Double> data;
    private  List<Long> total;

}
