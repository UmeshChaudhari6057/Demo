package com.maveric.delivery.service;

import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.Entity.ProjectType;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.TemplateStatus;
import com.maveric.delivery.requestdto.AssessmentTemplateEditRequestDto;
import com.maveric.delivery.requestdto.AssessmentTemplateRequestDto;
import com.maveric.delivery.responsedto.AssessmentTemplateResponseDto;
import com.maveric.delivery.responsedto.BaseDto;

import java.util.List;
import java.util.UUID;

public interface AssessmentTemplateService {
    List<BaseDto> getAllTemplates(String type);
    AssessmentTemplate createTemplate(AssessmentTemplateRequestDto assessmentTemplateRequestDto, UUID userID);

    AssessmentTemplate editTemplate(AssessmentTemplateEditRequestDto assessmentTemplateRequestDto, UUID userID, Long templateId);
    List<AssessmentTemplateResponseDto> fetchAllTemplateDetails( UUID userId);

    boolean duplicateTemplateNameCheck(AssessmentCategoryType categoryType,String templateName);
    List<AssessmentTemplateResponseDto> fetchTemplatesDetailsBasedOnStatus(TemplateStatus status,AssessmentCategoryType categoryType,
                                                                           String projectType,UUID userId);
    ProjectType saveProjectType(String projectType, UUID userId);
    AssessmentTemplate fetchTemplate(UUID userId,Long templateId);
}
