package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.Location;
import com.maveric.delivery.mysqlrepository.LocationmysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "Location", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@Service
@AllArgsConstructor
public class LocationMigration implements Migration{
 //   private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/location.json";
    
    private final LocationmysqlRepository locationmysqlRepository;


    
    @Override
    public void before() {
        log.info("Location Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    
    @Override
    public void rollbackBefore() {
        log.info("Location Migration RollbackBeforeExecution");
    }

    @Transactional
    @Override
    public void migrationMethod() throws IOException {
        log.info("Location migrationMethod");
     //   List<Location> locations= jsonFileReader.readJsonFileToList(filePath, Location.class);
       // mongoTemplate.insertAll(locations);
        
        
        try {
            List<Location> location = jsonFileReader.readJsonFileToList(filePath, Location.class);

            if (!location.isEmpty()) {
            	locationmysqlRepository.saveAll(location);
                log.info("Migration completed: {} records inserted", location.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
    }

    
    @Override
    public void rollback() {
        log.info("Location Migration RollbackBeforeExecution");
    }
}
