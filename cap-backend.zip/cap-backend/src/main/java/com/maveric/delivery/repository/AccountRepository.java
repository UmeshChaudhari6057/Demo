package com.maveric.delivery.repository;

import com.maveric.delivery.Entity.Account;
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * @author ankushk
 */

public class AccountRepository{ // extends MongoRepository<Account, Long> {
//
//    List<Account>  findByAccountNameIgnoreCase(String accountName);
//
//
//
//    List<Account> findByDedRoles_Oid(UUID userId);
//    boolean existsByAccountName(String accountName);
//
//    Account findByDedRoles_AccountId(Long accountId);
//
//
//
//    @Query(value = "{'dedRoles.role': ?0}", count = true)
//    long countByRoleIgnoreCase(String role);
//
//    List<Account> findByStatus(String status);
}
