package com.maveric.delivery.utils;

public enum FailedMessage {
    ACCOUNT_CREATION_FAILED("E-1000", "Account creation Failed"),
    FETCH_ACCOUNTS_FAILED("E-1001", "Failed to fetch accounts"),
    FETCH_ACCOUNTS_COUNT_FAILED("E-1002", "Failed to fetch accounts count"),
    FETCH_ACCOUNT_FAILED("E-1003", "Failed to fetch account"),
    UPDATE_ACCOUNT_DETAILS_FAILED("E-1004", "Failed to update account details"),
    EXISTS_ACCOUNT("E-1005", "Account name already exists : "),
    FETCH_COUNTRIES_FAILED("E-1006", "Failed to fetch countries"),
    PROJECTTYPE_CREATED_FAILED ("E-1007","ProjectType creation failed"),
    FETCH_PROJECTTYPE_FAILED("E-1008", "Failed to fetch projectType"),
    EXISTS_PROJECTS("E-1009", "Project name already exists : "),
    DATE_PROJECTS("E-1010", "Date validation failed"),

    FETCH_BASED_TYPES_FAILED("E-1101","Failed to fetch basedTypes"),
    PROJECT_NOT_FOUND("E-1011","The project is not found "),
    PROJECT_STATUS("E-1012","The Status should not be null "),
    FETCHED_PROJECT_STATUS_FAILED("E-1103","Failed to fetch Project Status"),
    FETCHED_ACCOUNT_STATUS_FAILED("E-1105","Failed to fetch Account Status"),
    FETCHED_ASSESSMENT_TEMPLATES_FAILED("E-1104","Failed to fetch assessment templates"),
    LOCATION_CREATION_FAILED("E-1014","Failed to save Location"),
    PROJECTROLE_CREATION_FAILED("E-1015","Failed to save projectRole"),
    ARTIFACTTYPE_CREATION_FAILED("E-1016","Failed to save artifactType"),

    INTERNAL_SERVER_ERROR("E-2000","Internal Server Error "),
    RESOURCE_NOT_FOUND("E-2001","The requested resource is not found."),
    ID_NOT_FOUND("E-2002"," Id Not Found Exception "),
    METHOD_ARGUMENT_NOT_VALID(" E-2003","Method Argument Not Valid Exception "),
    HTTP_MESSAGE_MESSAGE_NOT_READABLE("E-2004","Http Message Not Readable Exception "),
    ILLEGAL_ARGUMENT_EXCEPTION("E-2005","Illegal Argument Exception "),
    VALIDATION_ERROR("E-2006", "Validation error(s) "),
    USER_ROLE_EXCEPTION("E-2007","User role exception "),
    BAD_REQUEST("E-2008", "Bad Request "),
    ACCOUNT_NOT_FOUND("E-2009","The account is not found "),
    TYPE_NOT_FOUND("E-2101","Type not found"),

    USER_NOT_FOUND("E-2102","The user is not available"),

    ACTIVE_PROJECT_FOUND("E-2103","There are active projects associated with the account. The account cant be deleted."),
    ACTIVE_ACCOUNT_FOUND("E-2106","Cannot update userRole, active projects exist"),


    MEMBER_NOT_FOUND("E-2104","The team Member is not found"),

    CUSTOM_EXCEPTION("E-2104","Custom exception"),

    DATA_NOT_FOUND("E-2010","<DATA> not found "),

    PERMISSION_DENIED("E-3000","Permission Denied: You don't have access to this resource"),

    INVALID_TOKEN("E-3001","The provided token is invalid"),

    EXPIRED_TOKEN("E-3002","The token has expired. Please log in again."),

    DUPLICATE_KEY_EXCEPTION("E-3003","Duplicate Data"),
    ROLES_ASSIGN_FAILED("E-4001","Role assign failed"),
    NO_OTHER_USER_MAPPED_WITH_SUPER_ADMIN_EXCEPTION("E-4002","No any other user mapped with super admin."),
    MULTIPLE_SUPER_ADMINS_EXCEPTION("E-4003","No more super admin"),
    FETCH_USER_ROLES_FAILED("E-4004","Failed to fetch User role"),

    UPDATE_USER_ROLES_FAILED("E-4005","User role updated failed"),

    DELETE_USER_ROLES("S-4006","Failed to delete user role"),

    MISSING_SERVLET_REQUEST_PARAMETER_EXCEPTION("E-5000","Missing Request Parameter Exception"),
    METHOD_ARGUMENT_TYPE_MISMATCH_EXCEPTION("E-5001","Method Argument Type Mismatch Exception"),
    HTTP_REQUEST_METHOD_NOT_SUPPORTED_EXCEPTION("E-5002","Http Request Method Not Supported Exception"),
    MISSING_REQUEST_HEADER_EXCEPTION("E-5003","Missing Request Header Exception"),
    VALIDATION_EXCEPTION("E-5004","Validation Error"),
    MAX_UPLOAD_SIZE_EXCEEDED_EXCEPTION("E-5005","Attachment too large!"),
    API_EXCEPTION("E-5006","An error occurred while processing your request. Please try again later."),
    HTTP_CLIENT_ERROR_EXCEPTION("E-5007","An error occurred while processing your request. Please try again later."),
    ;


    private final String code;
    private final String message;

    FailedMessage(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static FailedMessage fromCode(String code) {
        for (FailedMessage errorMessage : FailedMessage.values()) {
            if (errorMessage.code == code) {
                return errorMessage;
            }
        }
        throw new IllegalArgumentException("Invalid error code");
    }

    @Override
    public String toString() {
        return "ErrorMessage{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}

