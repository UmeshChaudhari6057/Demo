package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.ErrorMessage;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Response object returned by API endpoints")
public class ResponseDto <T> implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    @Schema(description = "Indicates if the operation was successful")
    private String status;
    @Schema(description = "Indicates if the operation code")
    private String code;
    @Schema(description = "Message describing the result of the operation")
    private String message;
    @Schema(description = "ErrorMessage describing the result of the list of error message")
    private List<ErrorMessage> errorMessage;
    @Schema(description = "Data returned by the API")
    private T payload = null;


}

