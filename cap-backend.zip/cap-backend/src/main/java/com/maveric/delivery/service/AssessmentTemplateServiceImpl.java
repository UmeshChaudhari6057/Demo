package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.Entity.ProjectType;
import com.maveric.delivery.Entity.Question;
import com.maveric.delivery.exception.AssessmentException;
import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.CheckBoxOptions;
import com.maveric.delivery.model.embedded.Numerical;
import com.maveric.delivery.model.embedded.Option;
import com.maveric.delivery.model.embedded.RadioOptions;
import com.maveric.delivery.model.embedded.Range;
import com.maveric.delivery.model.embedded.Slider;
import com.maveric.delivery.model.embedded.TemplateStatus;
import com.maveric.delivery.mysqlrepository.AssessmentTemplatemysqlRepository;
import com.maveric.delivery.mysqlrepository.ProjectTypemysqlRepository;
import com.maveric.delivery.requestdto.AssessmentTemplateEditRequestDto;
import com.maveric.delivery.requestdto.AssessmentTemplateRequestDto;
import com.maveric.delivery.requestdto.TemplateQuestionDto;
import com.maveric.delivery.responsedto.AssessmentTemplateResponseDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.utils.FailedMessage;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class AssessmentTemplateServiceImpl implements AssessmentTemplateService {
    private final AssessmentTemplatemysqlRepository assessmentTemplateRepository;
    private final UserServiceImpl userService;
    private final ProjectTypemysqlRepository projectTypeRepository;
    @Override
    public List<BaseDto> getAllTemplates(String type) {
        log.info("AssessmentTemplateServiceImpl::getAllTemplates::started");
        List<AssessmentTemplate> templates=assessmentTemplateRepository.findByAssessmentTypeAndStatus(AssessmentCategoryType.DELIVERY_MATURITY,TemplateStatus.Active);
        List<BaseDto> templateList = new ArrayList<>();
        if(!CollectionUtils.isEmpty(templates)) {
            log.info("AssessmentTemplateServiceImpl::getAllTemplates::end");
            for (AssessmentTemplate assessmentTemplate : templates) {
                templateList.add(new BaseDto(assessmentTemplate.getId(), assessmentTemplate.getTemplateName()));
            }
        }
        return templateList;
    }

    public AssessmentTemplate createTemplate(AssessmentTemplateRequestDto assessmentTemplateRequestDto, UUID userID){
        if(userService.getHighestRole(userID,null,null).equalsIgnoreCase(SUPER_ADMIN_)) {
            validateTemplateName(assessmentTemplateRequestDto.getAssessmentType(),assessmentTemplateRequestDto.getTemplateName());
            AssessmentTemplate assessmentTemplate = new AssessmentTemplate();
            BeanUtils.copyProperties(assessmentTemplateRequestDto, assessmentTemplate);
            List<Question> questions= new ArrayList<>();
            Question question;
            for(TemplateQuestionDto questionDto : assessmentTemplateRequestDto.getQuestions()){
                question = new Question();
                BeanUtils.copyProperties(questionDto,question);
                question.setComments(true);
                questions.add(question);
            }
            assessmentTemplate.setQuestions(questions);

            if (assessmentTemplateRequestDto.getAssessmentType().equals(AssessmentCategoryType.PROJECT_MATURITY)) {
                List<AssessmentTemplate> activeStatusTemplate = assessmentTemplateRepository.findByAssessmentTypeAndStatus(
                        AssessmentCategoryType.PROJECT_MATURITY, TemplateStatus.Active);
                log.info("Template validation started");
                assessmentTemplate.setCreatedOn(getCurrentDateValue());
                validateAndSaveTemplate(activeStatusTemplate, assessmentTemplate);
                log.info("Template validation completed");
            } else if (assessmentTemplateRequestDto.getAssessmentType().equals(AssessmentCategoryType.EXECUTION_MATURITY)) {
                if (StringUtils.isBlank(assessmentTemplateRequestDto.getProjectType())) {
                    throw new AssessmentException("Project type should not be blank");
                }
                List<AssessmentTemplate> optionalAssessmentTemplates = assessmentTemplateRepository.findByAssessmentTypeAndStatusAndProjectType(
                        AssessmentCategoryType.EXECUTION_MATURITY, TemplateStatus.Active, assessmentTemplateRequestDto.getProjectType());
                log.info("Template validation started");
                assessmentTemplate.setCreatedOn(getCurrentDateValue());
                validateAndSaveTemplate(optionalAssessmentTemplates, assessmentTemplate);
                log.info("Template validation completed");
            } else {
                log.info("Template validation started");
                validateQuestionList(assessmentTemplate.getQuestions());
                log.info("Template validation completed");
                long currentDateValue = getCurrentDateValue();
                assessmentTemplate.setCreatedOn(currentDateValue);
                assessmentTemplateRepository.save(assessmentTemplate);
            }
            return assessmentTemplate;
        }else {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    public AssessmentTemplate editTemplate(AssessmentTemplateEditRequestDto assessmentTemplateRequestDto, UUID userID, Long templateId){
        if(userService.getHighestRole(userID,null,null).equalsIgnoreCase(SUPER_ADMIN_)) {
            log.info("Template edit started");
            Optional<AssessmentTemplate> assessmentTemplateOptional = assessmentTemplateRepository.findById(templateId);
            if(assessmentTemplateOptional.isEmpty()){
                throw new AssessmentException("Template id is not found");
            }
            AssessmentTemplate assessmentTemplate = assessmentTemplateOptional.get();
            if(!assessmentTemplate.getTemplateName().equals(assessmentTemplateRequestDto.getTemplateName())){
                validateTemplateName(assessmentTemplate.getAssessmentType(),assessmentTemplateRequestDto.getTemplateName());
            }
            TemplateStatus previousStatus = assessmentTemplate.getStatus();
            BeanUtils.copyProperties(assessmentTemplateRequestDto, assessmentTemplate);
            List<Question> questions= new ArrayList<>();
            Question question;
            for(TemplateQuestionDto questionDto : assessmentTemplateRequestDto.getQuestions()){
                question = new Question();
                BeanUtils.copyProperties(questionDto,question);
                question.setComments(true);
                questions.add(question);
            }
            assessmentTemplate.setQuestions(questions);

            if (assessmentTemplate.getAssessmentType().equals(AssessmentCategoryType.PROJECT_MATURITY)) {
                log.info("Template validation started");
                validateTemplateStatus(previousStatus, assessmentTemplate);
                List<AssessmentTemplate> activeStatusTemplate = assessmentTemplateRepository.findByAssessmentTypeAndStatus(
                        AssessmentCategoryType.PROJECT_MATURITY, TemplateStatus.Active);
                assessmentTemplate.setEditedOn(getCurrentDateValue());
                validateAndSaveTemplate(activeStatusTemplate, assessmentTemplate);
                log.info("Template validation completed");
            } else if (assessmentTemplate.getAssessmentType().equals(AssessmentCategoryType.EXECUTION_MATURITY)) {
                log.info("Template validation started");
                validateTemplateStatus(previousStatus, assessmentTemplate);
                List<AssessmentTemplate> optionalAssessmentTemplates = assessmentTemplateRepository.findByAssessmentTypeAndStatusAndProjectType(
                        AssessmentCategoryType.EXECUTION_MATURITY, TemplateStatus.Active, assessmentTemplate.getProjectType());
                assessmentTemplate.setEditedOn(getCurrentDateValue());
                validateAndSaveTemplate(optionalAssessmentTemplates, assessmentTemplate);
                log.info("Template validation completed");
            } else {
                log.info("Template validation started");
                validateQuestionList(assessmentTemplate.getQuestions());
                log.info("Template validation completed");
                assessmentTemplate.setEditedOn(getCurrentDateValue());
                assessmentTemplateRepository.save(assessmentTemplate);
            }
            return assessmentTemplate;
        }else {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    private void validateTemplateStatus(TemplateStatus previousStatus, AssessmentTemplate assessmentTemplate) {
        if(previousStatus.equals(TemplateStatus.Active) &&
                assessmentTemplate.getStatus().equals(TemplateStatus.Inactive)){
            throw new AssessmentException("Permission denied. This is the only active template available for this assessment type, so it cannot be set to INACTIVE status.");
        }
    }

    private void validateTemplateName(AssessmentCategoryType assessmentCategoryType, String templateName) {
        Optional<AssessmentTemplate> templateOptional = assessmentTemplateRepository.findByAssessmentTypeAndTemplateName(assessmentCategoryType,
                templateName);
        if (templateOptional.isPresent()) {
            throw new AssessmentException("Template name is already exist");
        }
    }

    @Override
    public List<AssessmentTemplateResponseDto> fetchAllTemplateDetails(UUID userId) {
        if(userService.getHighestRole(userId,null,null).equalsIgnoreCase(SUPER_ADMIN_)){
            List<AssessmentTemplate> assessmentTemplateList = assessmentTemplateRepository.findAll();
            return getAssessmentTemplateResponseDtos(assessmentTemplateList);
        }else {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }

    }

    public AssessmentTemplate fetchTemplate(UUID userId,Long templateId){
        if(userService.getHighestRole(userId,null,null).equalsIgnoreCase(SUPER_ADMIN_)) {
            return assessmentTemplateRepository.findById(templateId).orElse(null);
        }else {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    private List<AssessmentTemplateResponseDto> getAssessmentTemplateResponseDtos(List<AssessmentTemplate> assessmentTemplateList) {
        List<AssessmentTemplateResponseDto> templateResponseDtoList = new ArrayList<>();
        AssessmentTemplateResponseDto templateResponseDto ;
        for (AssessmentTemplate assessmentTemplate : assessmentTemplateList){
            templateResponseDto = new AssessmentTemplateResponseDto();
            BeanUtils.copyProperties(assessmentTemplate,templateResponseDto);
            templateResponseDto.setTemplateId(assessmentTemplate.getId());
            templateResponseDto.setAssessmentType(assessmentTemplate.getAssessmentType().getDescription());
            int utilizedProjects = assessmentTemplate.getUtilizedProjects() == null ? 0 : assessmentTemplate.getUtilizedProjects().size();
            templateResponseDto.setUtilizedProjects(utilizedProjects);
            templateResponseDtoList.add(templateResponseDto);
        }
        return templateResponseDtoList;
    }

    @Override
    public boolean duplicateTemplateNameCheck(AssessmentCategoryType categoryType, String templateName) {
        Optional<AssessmentTemplate> templateOptional = assessmentTemplateRepository.findByAssessmentTypeAndTemplateName(categoryType,templateName);
        return templateOptional.isPresent();
    }

    @Override
    public List<AssessmentTemplateResponseDto> fetchTemplatesDetailsBasedOnStatus(TemplateStatus status, AssessmentCategoryType categoryType, String projectType, UUID userId) {
        if(userService.getHighestRole(userId,null,null).equalsIgnoreCase(SUPER_ADMIN_)){
            List<AssessmentTemplate> assessmentTemplateList = assessmentTemplateRepository.findByAssessmentTypeAndStatusAndProjectType(categoryType,status,projectType);
            return getAssessmentTemplateResponseDtos(assessmentTemplateList);
        }else {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    private void validateAndSaveTemplate(List<AssessmentTemplate> activeStatusTemplate, AssessmentTemplate assessmentTemplate) {

        if(activeStatusTemplate.isEmpty() || assessmentTemplate.getStatus().equals(TemplateStatus.Inactive)){
            validateQuestionList(assessmentTemplate.getQuestions());
            assessmentTemplateRepository.save(assessmentTemplate);
        }else {
            Long currentTemplateId = assessmentTemplate.getId();
            if(activeStatusTemplate.size() >1){
                throw new AssessmentException("More than one active templates found");
            }
            validateQuestionList(assessmentTemplate.getQuestions());
            long currentDateValue = getCurrentDateValue();
            assessmentTemplateRepository.save(assessmentTemplate);
            assessmentTemplate = activeStatusTemplate.get(0);
            if (!Objects.equals(currentTemplateId, assessmentTemplate.getId())) {
                assessmentTemplate.setStatus(TemplateStatus.Inactive);
                assessmentTemplate.setEditedOn(currentDateValue);
                assessmentTemplateRepository.save(assessmentTemplate);
            }
        }
    }



    private long getCurrentDateValue() {
        return ZonedDateTime.now(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli();
    }

    private void validateQuestionList(List<Question> questionList){
        for (Question question : questionList){
            switch (question.getType()){
                case CHECK_BOX -> {
                    CheckBoxOptions checkBoxOptions =question.getCheckBoxOptions();
                    List<Option> options = checkBoxOptions.getOptions();
                    validateOptions(options);
                    for (Option option : options){
                        if(option.getIndex() == null || StringUtils.isBlank(option.getValue())||(!option.getValue().matches("^[a-zA-Z0-9,.&()\\- /?%\":#'+*=]+$"))
                                || option.isSelected() || option.getScore() == null ||option.getScore() <0){
                            throw  new AssessmentException("Provided option details are incorrect for checkbox : question"+question.getNumber());
                        }
                    }
                }
                case RADIO_BUTTON -> {
                    RadioOptions radioOptions =question.getRadioOptions();
                    List<Option> options = radioOptions.getOptions();
                    validateOptions(options);
                    for (Option option : options){
                        if(option.getIndex() == null || StringUtils.isBlank(option.getValue()) ||(!option.getValue().matches("^[a-zA-Z0-9,.&()\\- /?%\":#'+*=]+$"))||
                                option.isSelected() || option.getScore() == null ||option.getScore() <0 ){
                            throw  new AssessmentException("Provided option details are incorrect for radio button : question "+question.getNumber());
                        }
                    }
                }
                case NUMERICAL -> {
                    Numerical numerical = question.getNumerical();
                    List<Range> ranges = getNumericalRanges(question,numerical);
                    checkOverlapsAndGaps(ranges, numerical.getMin(), numerical.getMax());
                }
                case SLIDER -> {
                    Slider slider = question.getSlider();
                    List<Range> ranges = getSliderRanges(question,slider);
                    checkOverlapsAndGaps(ranges, slider.getMin(), slider.getMax());
                }
            }
        }
    }

    private void validateOptions(List<Option> options){
        if(options.size() > 5){
            throw  new AssessmentException("Options should not greater than 5");
        }

    }
    private List<Range> getNumericalRanges(Question question,Numerical numerical) {
        List<Range> ranges = numerical != null ? numerical.getRange() : null;
        if( numerical == null || numerical.getMin()<0 ||numerical.getMax()>99999 ||
                numerical.getMin() >= numerical.getMax() || ranges.size() >5){
            throw  new AssessmentException("Provided option details are incorrect for numerical field : "+ question.getNumber());
        }
        return ranges;
    }

    private List<Range> getSliderRanges(Question question,Slider slider) {
        List<Range> ranges = slider != null ? slider.getRange() : null;
        if( slider == null || slider.getMin()<0||slider.getMax()>99999||slider.getMin() >= slider.getMax() ||
                ranges.size() >5 || ((slider.getMax()-slider.getMin())%slider.getIncrement() != 0)){
            throw  new AssessmentException("Provided option details are incorrect for slider field : "+ question.getNumber());
        }
        return ranges;
    }

    private void checkOverlapsAndGaps(List<Range> ranges,int min,int max) {
        Collections.sort(ranges, Comparator.comparingInt(Range::getStart));

        if (ranges.get(0).getStart() < min) {
            throw  new AssessmentException("Range start should be greater than or equal to "+min);
        }
        // Variable to track the end of the last range
        int lastEnd = ranges.get(0).getEnd();
        if(ranges.get(0).getScore() == null){
            throw new AssessmentException("Score cannot be null");
        }

        for (int i = 1; i < ranges.size(); i++) {
            Range current = getRange(ranges, i, lastEnd);
            // Update the lastEnd to the end of the current range if it is larger
            lastEnd = current.getEnd();
        }
        if(lastEnd> max){
            throw  new AssessmentException("Range end should be lesser than or equal to "+max);
        }
    }

    private Range getRange(List<Range> ranges, int i, int lastEnd) {
        Range current = ranges.get(i);
        // Check for overlap
        if (current.getStart() <= lastEnd) {
            throw  new AssessmentException("Overlap found: " + ranges.get(i - 1) + " and " + current);
        }
        // Check for gaps
        if (current.getStart() != lastEnd + 1) {
            throw  new AssessmentException("Gap found between: " + lastEnd + " and " + (current.getStart()));
        }
        if(current.getScore() == null){
            throw new AssessmentException("Score cannot be null");
        }
        return current;
    }

    public ProjectType saveProjectType(String projectType,UUID userId){
        if(userService.getHighestRole(userId,null,null).equalsIgnoreCase(SUPER_ADMIN_)) {
            Optional<ProjectType> projectTypeOptional = projectTypeRepository.findByNameIgnoreCase(projectType);
            if(projectTypeOptional.isPresent()){
                throw new AssessmentException("Project type is already exist");
            }
            ProjectType type= new ProjectType();
            type.setName(projectType);
            return projectTypeRepository.save(type);
        }else {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }
}
