package com.maveric.delivery.responsedto;

import com.maveric.delivery.requestdto.AccountRoles;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilterRolesResponseDto {
    private Set<AccountRoles> deliveryManager;
    private Set<AccountRoles> deliveryPartner;
    private Set<AccountRoles> accountPartner;
    private Set<AccountRoles> engagementPartner;
}
