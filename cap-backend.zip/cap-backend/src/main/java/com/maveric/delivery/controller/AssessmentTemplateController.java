package com.maveric.delivery.controller;

import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.AssessmentTemplate;
import com.maveric.delivery.Entity.ProjectType;
import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.TemplateStatus;
import com.maveric.delivery.requestdto.AssessmentTemplateEditRequestDto;
import com.maveric.delivery.requestdto.AssessmentTemplateRequestDto;
import com.maveric.delivery.responsedto.AssessmentTemplateResponseDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AssessmentTemplateService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.websocket.server.PathParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Assessment Template Management", description = "Endpoints for managing Assessment Templates")
public class AssessmentTemplateController {

    private final AssessmentTemplateService assessmentTemplateService;
    @Operation(summary = "Fetch All Assessment Templates",description = "Api to Get All assessment Template")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Template fetched successfully"),
            @ApiResponse(responseCode = "404", description = "Templates Present not Available"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "assessments/templates")
    public ResponseEntity<ResponseDto<List<BaseDto>>> fetchAllTemplates(@PathParam("type") String type) {
        log.info("AssessmentTemplateController::FetchAllTemplates() started");
        List<BaseDto> assessmentTemplates=assessmentTemplateService.getAllTemplates(type);
        if (CollectionUtils.isEmpty(assessmentTemplates)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>(FAILED, FailedMessage.FETCHED_ASSESSMENT_TEMPLATES_FAILED.getCode(), FailedMessage.FETCHED_ASSESSMENT_TEMPLATES_FAILED.getMessage(),null, assessmentTemplates));
        }
        log.info("BasedController::FetchAllType() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getCode(), SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getMessage(),null, assessmentTemplates));
    }

    @Operation(summary = "Save Template",description = "Api to Save Template")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Template saved successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "templates")
    public ResponseEntity<ResponseDto<AssessmentTemplate>> createTemplate(HttpServletRequest servletRequest,@RequestBody @Valid AssessmentTemplateRequestDto assessmentTemplateRequestDto){
        log.info("AssessmentTemplateController::createTemplate() started");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentTemplate assessmentTemplate = assessmentTemplateService.createTemplate(assessmentTemplateRequestDto,userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SuccessMessage.CREATE_TEMPLATE.getCode(), SuccessMessage.CREATE_TEMPLATE.getMessage(),null, null));
    }

    @Operation(summary = "Edit Template",description = "Api to edit Template")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Template saved successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(path = "templates/{templateId}")
    public ResponseEntity<ResponseDto<AssessmentTemplate>> editTemplate(HttpServletRequest servletRequest, @RequestBody @Valid
    AssessmentTemplateEditRequestDto assessmentTemplateRequestDto, @PathVariable Long templateId){
        log.info("AssessmentTemplateController::editTemplate() started");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentTemplate assessmentTemplate = assessmentTemplateService.editTemplate(assessmentTemplateRequestDto,userId,templateId);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SuccessMessage.EDIT_TEMPLATE.getCode(), SuccessMessage.EDIT_TEMPLATE.getMessage(),null, null));
    }

    @Operation(summary = "Save Project Type",description = "Api to Save Project Type")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Project type saved successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "templates/projectType/{projectType}")
    public ResponseEntity<ResponseDto<ProjectType>> saveProjectType(HttpServletRequest servletRequest, @PathVariable String projectType){
        log.info("AssessmentTemplateController::saveProjectType() started");
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        ProjectType type = assessmentTemplateService.saveProjectType(projectType,userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SuccessMessage.SAVE_PROJECT_TYPE.getCode(), SuccessMessage.SAVE_PROJECT_TYPE.getMessage(),null, type));
    }

    @Operation(summary = "Fetch All Assessment Template Details",description = "Api to Get All Assessment Template Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Templates fetched successfully"),
            @ApiResponse(responseCode = "404", description = "Templates Present not Available"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "templates")
    public ResponseEntity<ResponseDto<List<AssessmentTemplateResponseDto>>> fetchAllTemplatesDetails(HttpServletRequest servletRequest){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        List<AssessmentTemplateResponseDto> assessmentTemplateList = assessmentTemplateService.fetchAllTemplateDetails(userId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getCode(), SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getMessage(), null, assessmentTemplateList));
    }

    @Operation(summary = "Fetch Template Details",description = "Api to Get Template Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Template fetched successfully"),
            @ApiResponse(responseCode = "404", description = "Template Present not Available"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "templates/id/{templateId}")
    public ResponseEntity<ResponseDto<AssessmentTemplate>> fetchTemplateDetails(HttpServletRequest servletRequest,@PathVariable Long templateId){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        AssessmentTemplate template = assessmentTemplateService.fetchTemplate(userId,templateId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.FETCHED_ASSESSMENT_TEMPLATE.getCode(), SuccessMessage.FETCHED_ASSESSMENT_TEMPLATE.getMessage(), null, template));
    }

    @Operation(summary = "Duplicate Template Name",description = "Api to Get Duplicate Template Name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Check if template name is duplicate"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "templates/duplicate/{templateName}")
    public ResponseEntity<ResponseDto> validateDuplicateTemplateName(@PathVariable String templateName, @RequestParam AssessmentCategoryType categoryType){
        boolean isDuplicate =assessmentTemplateService.duplicateTemplateNameCheck(categoryType,templateName);
        if (isDuplicate) {
            log.warn("Duplicate template name found");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS, SuccessMessage.DUPLICATE_TEMPLATE_NAME.getCode(), SuccessMessage.DUPLICATE_TEMPLATE_NAME.getMessage().concat(templateName), null, false));
        } else {
            log.info("Template name is not a duplicate");
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto(SUCCESS, SuccessMessage.TEMPLATE_NAME_AVAILABLE.getCode(), SuccessMessage.TEMPLATE_NAME_AVAILABLE.getMessage().concat(templateName), null, true));
        }
    }

    @Operation(summary = "Fetch All Assessment Template Details Based on Status",description = "Api to Get All Assessment Template Details Based on Status")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Templates fetched successfully"),
            @ApiResponse(responseCode = "404", description = "Templates Present not Available"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "templates/{status}")
    public ResponseEntity<ResponseDto<List<AssessmentTemplateResponseDto>>> fetchTemplatesDetailsBasedOnStatus(HttpServletRequest servletRequest, @PathVariable TemplateStatus status
    ,@RequestParam AssessmentCategoryType assessmentType,@RequestParam(defaultValue = "") String projectType){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute(O_ID));
        projectType = projectType.isBlank() ? null:projectType;
        List<AssessmentTemplateResponseDto> assessmentTemplateList = assessmentTemplateService.fetchTemplatesDetailsBasedOnStatus(status,assessmentType,projectType,userId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getCode(), SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getMessage(), null, assessmentTemplateList));
    }
}
