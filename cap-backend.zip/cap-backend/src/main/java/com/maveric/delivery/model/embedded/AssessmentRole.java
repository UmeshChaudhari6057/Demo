package com.maveric.delivery.model.embedded;

public enum AssessmentRole {

    ASSIGNED,
    ALL,
    REVIEWER;

}
