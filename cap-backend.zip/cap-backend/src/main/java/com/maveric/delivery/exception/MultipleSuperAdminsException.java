package com.maveric.delivery.exception;

public class MultipleSuperAdminsException extends RuntimeException {
    public MultipleSuperAdminsException(String message) {
        super(message);
    }
}
