package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AccountType;
import com.maveric.delivery.model.embedded.ClientInformation;
import com.maveric.delivery.requestdto.AccountRoles;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountResponseDto {
    private Long accountId;
    private String accountName;
    private AccountType accountType;
    private List<String> tags;
    private AccountRoles deliveryHead;
    private List<AccountRoles> accountPartners;
    private List<AccountRoles> engagementPartners;
    private List<AccountRoles> deliveryPartners;
    private Long dateOnboarded;
    private AccountStatus status;
    private String externalId;
    private ClientInformation clientInfo;
    private List<String> privileges;
}
