package com.maveric.delivery.mysqlrepository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maveric.delivery.Entity.AzureUsers;

@Repository
public interface AzureUsermysqlRepository extends JpaRepository<AzureUsers, UUID> {
}


