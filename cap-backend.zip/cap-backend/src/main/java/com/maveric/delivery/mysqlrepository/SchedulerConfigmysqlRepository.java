package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.SchedulerConfig;

public interface SchedulerConfigmysqlRepository extends JpaRepository<SchedulerConfig,Long> {
    SchedulerConfig findByKey(String key);
}
