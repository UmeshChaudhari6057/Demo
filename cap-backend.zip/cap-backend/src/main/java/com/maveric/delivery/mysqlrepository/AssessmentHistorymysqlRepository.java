package com.maveric.delivery.mysqlrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.delivery.Entity.AssessmentHistory;

public interface AssessmentHistorymysqlRepository extends JpaRepository<AssessmentHistory, Long> {

    List<AssessmentHistory> findByAssessmentId(Long assessmentId);
    
}
