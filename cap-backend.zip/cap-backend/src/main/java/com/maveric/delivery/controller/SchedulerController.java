package com.maveric.delivery.controller;

import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.scheduler.Scheduler;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Scheduler", description = "Endpoints for managing Scheduler APIs")
public class SchedulerController {

    private final Scheduler scheduler;
    private final ValidateApiAccess validateApiAccess;


    @Operation(summary = "Refresh User",description = "Api to Update the user details form Azure")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "success"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping("/refresh/users")
    public ResponseEntity<ResponseDto<String>> refreshUsers(HttpServletRequest servletRequest) {
        String uuid= (String) servletRequest.getAttribute(O_ID);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString(uuid)).build();
        validateApiAccess.isAccessible(rolesDto,SCHEDULER_JOB, REFRESH_USERS_JOB);
        scheduler.refreshUsers(uuid,API);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.REFRESH_USERS_JOB_SUCCESSFUL.getCode(), SuccessMessage.REFRESH_USERS_JOB_SUCCESSFUL.getMessage(), null, null));
    }

    @Operation(summary = "This API is intended to create assessments.",description = "This API is intended to trigger create assessments.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles retrieve successfully",
                    content = @Content(schema = @Schema(implementation = ResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/create/assessments")
    public ResponseEntity<ResponseDto<String>> createAssessment(HttpServletRequest servletRequest) {
        String uuid= (String) servletRequest.getAttribute(O_ID);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString(uuid)).build();
        validateApiAccess.isAccessible(rolesDto, SCHEDULER_JOB,CREATE_ASSESSMENTS_JOB);
        scheduler.createAssessment(uuid,API);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.CREATE_ASSESSMENTS_JOB_SUCCESSFUL.getCode(), SuccessMessage.CREATE_ASSESSMENTS_JOB_SUCCESSFUL.getMessage(), null, null));
    }

    @Operation(summary = "This API is intended to trigger reminder Mails.",description = "This API is intended to trigger reminder Mails.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles retrieve successfully",
                    content = @Content(schema = @Schema(implementation = ResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/remMails")
    public ResponseEntity<ResponseDto<String>> sendRemainderMails(HttpServletRequest servletRequest) {
        String uuid= (String) servletRequest.getAttribute(O_ID);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString(uuid)).build();
        validateApiAccess.isAccessible(rolesDto, SCHEDULER_JOB,REMAINDER_MAILS_JOB);
        scheduler.sendRemainderMails(uuid,API);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.SEND_REMAINDER_MAILS_SUCCESSFUL.getCode(), SuccessMessage.SEND_REMAINDER_MAILS_SUCCESSFUL.getMessage(), null, null));
    }

    @Operation(summary = "This API is intended to trigger failed projects assessments.",description = "This API is intended to trigger failed projects assessments.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles retrieve successfully",
                    content = @Content(schema = @Schema(implementation = ResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/failedProjects")
    public ResponseEntity<ResponseDto<String>> processFailedProjects(HttpServletRequest servletRequest) {
        String uuid= (String) servletRequest.getAttribute(O_ID);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString(uuid)).build();
        validateApiAccess.isAccessible(rolesDto, SCHEDULER_JOB,FAILED_ASSESSMENTS_JOB);
        scheduler.processFailedProjects(uuid,API);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.FAILED_PROJECTS_JOB_SUCCESSFUL.getCode(), SuccessMessage.FAILED_PROJECTS_JOB_SUCCESSFUL.getMessage(), null, null));
    }

    @Operation(summary = "This API is intended to trigger update projects status",description = "This API is intended to trigger update projects status.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Roles retrieve successfully",
                    content = @Content(schema = @Schema(implementation = ResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/update/projectStatus")
    public ResponseEntity<ResponseDto<String>> updateProjectStatus(HttpServletRequest servletRequest) {
        String uuid= (String) servletRequest.getAttribute(O_ID);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString(uuid)).build();
        validateApiAccess.isAccessible(rolesDto, SCHEDULER_JOB,PROJECT_END_DATE_CHECK_JOB);
        scheduler.changeProjectEndDate(uuid,API);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.UPDATE_PROJECT_STATUS_SUCCESSFUL.getCode(), SuccessMessage.UPDATE_PROJECT_STATUS_SUCCESSFUL.getMessage(), null, null));
    }

}
