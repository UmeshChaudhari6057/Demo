package com.maveric.delivery.service;

import static com.maveric.delivery.utils.Constants.ACCOUNT_ADMIN_;
import static com.maveric.delivery.utils.Constants.ALLOCATION;
import static com.maveric.delivery.utils.Constants.CREATED_AT;
import static com.maveric.delivery.utils.Constants.DH;
import static com.maveric.delivery.utils.Constants.IS_BILLABLE;
import static com.maveric.delivery.utils.Constants.LOCATION_;
import static com.maveric.delivery.utils.Constants.PROJECT_ID;
import static com.maveric.delivery.utils.Constants.PROJECT_ROLE_;
import static com.maveric.delivery.utils.Constants.SKILL_SET;
import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBER;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_ADD;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_EDIT;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_VIEW_ALL;
import static com.maveric.delivery.utils.Constants.TEAM_MEMBERS_VIEW_ASSOCIATED;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Sort;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.DuplicateUserIdException;
import com.maveric.delivery.exception.ProjectDateException;
import com.maveric.delivery.exception.ProjectNotFoundException;
import com.maveric.delivery.exception.TeamMemberNotFoundException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.Entity.Account;
import com.maveric.delivery.Entity.Location;
import com.maveric.delivery.Entity.Project;
import com.maveric.delivery.Entity.TeamMember;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.model.embedded.TeamMemberStatus;
import com.maveric.delivery.mysqlrepository.LocationmysqlRepository;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.mysqlrepository.TeamMembermysqlRepository;
import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.requestdto.TeamMemberFilterDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;
import com.maveric.delivery.utils.UtilMethods;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class TeamMemberServiceImpl implements TeamMemberService {
    private final UtilMethods utilMethods;
    private final TeamMembermysqlRepository teamMemberRepository;
  //  private final ProjectRepository projectRepository;
    private final UserServiceImpl userServiceImpl;
    private final DedRolesRepository dedRolesRepository;
    private final LocationmysqlRepository locationRepository;
  //  private final MongoTemplate mongoTemplate;
  //  private final AccountRepository accountRepository;

    @Override
    public TeamMemberResponseDto saveTeamMember(TeamMemberDto teamMemberDto, UUID userId, Long projectId) {
    	// Commented out MongoDB code
//        log.info("TeamMemberServiceImpl:: saveTeamMember:: started");
//        checkUserAuthenticity(userId);
//
//        if (Objects.isNull(teamMemberDto.getUserId()))
//            throw new UserNotFoundException("Team Member Id is required");
//
//        checkUserAuthenticity(teamMemberDto.getUserId());
//        Optional<Project> project = projectRepository.findById(projectId);
//        if (project.isEmpty()) {
//            log.error("TeamMemberServiceImpl:: saveTeamMember:: Project id not found");
//            throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
//        }
//        if (checkAccess(userId, project.get().getAccountId(), projectId)) {
//            if (teamMemberRepository.existsByUserIdAndProjectId(teamMemberDto.getUserId(), projectId)) {
//                log.error("TeamMemberServiceImpl:: saveTeamMember:: Duplicate User");
//                throw new DuplicateUserIdException("Team Member with Id" + userId + "already Exist");
//            }
//            if (StringUtils.isNotBlank(teamMemberDto.getLocation()) && !locationRepository.existsByNameIgnoreCase(teamMemberDto.getLocation())) {
//                Location location = new Location();
//                location.setName(teamMemberDto.getLocation());
//                locationRepository.save(location);
//            }
//
//            startAndEndDateValidator(teamMemberDto.getStartDate(), project.get().getStartDate(), teamMemberDto.getEndDate(), project.get().getEndDate());
//
//            TeamMember teamMember = new TeamMember();
//            BeanUtils.copyProperties(teamMemberDto, teamMember);
//            teamMember.setProjectId(projectId);
//            teamMember.setUserId(teamMemberDto.getUserId());
//            teamMember.setStatus(TeamMemberStatus.Active);
//            teamMember.setCreatedBy(utilMethods.getDisplayName(userId));
//            teamMember.setCreatedAt(System.currentTimeMillis());
//            teamMember.setUpdatedBy(utilMethods.getDisplayName(userId));
//            teamMember.setUpdatedAt(System.currentTimeMillis());
//
//            TeamMemberResponseDto responseDto = new TeamMemberResponseDto();
//            TeamMember response = teamMemberRepository.save(teamMember);
//            BeanUtils.copyProperties(response, responseDto);
//            userServiceImpl.saveRole(response);
//            log.info("TeamMemberServiceImpl:: saveTeamMember:: ended");
//            return responseDto;
//        }else{
//            throw new CustomException("User is not authorised to add team member", HttpStatus.UNAUTHORIZED);
//        }
    	return new TeamMemberResponseDto();
    }

    private Boolean checkAccess(UUID oid, Long accountId, Long projectId) {
        String role = userServiceImpl.getHighestRole(oid, null, projectId);
        List<String> privileges = utilMethods.getPrivilegesString(role, List.of(TEAM_MEMBERS));
        return role.equalsIgnoreCase(SUPER_ADMIN_)
                || (dedRolesRepository.existsByOidAndAccount_IdAndRole(oid, accountId, DH)
                && utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(TEAM_MEMBERS)).contains(TEAM_MEMBERS_ADD))
                || privileges.contains(TEAM_MEMBERS_ADD);
    }


    //comment code due to Mongo Template
    @Override
    public List<TeamMemberResponseListDto> getAllTeamMembers(UUID userId, Long projectId, TeamMemberFilterDto filter) {
    	// Commented out MongoDB code
//        log.info("TeamMemberServiceImpl:: getAllTeamMembers:: started");
//        Criteria criteria = new Criteria();
//        List<Criteria> criteriaList = new ArrayList<>();
//        List<TeamMemberResponseListDto> responseDto = new ArrayList<>();
//        Optional<Project> project = projectRepository.findById(projectId);
//        if (project.isEmpty()) {
//            log.error("TeamMemberServiceImpl:: getAllTeamMembers:: Project id not found");
//            throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
//        }
//        String highestRole = userServiceImpl.getHighestRole(userId, null, null);
//        List<String> privileges = utilMethods.getPrivilegesString(highestRole, List.of(TEAM_MEMBERS));
//        if (highestRole.equalsIgnoreCase(SUPER_ADMIN_) || privileges.contains(TEAM_MEMBERS_VIEW_ALL)) {
//            criteria.and(PROJECT_ID).is(projectId);
//        } else {
//            String highestRoleProjectLevel = userServiceImpl.getHighestRole(userId, project.get().getAccountId(), projectId);
//            if (!highestRoleProjectLevel.isBlank()) {
//                List<String> privilegesProjectLevel = utilMethods.getPrivilegesString(highestRoleProjectLevel, List.of(TEAM_MEMBERS));
//                if (privilegesProjectLevel.contains(TEAM_MEMBERS_VIEW_ASSOCIATED)) {
//                    List<DedRolesmy> dedRoles = dedRolesRepository.findByOidAndProject_Id(userId, projectId);
//                    if (!dedRoles.isEmpty()) {
//                        criteria.and(PROJECT_ID).is(projectId);
//                    } else {
//                        return responseDto;
//                    }
//                }
//            } else {
//                return responseDto;
//            }
//        }
//        log.info("TeamMemberServiceImpl::getAllFilteredTeamMembers:: call started");
//
//        if (!CollectionUtils.isEmpty(filter.getProjectRole())) {
//            criteriaList.add(Criteria.where(PROJECT_ROLE_).in(filter.getProjectRole()));
//        }
//        if (StringUtils.isNotBlank(filter.getLocation())) {
//            criteriaList.add(Criteria.where(LOCATION_).is(filter.getLocation()));
//        }
//        if (!CollectionUtils.isEmpty(filter.getSkillSet())) {
//            criteriaList.add(Criteria.where(SKILL_SET).in(filter.getSkillSet()));
//        }
//        if (filter.getIsBillable() != null) {
//            criteriaList.add(Criteria.where(IS_BILLABLE).is(filter.getIsBillable()));
//        }
//        if (filter.getAllocationFrom() != null && filter.getAllocationTo() != null) {
//            criteriaList.add(Criteria.where(ALLOCATION).gte(filter.getAllocationFrom()).lte(filter.getAllocationTo()));
//        }
//        if (!CollectionUtils.isEmpty(criteriaList)) {
//            criteria.orOperator(criteriaList);
//        }
//        Query query = new Query(criteria);
//        if (StringUtils.isNotBlank(filter.getSortBy())) {
//            utilMethods.isValidField(TeamMember.class, filter.getSortBy());
//            query.with(Sort.by(Sort.Direction.DESC, filter.getSortBy()));
//        }else {
//            query.with(Sort.by(Sort.Direction.DESC, CREATED_AT));
//        }
//
//        List<TeamMember> teamMembers = mongoTemplate.find(query, TeamMember.class);
//
//        if (teamMembers.isEmpty()) {
//            return responseDto;
//        }
//        responseDto = toTeamMemberDtoList(teamMembers);
//        log.info("TeamMemberServiceImpl:: getAllFilteredTeamMembers:: ended");
//        return responseDto;
    	
    	return new ArrayList<TeamMemberResponseListDto>();
    }

    @Override
    public TeamMemberResponseListDto getTeamMemberById(Long teamMemberId) {
    	//// Commented out MongoDB code
//        log.info("TeamMemberServiceImpl:: getTeamMemberById:: started");
//        Optional<TeamMember> teamMember = teamMemberRepository.findById(teamMemberId);
//        AtomicReference<TeamMemberResponseListDto> responseDto = new AtomicReference<>(new TeamMemberResponseListDto());
//
//        teamMember.ifPresentOrElse(teamMember1 -> {
//            Optional<Project> project = projectRepository.findById(teamMember1.getProjectId());
//
//            project.ifPresentOrElse(project1 -> {
//                String accountName= accountRepository.findById(project1.getAccountId()).orElse(new Account()).getAccountName();
//                responseDto.set(toTeamMemberDto(teamMember1, project1.getProjectName(), accountName));
//            },()->{
//                log.error("TeamMemberServiceImpl:: getAllTeamMembers:: Project id not found :{}", teamMember1.getProjectId());
//                throw new ProjectNotFoundException("Project not found");
//            });
//        },()->{
//            log.error("TeamMemberServiceImpl:: getTeamMemberById:: No id found {}",teamMemberId);
//            throw new TeamMemberNotFoundException("Team Member not found");
//        });
//        log.info("TeamMemberServiceImpl:: getTeamMemberById:: ended");
//        return responseDto.get();
    	return new TeamMemberResponseListDto();
    }

    @Override
    public TeamMemberResponseDto editTeamMember(TeamMemberDto teamMemberDto, UUID userId, Long teamMemberId) {
    	// Commented out MongoDB code
    	//        log.info("TeamMemberServiceImpl:: editTeamMember:: started");
//        checkUserAuthenticity(userId);
//        Optional<TeamMember> teamMember = teamMemberRepository.findById(teamMemberId);
//        if (teamMember.isPresent()) {
//            String teamMemberName = teamMember.get().getName();
//            TeamMemberStatus teamMemberStatus = teamMember.get().getStatus();
//            TeamMember existingMember = new TeamMember();
//            BeanUtils.copyProperties(teamMember.get(), existingMember);
//
//            Optional<Project> project = projectRepository.findById(teamMember.get().getProjectId());
//            if (project.isEmpty()) {
//                log.error("TeamMemberServiceImpl:: editTeamMember:: Project id not found");
//                throw new ProjectNotFoundException("Project with ID " + teamMember.get().getProjectId() + " not found");
//            }
//            if (Boolean.TRUE.equals(checkAccessToEdit(userId, project.get().getAccountId(), project.get().getId()))) {
//                if (StringUtils.isNotBlank(teamMemberDto.getLocation()) && !locationRepository.existsByNameIgnoreCase(teamMemberDto.getLocation())) {
//                    Location location = new Location();
//                    location.setName(teamMemberDto.getLocation());
//                    locationRepository.save(location);
//                }
//                startAndEndDateValidator(teamMemberDto.getStartDate(), project.get().getStartDate(), teamMemberDto.getEndDate(), project.get().getEndDate());
//
//                BeanUtils.copyProperties(teamMemberDto, existingMember);
//                existingMember.setName(teamMemberName);
//                existingMember.setProjectId(teamMember.get().getProjectId());
//                existingMember.setUpdatedBy(utilMethods.getDisplayName(userId));
//                existingMember.setUpdatedAt(System.currentTimeMillis());
//                existingMember.setStatus(teamMemberStatus);
//                existingMember.setUserId(teamMember.get().getUserId());
//
//                if (teamMemberDto.getStatus() != null)
//                    existingMember.setStatus(teamMemberDto.getStatus());
//                TeamMemberResponseDto responseDto = new TeamMemberResponseDto();
//                TeamMember response = teamMemberRepository.save(existingMember);
//                BeanUtils.copyProperties(response, responseDto);
//                dedRolesRepository.deleteByOidAndProject_IdAndRole(userId, response.getProjectId(), TEAM_MEMBER);
//                userServiceImpl.saveRole(response);
//                log.info("TeamMemberServiceImpl:: editTeamMember:: ended");
//                return responseDto;
//            } else{
//                log.error("TeamMemberServiceImpl:: editTeamMember:: Not authorized");
//                throw new CustomException("User is not authorized to edit team member",HttpStatus.UNAUTHORIZED);
//            }
//        }else {
//            log.error("TeamMemberServiceImpl:: editTeamMember:: No id found");
//            throw new TeamMemberNotFoundException("Team Member with ID " + teamMemberId + " not found");
//        }
    	return new TeamMemberResponseDto();
    }

    private Boolean checkAccessToEdit(UUID oid, Long accountId, Long projectId) {
        String role = userServiceImpl.getHighestRole(oid, null, projectId);
        List<String> privileges = utilMethods.getPrivilegesString(role, List.of(TEAM_MEMBERS));
        return role.equalsIgnoreCase(SUPER_ADMIN_)
                || (dedRolesRepository.existsByOidAndAccount_IdAndRole(oid, accountId, DH)
                && utilMethods.getPrivilegesString(ACCOUNT_ADMIN_, List.of(TEAM_MEMBERS)).contains(TEAM_MEMBERS_EDIT))
                || privileges.contains(TEAM_MEMBERS_EDIT);
    }

    void startAndEndDateValidator(Long memberStartDate, Long projectStartDate, Long memberEndDate, Long projectEndDate) {
        LocalDate startDate = Instant.ofEpochMilli(memberStartDate)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        if (startDate.isAfter(LocalDate.now())) {
            log.error("TeamMemberServiceImpl::saveTeamMember::error");
            throw new ProjectDateException("Future date is not allowed: start date must be a past or current date");
        }
        if (memberStartDate <= projectStartDate) {
            log.error("TeamMemberServiceImpl::saveTeamMember:: startDate error");
            throw new ProjectDateException("Member start date must be after Project start date");
        }

        if (memberEndDate != null) {
            LocalDate endDate = Instant.ofEpochMilli(memberEndDate)
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
            if (startDate.isAfter(endDate)) {
                log.error("TeamMemberServiceImpl::saveTeamMember::error");
                throw new ProjectDateException("End date must be a after start date");
            }
            if (projectEndDate != null && memberEndDate >= projectEndDate) {
                log.error("TeamMemberServiceImpl::saveTeamMember:: EndDate error");
                throw new ProjectDateException("Member End date Must be before Project end date");
            }
        }
    }


    public List<TeamMemberResponseListDto> toTeamMemberDtoList(List<TeamMember> teamMember) {
        return teamMember.stream()
                .map(teamMembers -> toTeamMemberResponseDto(teamMembers))
                .toList();
    }

    public TeamMemberResponseListDto toTeamMemberResponseDto(TeamMember teamMember) {
        TeamMemberResponseListDto teamMemberResponseDto = new TeamMemberResponseListDto();
        BeanUtils.copyProperties(teamMember, teamMemberResponseDto);
        return teamMemberResponseDto;
    }

    public TeamMemberResponseListDto toTeamMemberDto(TeamMember teamMember, String projectName, String accountName) {
        TeamMemberResponseListDto teamMemberResponseDto = new TeamMemberResponseListDto();
        BeanUtils.copyProperties(teamMember, teamMemberResponseDto);
        teamMemberResponseDto.setProjectName(projectName);
        teamMemberResponseDto.setAccountName(accountName);
        return teamMemberResponseDto;
    }

    void checkUserAuthenticity(UUID userId) {
        String userName = utilMethods.getDisplayName(userId);
        if (null == userName
                || userName.isEmpty()) {
            log.error("TeamMemberServiceImpl::User not found");
            throw new UserNotFoundException(":User not found " + userId);
        }
    }

    public Set<String> getAllSkills(Long projectId) {
        log.info("TeamMemberService::fetchAllSkills() started");
        List<TeamMember> teamMembers = teamMemberRepository.findByProjectId(projectId);

        Set<String> skills = teamMembers.stream()
                .flatMap(teamMember -> teamMember.getSkillSet().stream())
                .collect(Collectors.toCollection(HashSet::new));
        log.info("TeamMemberService::fetchAllSkills() ended");
        return skills;
    }

}

