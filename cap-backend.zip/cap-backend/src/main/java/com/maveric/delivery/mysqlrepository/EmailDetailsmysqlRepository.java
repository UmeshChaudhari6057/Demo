package com.maveric.delivery.mysqlrepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maveric.delivery.Entity.EmailDetails;

@Repository
public interface EmailDetailsmysqlRepository extends JpaRepository<EmailDetails, Long> {

}

 