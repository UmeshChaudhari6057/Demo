package com.maveric.delivery.model.embedded;

import java.util.UUID;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangeHistory {
    private String name;
    private UUID userId;
    private Long updatedAt;
}
