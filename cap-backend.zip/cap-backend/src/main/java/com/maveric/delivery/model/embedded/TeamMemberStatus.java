package com.maveric.delivery.model.embedded;

public enum TeamMemberStatus {
    Inactive, Active,Released
}
