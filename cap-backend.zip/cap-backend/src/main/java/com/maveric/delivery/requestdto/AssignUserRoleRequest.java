package com.maveric.delivery.requestdto;

import java.util.List;

/**
 * @author ankushk
 */
public class AssignUserRoleRequest {
    private String roleName;
    private List<String> userNames;
}