package com.maveric.delivery.responsedto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobNotificationDetails {
    private String accountName;
    private String projectName;
    private String errorMessage;
    private int count;
}
