package com.maveric.delivery.responsedto;

import com.maveric.delivery.requestdto.AccountRoles;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountFilterResponseDto {
    private Set<AccountRoles> deliveryHeads;
    private Set<AccountRoles> accountPartners;
    private Set<AccountRoles> engagementPartners;
    private Set<AccountRoles> deliveryPartners;



}
