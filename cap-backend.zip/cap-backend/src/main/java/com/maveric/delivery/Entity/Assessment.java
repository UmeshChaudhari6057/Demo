package com.maveric.delivery.Entity;



import java.util.List;
import java.util.UUID;

import com.maveric.delivery.model.embedded.AssessmentStatus;

import com.maveric.delivery.model.embedded.MyTemplateCategory;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "assessments")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Assessment extends IdentifiedEntity {

    @Column(nullable = false)
    private Long accountId;

    @Column(nullable = false)
    private UUID userId;

    private String userName;

    private UUID deliveryHeadId;
    private String deliveryHead;

    private Long projectId;

    @Enumerated(EnumType.STRING)
    private AssessmentStatus status;

    private Long initiatedOn;
    private Long dueOn;
    private Long submittedOn;
    
    private String reviewerName;

    @Column(nullable = false)
    private UUID reviewerId;

    private Double score;

//    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JoinTable(
//    name = "assessment_questions",
//    joinColumns = @JoinColumn(name = "assessment_id"),
//    inverseJoinColumns = @JoinColumn(name = "question_id"))
//    private List<MyQuestion> questions; // Mapping with MyQuestion

    private String overallComment;
    private Long reviewedOn;
    private Boolean isReassigned;
    private String reasonForReassign;
    
    @OneToMany(mappedBy = "assessment", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<MyTemplateCategory> templateCategories;
}

