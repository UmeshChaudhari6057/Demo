package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;
@Data
@RequiredArgsConstructor
public class PrivilegesDetailsDto {
    private String name;
    private String value;
    private String description;
    private List<PrivilegesDto> privilegeDetails;
    @JsonIgnore
    private List<String> privilegesList;
}
