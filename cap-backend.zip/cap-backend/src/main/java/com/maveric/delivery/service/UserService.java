package com.maveric.delivery.service;


import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.requestdto.UserPrivilegesDto;

import java.util.List;
import java.util.UUID;

public interface UserService {
    String getHighestRole(UUID oid, Long accountId, Long projectId) ;
    DedRolesmy  saveUser(DedRolesDto json);
    List<UserDto> getAllUsers();
    Integer refreshUsers()throws ReflectiveOperationException;

    UserPrivilegesDto getPrivileges(UUID userId);

    List<String> getRolesName(UUID userId);
    List<String> getPrivilegesForNavBar(UUID userId);
}
