package com.maveric.delivery.utils;

import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.Entity.AzureUsers;
import com.maveric.delivery.model.embedded.DedRolesmy;
import com.maveric.delivery.mysqlrepository.AzureUsermysqlRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.requestdto.DateRangeDto;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.service.RolePrivilegesServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

import static com.maveric.delivery.utils.Constants.*;


@Service
@Slf4j
@RequiredArgsConstructor
public class UtilMethods {

    private final DedRolesRepository dedRolesRepository;
    private final RolePrivilegesServiceImpl rolePrivilegesService;
    private final AzureUsermysqlRepository azureUserRepository;

    public List<String> getPrivilegesString(String highestRole, List<String> values) {
        List<String> privileges = new ArrayList<>();
        if (!highestRole.isBlank() && (!highestRole.equalsIgnoreCase(SUPER_ADMIN_))) {
                List<PrivilegesDetailsDto> privilegesDetailsDtoList = rolePrivilegesService.findByValue(values, highestRole);
                for (PrivilegesDetailsDto privilegesDetailsDto : privilegesDetailsDtoList) {
                    privileges.addAll(privilegesDetailsDto.getPrivilegesList());
                }

        }
        return privileges;
    }

    public void checkValidRole(Long accountId, UUID userId, String role) {
        List<DedRolesmy> dedRoles = dedRolesRepository.findByAccount_IdAndRoleAndProject_IdIsNull(accountId, role);
        if (dedRoles.stream()
                .noneMatch(dedRole -> dedRole.getOid().equals(userId))) {
            throw new UserNotFoundException("Invalid User found in the role " + role);
        }
    }

    public String getDisplayName(UUID userId) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(userId);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }

    public DateRangeDto getDateRange(String range){
        DateRangeDto dateRangeDto = new DateRangeDto();
        LocalDate startDate = LocalDate.now();
        if (StringUtils.isBlank(range))
            range = ALL;
        switch(range){
            case LAST_30_DAYS -> {
                startDate = startDate.minusDays(29);
                dateRangeDto.setStartDate(startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
                dateRangeDto.setEndDate(LocalDateTime.now().with(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());
            }
            case OLDER_30_DAYS -> {
                LocalDate endDate = LocalDate.now().minusDays(30);
                dateRangeDto.setStartDate(0L);
                dateRangeDto.setEndDate(endDate.atTime(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());
            }
            case LAST_3_MONTHS ->{
                startDate = startDate.minusMonths(2).withDayOfMonth(1);
                dateRangeDto .setStartDate(startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
                dateRangeDto .setEndDate(LocalDateTime.now().with(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());}
            case LAST_6_MONTHS ->{
                startDate = startDate.minusMonths(5).withDayOfMonth(1);
                dateRangeDto .setStartDate(startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
                dateRangeDto .setEndDate(LocalDateTime.now().with(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());}
            case LAST_1_YEAR ->{
                startDate =  startDate.minusYears(1).withDayOfYear(1);
                dateRangeDto .setStartDate(startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
                dateRangeDto .setEndDate(LocalDateTime.now().with(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());}
            case LAST_2_YEAR ->{
                startDate = startDate.minusYears(2).withDayOfYear(1);
                dateRangeDto .setStartDate(startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
                dateRangeDto .setEndDate(LocalDateTime.now().with(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());}
            default -> {
                startDate = startDate.minusMonths(5).withDayOfMonth(1);
                dateRangeDto .setStartDate(startDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
                dateRangeDto .setEndDate(LocalDateTime.now().with(LocalTime.MAX).toInstant(ZoneOffset.UTC).toEpochMilli());}
        }

        return dateRangeDto;
    }

    public List<DateRangeDto> getChatDateRange(String range) {
        List<DateRangeDto> dateRangeDtos = new ArrayList<>();
        LocalDateTime startDate = LocalDateTime.now();
        if (StringUtils.isBlank(range))
            range = ALL;

        switch (range) {
            case LAST_3_MONTHS -> {
                startDate = startDate.minusMonths(2).withDayOfMonth(1);
                dateRangeDtos.addAll(getWeekRange(startDate, LocalDateTime.now()));
            }
            case LAST_6_MONTHS, ALL -> {
                startDate = startDate.minusMonths(5).withDayOfMonth(1);
                dateRangeDtos.addAll(getMonthRange(startDate, LocalDateTime.now()));
            }
            case LAST_1_YEAR -> {
                startDate = startDate.minusYears(1).withDayOfYear(1);
                dateRangeDtos.addAll(getMonthRange(startDate, LocalDateTime.now()));
            }
            case LAST_2_YEAR -> {
                startDate = startDate.minusYears(2).withDayOfYear(1);
                dateRangeDtos.addAll(getMonthRange(startDate, LocalDateTime.now()));
            }
            default -> {
                startDate = startDate.minusMonths(5).withDayOfMonth(1);
                dateRangeDtos.addAll(getMonthRange(startDate, LocalDateTime.now()));
            }

        }

        return dateRangeDtos;
    }

    private List<DateRangeDto> getWeekRange(LocalDateTime startDate, LocalDateTime endDate) {
        List<DateRangeDto> dateRangeDtos = new ArrayList<>();
        LocalDateTime currentWeekStart = startDate;
        while (currentWeekStart.isBefore(endDate)) {
            DateRangeDto dateRangeDto = new DateRangeDto();
            // Calculate the end of the current week
            LocalDateTime currentWeekEnd = currentWeekStart.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
            if (currentWeekEnd.isAfter(endDate)) {
                currentWeekEnd = endDate;
            }
            dateRangeDto.setStartDate(currentWeekStart.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
            dateRangeDto.setEndDate(currentWeekEnd.toLocalDate().atTime(LocalTime.MAX).atZone(ZoneOffset.UTC).toInstant().toEpochMilli());
            dateRangeDtos.add(dateRangeDto);
            // Move to the start of the next week
            currentWeekStart = currentWeekEnd.plusDays(1);
        }
        return dateRangeDtos;
    }

    private Collection<? extends DateRangeDto> getMonthRange(LocalDateTime startDate, LocalDateTime endDate) {
        List<DateRangeDto> dateRangeDtos = new ArrayList<>();
        LocalDateTime currentMonthStart = startDate;
        while (currentMonthStart.isBefore(endDate) || currentMonthStart.equals(endDate)) {
            DateRangeDto dateRangeDto = new DateRangeDto();
            // Calculate the end of the current month
            LocalDateTime currentMonthEnd = currentMonthStart.plusMonths(1).minusDays(1);
            if (currentMonthEnd.isAfter(endDate)) {
                currentMonthEnd = endDate;
            }
            dateRangeDto.setStartDate(currentMonthStart.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
            dateRangeDto.setEndDate(currentMonthEnd.toLocalDate().atTime(LocalTime.MAX).atZone(ZoneOffset.UTC).toInstant().toEpochMilli());
            dateRangeDtos.add(dateRangeDto);
            // Move to the start of the next month
            currentMonthStart = currentMonthStart.plusMonths(1);
        }
        return dateRangeDtos;

    }

    public Long stringToLong(String val) {
        if (StringUtils.isBlank(val) || val.equalsIgnoreCase("null"))
            return 0L;
        return Long.parseLong(val);
    }

    public Long integerToLong(Integer val) {
        if (null==val)
            return 0L;
        return Long.valueOf(val);
    }
    public static Double integerToDouble(Integer val) {
        if (null==val)
            return (double) 0;
        return Double.valueOf(val);
    }

    public void isValidField(Class<?> cls, String fieldName) {
        try {
            cls.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            throw new IllegalArgumentException("Field '" + fieldName + "' does not exist");
        }
    }

    // Generate a new trace ID
    public void updateSchedulerTraceId(){
            String traceId = UUID.randomUUID().toString();
            // Set the trace ID in the MDC
            MDC.put(CRON_TRACE_ID, traceId);
    }
}
