package com.maveric.delivery.Entity;


import java.util.List;
import java.util.UUID;

import org.hibernate.annotations.UpdateTimestamp;

import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.MyTemplateCategory;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "assessment_draft", indexes = {
        @Index(name = "idx_assessment_id", columnList = "assessment_id")
})
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssessmentDraft extends IdentifiedEntity {

    @Column(name = "assessment_id", nullable = false)
    private Long assessmentId;

    private Long accountId;
    private UUID userId;
    private String userName;
    private UUID deliveryHeadId;
    private String deliveryHead;
    private Long projectId;

    @Enumerated(EnumType.STRING)
    private AssessmentStatus status;

    private Long initiatedOn;
    private Long dueOn;
    private Long submittedOn;
    private String reviewerName;
    private UUID reviewerId;
    private Double score;
//    @ElementCollection
//    @CollectionTable(name = "assessment_draft_template_category", 
//                     joinColumns = @JoinColumn(name = "assessment_draft_id"))
//    private List<MyTemplateCategory> templateCategory;
//    
    
    // 🔹 One-to-Many Relationship with MyTemplateCategory
    @OneToMany(mappedBy = "assessmentDraft", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<MyTemplateCategory> templateCategories;
    
    @Column(columnDefinition = "TEXT")
    private String overallComment;

    private Long reviewedOn;
    private Boolean isReassigned;
    private String reasonForReassign;
    private String updatedBy;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Long updatedAt;
}

