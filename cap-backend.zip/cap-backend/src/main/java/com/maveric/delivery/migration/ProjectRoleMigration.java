package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.ProjectRole;
import com.maveric.delivery.mysqlrepository.ProjectRolemysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
//import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "ProjectRole", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
@Service
@AllArgsConstructor
public class ProjectRoleMigration implements Migration{
   
 ////   private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/project-role.json";
    
    private final ProjectRolemysqlRepository projectRolemysqlReposiotry;


    
    @Override
    public void before() {
        log.info("ProjectRole Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
  
    @Override
    public void rollbackBefore() {
        log.info("ProjectRole Migration RollbackBeforeExecution");
    }

  
    @Override
    public void migrationMethod() throws IOException {
        log.info("ProjectRole migrationMethod");
//        List<ProjectRole> projectRoles= jsonFileReader.readJsonFileToList(filePath, ProjectRole.class);
//        mongoTemplate.insertAll(projectRoles);
//        
        
        try {
            List<ProjectRole> projectRoles = jsonFileReader.readJsonFileToList(filePath, ProjectRole.class);

            if (!projectRoles.isEmpty()) {
            	projectRolemysqlReposiotry.saveAll(projectRoles);
                log.info("Migration completed: {} records inserted", projectRoles.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
        
    }

    
    @Override
    public void rollback() {
        log.info("ProjectRole Migration RollbackBeforeExecution");
        projectRolemysqlReposiotry.deleteAll();
    }
}
