package com.maveric.delivery.controller;

import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.*;
import com.maveric.delivery.service.AccountServiceImpl;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;


@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
@Tag(name = "Account Management", description = "Endpoints for managing Accounts")
public class AccountController {

    private final AccountServiceImpl accountServiceImpl;
    private final ValidateApiAccess validateApiAccess;

    private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

    @Operation(summary = "Save Account",description = "Api to save account")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Account created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/accounts")
    public ResponseEntity<ResponseDto<AccountResponseDto>> saveAccount(HttpServletRequest servletRequest, @Valid @RequestBody AccountRequestDto accountRequestDto) {
        logger.info("AccountController::Saving account: {}", accountRequestDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE);
        AccountResponseDto createdAccount = accountServiceImpl.createAccount(accountRequestDto,rolesDto.getOid());
        logger.info("Account created successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto<>(SUCCESS, SuccessMessage.ACCOUNT_CREATED.getCode(), SuccessMessage.ACCOUNT_CREATED.getMessage(), null, createdAccount));
    }

    @Operation(summary = "Get All Accounts",description = "Api to Get All Accounts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Accounts Fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/userId/{userId}")
    public ResponseEntity<ResponseDto<List<AccountSummaryDto>>> getAllAccountsByuserId(HttpServletRequest servletRequest, @PathVariable UUID userId) throws Exception {
        logger.info("AccountController::Fetching all accounts by userId: {}", userId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, VIEW_ALL,VIEW_ASSOCIATED);
        List<AccountSummaryDto> accounts = accountServiceImpl.getAllAccounts(rolesDto.getOid(),new AccountFilterDto());
        logger.info("Accounts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ACCOUNTS.getCode(), SuccessMessage.FETCH_ACCOUNTS.getMessage(), null, accounts));
    }

    @Operation(summary = "Get All Accounts counts",description = "Api to Get Accounts summary counts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Accounts count fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/summaryCount/userId/{userId}")
    public ResponseEntity<ResponseDto<AccountSummaryCountDto>> getSummaryCounts(HttpServletRequest servletRequest, @PathVariable UUID userId) throws Exception {
        logger.info("AccountController::Fetching summary counts for userId: {}", userId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, VIEW_ASSOCIATED,VIEW_ALL);
        AccountSummaryCountDto accounts = accountServiceImpl.getCountOfAccount(rolesDto.getOid());
        logger.info("Summary counts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ACCOUNTS_COUNT.getCode(), SuccessMessage.FETCH_ACCOUNTS_COUNT.getMessage(), null, accounts));
    }

    @Operation(summary = "Get By Account Id",description = "Api to get specific account")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account found by ID"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/{accountId}")
    public ResponseEntity<ResponseDto<AccountResponseDto>> getAccountById(HttpServletRequest servletRequest, @PathVariable Long accountId) {
        logger.info("AccountController::Fetching account by ID: {}", accountId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS,VIEW_ALL,VIEW_ASSOCIATED);
        AccountResponseDto accountOptional = accountServiceImpl.getAccountById(accountId, rolesDto.getOid());
        logger.info("Account retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ACCOUNT.getCode(), SuccessMessage.FETCH_ACCOUNT.getMessage(), null, accountOptional));
    }

    @Operation(summary = "Edit Account",description = "APi to update specific account details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account edited successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(path = "/accounts/{accountId}")
    public ResponseEntity<ResponseDto<AccountResponseDto>> editAccount(HttpServletRequest servletRequest, @RequestBody AccountRequestDto accountRequestDto, @PathVariable Long accountId) {
        logger.info("AccountController::Editing account with ID: {}, {}", accountId, accountRequestDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).accountId(accountId).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, EDIT);
        AccountResponseDto editedAccount = accountServiceImpl.editAccount(accountRequestDto, accountId,rolesDto.getOid());
        logger.info("Account edited successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto<>(SUCCESS, SuccessMessage.UPDATE_ACCOUNT_DETAILS.getCode(), SuccessMessage.UPDATE_ACCOUNT_DETAILS.getMessage(), null, editedAccount));
    }

    @Operation(summary = "Duplicate Account Name",description = "Api to validate to Duplicate Account Name ")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Check if account name is duplicate"),
            @ApiResponse(responseCode = "409", description = "Duplicate account name"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/duplicate/{accountName}")
    public ResponseEntity<ResponseDto<Boolean>> duplicateAccountName(HttpServletRequest servletRequest, @PathVariable String accountName) {
        logger.info("AccountController::Checking duplicate account name: {}", accountName);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE,EDIT);
        boolean isDuplicate = accountServiceImpl.duplicateAccountName(accountName);
        if (isDuplicate) {
            logger.warn("Duplicate account name found: {}", accountName);
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>("Successfully", FailedMessage.EXISTS_ACCOUNT.getCode(), FailedMessage.EXISTS_ACCOUNT.getMessage().concat(accountName), null, isDuplicate));
        } else {
            logger.info("Account name is not a duplicate: {}", accountName);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto<>("Successfully", SuccessMessage.AVAILABLE_ACCOUNT.getCode(), SuccessMessage.AVAILABLE_ACCOUNT.getMessage().concat(accountName), null, isDuplicate));
        }
    }

    @Operation(summary = "Get Account Members By Account Id",description = "Api to get Account members details (i.e.,: AP,EP,DP )")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description ="Account Members fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/{accountId}/members")
    public ResponseEntity<ResponseDto<AccountMemberDto>> getAccountMembers(HttpServletRequest servletRequest, @PathVariable Long accountId) {
        log.info("AccountController::getAccountMembers() ::start");
        AccountMemberDto accountMemberDto = accountServiceImpl.getAccountMembers(accountId);
        log.info("AccountController::getAccountMembers() ::End");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(SUCCESS, SuccessMessage.FETCH_ACCOUNT_MEMBERS.getCode(), SuccessMessage.FETCH_ACCOUNT_MEMBERS.getMessage() + accountId, null, accountMemberDto));

    }

    @Operation(summary = "Get All AccountName as per userId",description = "Api to get Account name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description ="Accounts Fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(path = "/accounts/names")
    public ResponseEntity<ResponseDto<AccountNamesResponseDto>> getAccountsList(HttpServletRequest servletRequest) throws Exception {
        logger.info("AccountController::Fetching all accounts");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, PROJECTS, VIEW_ALL,VIEW_ASSOCIATED);
        AccountNamesResponseDto accountsNames = accountServiceImpl.getAccountsList(rolesDto.getOid());
        logger.info("Accounts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.FETCH_ACCOUNTS.getCode(), SuccessMessage.FETCH_ACCOUNTS.getMessage(), null, accountsNames));

    }
    @Operation(summary = "Get All Associated accounts for project creation",description = "Api to get Account name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description ="Accounts Fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/associated-names")
    public ResponseEntity<ResponseDto<List<AccountListDto>>> getAssociatedAccountList(HttpServletRequest servletRequest) {
        logger.info("AccountController::getAssociatedAccountList:: method call started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, PROJECTS, VIEW_ALL,VIEW_ASSOCIATED);
        List<AccountListDto> accountsNames = accountServiceImpl.getAccountNamesListInCreateProject(rolesDto.getOid());
        logger.info("Accounts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto<>(Constants.SUCCESS, SuccessMessage.FETCH_ACCOUNTS.getCode(), SuccessMessage.FETCH_ACCOUNTS.getMessage(), null, accountsNames));

    }


    @Operation(summary = "Fetch Account filter members",description = "Api to Fetch Account filter members")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account filters members fetched Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/members/filters")
    public ResponseEntity<ResponseDto<AccountFilterResponseDto>> fetchAccountFilterMembers(HttpServletRequest servletRequest) {
        log.info("AccountController::fetchAccountFilterMembers() started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        AccountFilterResponseDto filterMembersDto =accountServiceImpl.getAccountFilterMembers(rolesDto.getOid());
        log.info("AccountController::fetchAccountFilterMembers() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, SuccessMessage.ACCOUNT_FILTER_MEMBERS_FETCHED.getCode(), SuccessMessage.ACCOUNT_FILTER_MEMBERS_FETCHED.getMessage(),null, filterMembersDto));
    }

    @Operation(summary = "Fetch Account List",description = "Api to Fetch Account List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account List fetched Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "accounts/filters/account-name")
    public ResponseEntity<ResponseDto<List<AccountListDto>>> fetchAccountList(HttpServletRequest servletRequest,@RequestParam(required = false) AssessmentRole assessmentRole)  {
        log.info("AccountController::fetchAccountList() started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        List<AccountListDto> accountListResponseDto =accountServiceImpl.getAccountsListResponse(rolesDto.getOid(),assessmentRole);
        log.info("AccountController::fetchAccountList() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, SuccessMessage.ACCOUNT_LIST_FETCHED.getCode(), SuccessMessage.ACCOUNT_LIST_FETCHED.getMessage(),null, accountListResponseDto));
    }

    @Operation(summary = "Apply Filter for Account",description = "Api to Filter the Account based on the criteria")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Filtered data fetched Successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/accounts/filters")
    public ResponseEntity<ResponseDto<List<AccountSummaryDto>>> fetchFilteredData(HttpServletRequest servletRequest,@RequestBody AccountFilterDto accountFilterDto) throws Exception {
        log.info("AccountController::fetchFilteredData() started");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS,VIEW_ALL,VIEW_ASSOCIATED );
        List<AccountSummaryDto> accountListResponseDto =accountServiceImpl.getAllAccounts(rolesDto.getOid(), accountFilterDto) ;
        log.info("AccountController::fetchFilteredData() ended");
        return ResponseEntity.ok(new ResponseDto<>(SUCCESS, SuccessMessage.ACCOUNT_LIST_FETCHED.getCode(), SuccessMessage.ACCOUNT_LIST_FETCHED.getMessage(),null, accountListResponseDto));
    }

}


