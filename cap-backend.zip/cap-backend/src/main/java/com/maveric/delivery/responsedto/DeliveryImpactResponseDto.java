package com.maveric.delivery.responsedto;

import com.maveric.delivery.Entity.IdentifiedEntity;
import com.maveric.delivery.model.embedded.ChangeHistory;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeliveryImpactResponseDto extends IdentifiedEntity {
    private Long projectId;
    private String content;
    private List<ChangeHistory> changeHistory;
}
