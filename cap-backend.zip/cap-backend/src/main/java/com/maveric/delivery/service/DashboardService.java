package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.DashboardFilterDto;
import com.maveric.delivery.responsedto.DashboardDetailsDto;
import com.maveric.delivery.responsedto.AssessmentDetailsDto;
import com.maveric.delivery.responsedto.AssessmentTrendsDetailsDto;

public interface DashboardService {
    DashboardDetailsDto fetchDashboardDetails(DashboardFilterDto dashboardFilterDto);

    AssessmentDetailsDto fetchTopAssessment();

    AssessmentTrendsDetailsDto fetchDashboardTrendsDetails(DashboardFilterDto dashboardFilterDto);
}
