package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.requestdto.TeamMemberFilterDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;

import java.util.List;
import java.util.Set;
import java.util.UUID;

public interface TeamMemberService {
    TeamMemberResponseDto saveTeamMember(TeamMemberDto teamMemberDto, UUID oid,Long projectId);

    List<TeamMemberResponseListDto> getAllTeamMembers(UUID userId,Long projectId, TeamMemberFilterDto filter);

    TeamMemberResponseDto editTeamMember(TeamMemberDto teamMemberDto, UUID oid, Long teamMemberId);
    TeamMemberResponseListDto getTeamMemberById(Long teamMemberId);

    Set<String> getAllSkills( Long projectId);
}
