package com.maveric.delivery.service;

import com.maveric.delivery.exception.DataNotFoundException;
import com.maveric.delivery.mapper.PrivilegesMapper;
import com.maveric.delivery.Entity.IdentifiedEntity;
import com.maveric.delivery.Entity.Privileges;
import com.maveric.delivery.Entity.RolePrivileges;
import com.maveric.delivery.Entity.Roles;
import com.maveric.delivery.mysqlrepository.PrivilegesmysqlRepository;
import com.maveric.delivery.mysqlrepository.RolePrivilegesmysqlRepository;
import com.maveric.delivery.mysqlrepository.RolesmysqlRepository;
import com.maveric.delivery.requestdto.PrivilegesDetailsDto;
import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.utils.FailedMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RolePrivilegesServiceImpl implements RolePrivilegesService {

    private final RolePrivilegesmysqlRepository rolePrivilegesRepository;

    private final PrivilegesmysqlRepository privilegesRepository;

    private final RolesmysqlRepository rolesRepository;

    @Override
//    @CacheEvict(value = {"findByRoleId", "findByGroupContaining"}, allEntries = true)
    public List<RolePrivilegesDto> save(List<RolePrivilegesDto> rolePrivilegesDtoList) {
        log.debug("RolePrivilegesServiceImpl.save: started");
        List<RolePrivileges> rolePrivileges = new ArrayList<>();
        rolePrivilegesDtoList.forEach(rolePrivilegesDto -> {

           if (!rolesRepository.existsById(rolePrivilegesDto.getRoleId()))
               throw new DataNotFoundException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());

            RolePrivileges privileges = toEntity(rolePrivilegesDto);
            Long id = rolePrivilegesRepository.findByRoleId(rolePrivilegesDto.getRoleId()).map(IdentifiedEntity::getId).orElse(null);
            privileges.setId(id);
            privileges = rolePrivilegesRepository.save(privileges);
            rolePrivileges.add(privileges);
        });
        log.debug("RolePrivilegesServiceImpl.save: end");
        return toDtoList(rolePrivileges);
    }

    @Override
    public List<RolePrivilegesDto> findAll() {
        log.debug("RolePrivilegesServiceImpl.get: start");
        List<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findAll();
        log.debug("RolePrivilegesServiceImpl.get: end");
        return toDtoList(rolePrivileges);
    }

    @Override
    public RolePrivilegesDto findByRoleId(Long roleId) {
        log.debug("RolePrivilegesServiceImpl.findByRoleId: start -> RoleId:{}", roleId);
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roleId);
        log.debug("RolePrivilegesServiceImpl.findByRoleId: end -> RoleId:{}", roleId);
        return toDto(rolePrivileges.orElse(null));

    }

    @Override
    public List<PrivilegesDetailsDto> findByGroup(List<String> module, String userGroup) {
        log.debug("RolePrivilegesServiceImpl.findByGroup: start -> type:{} ,userGroup:{} ", module, userGroup);
        Roles roles = rolesRepository.findByGroupContaining(userGroup);
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roles.getId());
        Optional<List<Privileges>> privileges = rolePrivileges.map(RolePrivileges::getPrivileges);
        log.debug("RolePrivilegesServiceImpl.findByGroup: end -> type:{} ,userGroup:{} ", module, userGroup);
        List<PrivilegesDetailsDto> privilegesDetailsDtos = PrivilegesMapper.MAPPER.toDtoList(privileges.orElse(Collections.emptyList()).stream().filter(privileges1 -> module.contains(privileges1.getValue())).toList());
        privilegesDetailsDtos.stream().filter(Objects::nonNull).forEach(privilegesDto -> {

                    List<String> list = privilegesDto.getPrivilegesList().stream().filter(Objects::nonNull).map(s ->
                            ((privilegesDto.getValue() + "_" + s).replace(" ", "_")).toUpperCase()
                    ).toList();
                    privilegesDto.setPrivilegesList(list);
                }

        );
        return privilegesDetailsDtos;
    }

    @Override
    public RolePrivilegesDto findByValue(String name) {
        log.debug("RolePrivilegesServiceImpl.findByValue: start -> Role:{} ", name);
        Roles roles = rolesRepository.findByName(name);
        if (Objects.isNull(roles) || Objects.isNull(roles.getId()))
            throw new DataNotFoundException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roles.getId());
        log.debug("RolePrivilegesServiceImpl.findByValue: end -> Role:{} ", name);
        return toDto(rolePrivileges.orElse(null));
    }

    @Override
    public List<PrivilegesDetailsDto> findByValue(List<String> module, String value) {
        log.debug("RolePrivilegesServiceImpl.findByValue: start -> type:{} ,Role:{} ", module, value);
        Roles roles = rolesRepository.findByName(value);
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roles.getId());
        Optional<List<Privileges>> privileges = rolePrivileges.map(RolePrivileges::getPrivileges);
        List<PrivilegesDetailsDto> privilegesDetailsDtos;
        if (module.stream().anyMatch(s -> s.equalsIgnoreCase("ALL"))) {
            privilegesDetailsDtos = PrivilegesMapper.MAPPER.toDtoList(privileges.orElse(Collections.emptyList()));
        } else {
            privilegesDetailsDtos = PrivilegesMapper.MAPPER.toDtoList(privileges.orElse(Collections.emptyList()).stream().filter(privileges1 -> module.contains(privileges1.getValue())).toList());
        }
        privilegesDetailsDtos.stream().filter(Objects::nonNull).forEach(privilegesDto -> {
                    List<String> list = Collections.emptyList();
                    if (!CollectionUtils.isEmpty(privilegesDto.getPrivilegesList())) {
                        list = privilegesDto.getPrivilegesList().stream().filter(Objects::nonNull).map(s ->
                                ((privilegesDto.getValue() + "_" + s).replace(" ", "_")).toUpperCase()
                        ).toList();
                    }
                    privilegesDto.setPrivilegesList(list);
                }
        );
        log.debug("RolePrivilegesServiceImpl.findByGroup: end -> type:{} , Role:{} ", module, value);
        return privilegesDetailsDtos;
    }


    private RolePrivileges toEntity(RolePrivilegesDto rolePrivilegesDto) {
        RolePrivileges rolePrivileges = new RolePrivileges();
        List<Privileges> privileges = new ArrayList<>();
        rolePrivilegesDto.getPrivileges().forEach(privilegesDetailsDto -> {
            Privileges privileges1 = new Privileges();
            privileges1.setName(privilegesDetailsDto.getName());
            if(!CollectionUtils.isEmpty(privilegesDetailsDto.getPrivilegeDetails()))
                privileges1.setPrivileges(privilegesDetailsDto.getPrivilegeDetails().stream().filter(PrivilegesDto::isEnabled).map(privilegesDto -> {
                    Privileges privileges2 = new Privileges();
                    privileges2.setName(privilegesDto.getName());
                    privileges2.setValue(privilegesDto.getValue());
                    privileges2.setDescription(privilegesDto.getDescription());
                    return privileges2;
                }).toList());
            privileges.add(privileges1);
        });
        rolePrivileges.setRoleId(rolePrivilegesDto.getRoleId());
        rolePrivileges.setPrivileges(privileges);
        return rolePrivileges;
    }

    private List<RolePrivilegesDto> toDtoList(List<RolePrivileges> rolePrivileges) {
        return rolePrivileges.stream().map(this::toDto).toList();
    }

    private RolePrivilegesDto toDto(RolePrivileges rolePrivileges) {
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<PrivilegesDetailsDto> privilegesDetailsDtos = new ArrayList<>();
        List<Privileges> privileges = privilegesRepository.findAll();
        if (Objects.nonNull(rolePrivileges.getRoleId())) {
            Optional<Roles> roles = rolesRepository.findById(rolePrivileges.getRoleId());
            if (roles.isPresent()) {
                rolePrivilegesDto.setRoleName(roles.get().getName());
                rolePrivilegesDto.setHierarchy((long) roles.get().getHierarchy());
                rolePrivilegesDto.setRoleId(roles.get().getId());

                Map<String, List<Privileges>> list = rolePrivileges.getPrivileges().stream().collect(Collectors.groupingBy(Privileges::getValue, Collectors.mapping(Privileges::getPrivileges, Collectors.reducing(new ArrayList<>(), (list1, list2) -> {
                    List<Privileges> mergedList = new ArrayList<>(list1);
                    mergedList.addAll(list2);
                    return mergedList;
                }))));
                for (Privileges privileges1 : privileges) {
                    PrivilegesDetailsDto privilegesDetailsDto = new PrivilegesDetailsDto();

                    List<PrivilegesDto> privilegesDtos = privileges1.getPrivileges().stream().map(s -> {
                        PrivilegesDto privilegesDto = new PrivilegesDto();
                        privilegesDto.setName(s.getName());
                        privilegesDto.setValue(s.getValue());
                        privilegesDto.setDescription(s.getDescription());
                        List<Privileges> val = list.get(privileges1.getValue());
                        boolean isEnabled = false;
                        if (!CollectionUtils.isEmpty(val)) {
                            List<String> privilegesList= val.stream().map(Privileges::getValue).toList();
                            isEnabled = privilegesList.contains(s.getValue());
                            privilegesDetailsDto.setPrivilegesList(privilegesList);
                        }
                        privilegesDto.setEnabled(isEnabled);

                        return privilegesDto;
                    }).toList();
                    privilegesDetailsDto.setName(privileges1.getName());
                    privilegesDetailsDto.setDescription(privileges1.getDescription());
                    privilegesDetailsDto.setValue(privileges1.getValue());

                    privilegesDetailsDto.setPrivilegeDetails(privilegesDtos);
                    privilegesDetailsDtos.add(privilegesDetailsDto);
                }
                rolePrivilegesDto.setPrivileges(privilegesDetailsDtos);
            }
        }
        return rolePrivilegesDto;
    }
}
