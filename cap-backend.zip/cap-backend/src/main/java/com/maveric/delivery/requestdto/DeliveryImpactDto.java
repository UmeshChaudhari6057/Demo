package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.ChangeHistory;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeliveryImpactDto {

    @NotNull(message = "Content is required")
    private String content;

}


