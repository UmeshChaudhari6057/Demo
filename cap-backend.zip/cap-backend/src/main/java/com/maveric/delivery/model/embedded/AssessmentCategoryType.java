package com.maveric.delivery.model.embedded;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AssessmentCategoryType {
    PROJECT_MATURITY("Project Maturity"),
    EXECUTION_MATURITY("Execution Maturity"),
    DELIVERY_MATURITY("Delivery Maturity");

    private final String description;

}
