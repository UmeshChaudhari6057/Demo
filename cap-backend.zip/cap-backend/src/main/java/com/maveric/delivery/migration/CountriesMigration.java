package com.maveric.delivery.migration;

import com.maveric.delivery.Entity.BusinessSubvertical;
import com.maveric.delivery.Entity.Country;
import com.maveric.delivery.mysqlrepository.CountrymysqlRepository;
import com.maveric.delivery.utils.JsonFileReader;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

//@ChangeUnit(id = "Countries", order = "001", author = "delivery-excellence", systemVersion = "1")
@Service
@Slf4j
@AllArgsConstructor
public class CountriesMigration implements Migration{
 //   private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;

    private final String filePath = "/migration/data/countries.json";
    
    private final CountrymysqlRepository countrymysqlRepository;


//    @BeforeExecution
    @Override
    public void before() {
        log.info("Countries Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
 //   @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("Countries Migration RollbackBeforeExecution");
    }

  //  @Execution
    @Transactional
    @Override
    public void migrationMethod() throws IOException {
        log.info("Countries migrationMethod");
     //   List<Country> Countriess= jsonFileReader.readJsonFileToList(filePath, Country.class);
      //  mongoTemplate.insertAll(Countriess);
        
        
        try {
            List<Country> Countriess = jsonFileReader.readJsonFileToList(filePath, Country.class);

            if (!Countriess.isEmpty()) {
            	countrymysqlRepository.saveAll(Countriess);
                log.info("Migration completed: {} records inserted", Countriess.size());
            } else {
                log.info("No data found to migrate.");
            }
        } catch (IOException e) {
            log.error("Error reading JSON file for migration", e);
            throw new RuntimeException("Migration failed! Rolling back...");
        }
        
    }

    

  //  @RollbackExecution
    @Override
    public void rollback() {
        log.info("Countries Migration RollbackBeforeExecution");
        
        //Addedd code for mysql
        countrymysqlRepository.deleteAll(); 
    }

}
